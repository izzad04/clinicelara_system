<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Treatments Model
 *
 * @property \App\Model\Table\PatientsTable&\Cake\ORM\Association\BelongsTo $Patients
 * @property \App\Model\Table\DoctorsTable&\Cake\ORM\Association\BelongsTo $Doctors
 *
 * @method \App\Model\Entity\Treatment newEmptyEntity()
 * @method \App\Model\Entity\Treatment newEntity(array $data, array $options = [])
 * @method array<\App\Model\Entity\Treatment> newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Treatment get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \App\Model\Entity\Treatment findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \App\Model\Entity\Treatment patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\App\Model\Entity\Treatment> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Treatment|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \App\Model\Entity\Treatment saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\App\Model\Entity\Treatment>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Treatment>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Treatment>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Treatment> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Treatment>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Treatment>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Treatment>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Treatment> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class TreatmentsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
     public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('treatments');
        $this->setDisplayField('sickness');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Patients', [
            'foreignKey' => 'patient_id',
            'joinType' => 'INNER',
        ]);

        $this->belongsTo('Doctors', [
            'foreignKey' => 'doctor_id',
            'joinType' => 'INNER',
        ]);

        $this->addBehavior('AuditStash.AuditLog');

        // ✅ Search behavior
        $this->addBehavior('Search.Search');

        // ✅ Search configuration: id + name (patient/doctor/sickness)
        $this->searchManager()
            // exact search by Treatments.id
            ->add('id', 'Search.Value', [
                'fields' => ['Treatments.id'],
            ])


            // LIKE search by patient name OR doctor name OR sickness
            ->add('name', 'Search.Like', [
                'before' => true,
                'after' => true,
                'fieldMode' => 'OR',
                'comparison' => 'LIKE',
                'fields' => [
                    'Patients.fullname',
                    'Doctors.fullname',
                    'Treatments.sickness',
                ],
            ]);
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('patient_id')
            ->notEmptyString('patient_id');

        $validator
            ->integer('doctor_id')
            ->notEmptyString('doctor_id');

        $validator
            ->date('start_date')
            ->requirePresence('start_date', 'create')
            ->notEmptyDate('start_date');

        $validator
            ->date('end_date')
            ->requirePresence('end_date', 'create')
            ->notEmptyDate('end_date');

        $validator
            ->integer('duration')
            ->requirePresence('duration', 'create')
            ->notEmptyString('duration');

        $validator
            ->scalar('sickness')
            ->maxLength('sickness', 255)
            ->requirePresence('sickness', 'create')
            ->notEmptyString('sickness');

        $validator
            ->scalar('notes')
            ->allowEmptyString('notes');

        return $validator;
    }

    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['patient_id'], 'Patients'), ['errorField' => 'patient_id']);
        $rules->add($rules->existsIn(['doctor_id'], 'Doctors'), ['errorField' => 'doctor_id']);

        return $rules;
    }
}
