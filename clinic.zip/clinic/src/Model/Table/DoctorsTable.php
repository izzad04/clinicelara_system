<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
use Search\Manager;

class DoctorsTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('doctors');
        $this->setDisplayField('fullname');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        $this->addBehavior('AuditStash.AuditLog');
        $this->addBehavior('Search.Search');

        $this->hasMany('Appointments', [
            'foreignKey' => 'doctor_id',
        ]);
    }

    /**
     * Search supports:
     * - ?id=2
     * - ?doctor=izzad
     * - both together
     */
    public function searchManager(): Manager
    {
        $searchManager = new Manager($this);

        // ✅ ID exact match (numeric only)
        $searchManager->callback('id', [
            'callback' => function ($query, $args) {
                $id = $args['id'] ?? null;
                if ($id !== null && $id !== '' && ctype_digit((string)$id)) {
                    $query->where([$this->aliasField('id') => (int)$id]);
                }
                return true;
            }
        ]);

        // ✅ Doctor name LIKE
        $searchManager->like('doctor', [
            'before' => true,
            'after'  => true,
            'fields' => [
                $this->aliasField('fullname'),
            ],
        ]);

        return $searchManager;
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('fullname')
            ->maxLength('fullname', 50)
            ->requirePresence('fullname', 'create')
            ->notEmptyString('fullname');

        // Keep as you currently have (change if specialization is varchar)
        $validator
            ->integer('specialization')
            ->notEmptyString('specialization');

        $validator
            ->integer('status')
            ->notEmptyString('status');

        return $validator;
    }
}
