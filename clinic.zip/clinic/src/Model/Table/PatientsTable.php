<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\ORM\RulesChecker;

class PatientsTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('patients');
        $this->setDisplayField('fullname');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        $this->addBehavior('AuditStash.AuditLog');

        // Search Behavior
        $this->addBehavior('Search.Search');

        $this->hasMany('Appointments', [
            'foreignKey' => 'patient_id',
        ]);

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER',
        ]);

        /**
         * ✅ Search:
         * ?id=2
         * ?fullname=joanne
         * ?ic=0412...
         */
        $this->searchManager()
            ->add('id', 'Search.Value', [
                'fields' => ['Patients.id'],
            ])
            ->add('fullname', 'Search.Like', [
                'before' => true,
                'after'  => true,
                'fields' => ['Patients.fullname'],
            ])
            ->add('ic', 'Search.Like', [
                'before' => true,
                'after'  => true,
                'fields' => ['Patients.ic'],
            ]);
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('user_id')
            ->notEmptyString('user_id');

        $validator
            ->scalar('fullname')
            ->maxLength('fullname', 50)
            ->requirePresence('fullname', 'create')
            ->notEmptyString('fullname');

        $validator
            ->scalar('ic')
            ->maxLength('ic', 14)
            ->requirePresence('ic', 'create')
            ->notEmptyString('ic');

        $validator
            ->scalar('phone')
            ->maxLength('phone', 13)
            ->requirePresence('phone', 'create')
            ->notEmptyString('phone');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmptyString('email');

        $validator
            ->scalar('street1')
            ->maxLength('street1', 25)
            ->requirePresence('street1', 'create')
            ->notEmptyString('street1');

        $validator
            ->scalar('street2')
            ->maxLength('street2', 25)
            ->requirePresence('street2', 'create')
            ->notEmptyString('street2');

        $validator
            ->integer('postcode')
            ->requirePresence('postcode', 'create')
            ->notEmptyString('postcode');

        $validator
            ->scalar('city')
            ->maxLength('city', 25)
            ->requirePresence('city', 'create')
            ->notEmptyString('city');

        $validator
            ->scalar('state')
            ->maxLength('state', 30)
            ->requirePresence('state', 'create')
            ->notEmptyString('state');

        return $validator;
    }

    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn('user_id', 'Users'), ['errorField' => 'user_id']);
        return $rules;
    }
}
