<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Patient Entity
 *
 * @property int $id
 * @property string $fullname
 * @property string $ic
 * @property int $phone
 * @property string $email
 * @property string $street1
 * @property string $street2
 * @property int $postcode
 * @property string $city
 * @property string $state
 * @property \Cake\I18n\DateTime $created
 * @property \Cake\I18n\DateTime $modified
 *
 * @property \App\Model\Entity\Appointment[] $appointments
 */
class Patient extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'user_id' => true,
        'fullname' => true,
        'ic' => true,
        'phone' => true,
        'email' => true,
        'street1' => true,
        'street2' => true,
        'postcode' => true,
        'city' => true,
        'state' => true,
        'status' => true,
        'created' => true,
        'modified' => true,
        'appointments' => true,
    ];
}
