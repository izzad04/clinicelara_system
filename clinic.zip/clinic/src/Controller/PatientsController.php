<?php
namespace App\Controller;

use App\Controller\AppController;

class PatientsController extends AppController
{
   public function index()
{
    // Current user
    $currentUser = $this->request->getAttribute('identity');
    $currentUserId = $currentUser->id ?? null;
    $userRole = $currentUser->role ?? 'user';

    // ✅ NEW SEARCH FIELDS
    $id   = trim((string)$this->request->getQuery('id'));
    $name = trim((string)$this->request->getQuery('name'));
    $ic   = trim((string)$this->request->getQuery('ic'));

    // Base query
    $query = $this->Patients->find()
        ->contain(['Users'])
        ->order(['Patients.created' => 'DESC']);

    /**
     * 🔒 ROLE-BASED VISIBILITY
     */
    if (in_array($userRole, ['user', 'patient'])) {
        $query->where(['Patients.user_id' => $currentUserId]);
    }

    /**
     * 🔍 SEARCH (ID + NAME + IC)
     */
    if ($id !== '') {
        $query->where(['Patients.id' => (int)$id]);
    }

    if ($name !== '') {
        $query->where(['Patients.fullname LIKE' => "%{$name}%"]);
    }

    if ($ic !== '') {
        $query->where(['Patients.ic LIKE' => "%{$ic}%"]);
    }

    /**
     * 📄 PAGINATION (keeps query string)
     */
    $patients = $this->paginate($query);

    /**
     * 📊 STATISTICS
     */
    $statsBase = $this->Patients->find();

    if (in_array($userRole, ['user', 'patient'])) {
        $statsBase->where(['user_id' => $currentUserId]);
    }

    $total_patients = $statsBase->count();

    $total_patients_active = (clone $statsBase)->where(['status' => 1])->count();
    $total_patients_disabled = (clone $statsBase)->where(['status' => 0])->count();
    $total_patients_archived = (clone $statsBase)->where(['status' => 2])->count();

    /**
     * 📈 MONTHLY CHART
     */
    $monthlyQuery = $this->Patients->find()
        ->select([
            'month' => 'DATE_FORMAT(Patients.created, "%Y-%m")',
            'count' => 'COUNT(*)'
        ]);

    if (in_array($userRole, ['user', 'patient'])) {
        $monthlyQuery->where(['Patients.user_id' => $currentUserId]);
    }

    $monthlyData = $monthlyQuery
        ->group(['month'])
        ->order(['month' => 'ASC'])
        ->limit(12)
        ->toArray();

    $monthArray = [];
    $countArray = [];

    foreach ($monthlyData as $row) {
        $monthArray[] = $row->month;
        $countArray[] = $row->count;
    }

    $this->set(compact(
        'patients',
        'total_patients',
        'total_patients_active',
        'total_patients_disabled',
        'total_patients_archived',
        'monthArray',
        'countArray'
    ));
}


    public function add()
    {
        // Get current user
        $currentUser = $this->request->getAttribute('identity');
        $currentUserId = $currentUser->id ?? null;
        $userRole = $currentUser->role ?? 'user';
        
        $patient = $this->Patients->newEmptyEntity();
        
        if ($this->request->is('post')) {
            // Add current user's ID to the patient data
            $data = $this->request->getData();
            $data['user_id'] = $currentUserId; // Set the user_id to current user
            
            // Set default status to active
            if (!isset($data['status'])) {
                $data['status'] = 1; // Active
            }
            
            $patient = $this->Patients->patchEntity($patient, $data);
            
            if ($this->Patients->save($patient)) {
                $this->Flash->success(__('The patient has been saved.'));
                
                // Redirect based on user role
                if ($userRole === 'admin' || $userRole === 'staff') {
                    return $this->redirect(['action' => 'index']);
                } else {
                    return $this->redirect(['controller' => 'Appointments', 'action' => 'add', '?' => ['patient_id' => $patient->id]]);
                }
            }
            $this->Flash->error(__('The patient could not be saved. Please, try again.'));
        }
        
        // Get users for admin/staff to assign patient to different user
        $users = [];
        if ($userRole === 'admin' || $userRole === 'staff') {
            $users = $this->Patients->Users->find('list', [
                'keyField' => 'id',
                'valueField' => 'fullname'
            ])->toArray();
        }
        
        $this->set(compact('patient', 'users', 'userRole'));
    }

    public function view($id = null)
    {
        $patient = $this->Patients->get($id, [
            'contain' => ['Users', 'Appointments' => ['Doctors', 'Users']],
        ]);
        
        // Check if user has permission to view this patient
        $currentUser = $this->request->getAttribute('identity');
        $currentUserId = $currentUser->id ?? null;
        $userRole = $currentUser->role ?? 'user';
        
        if ($userRole !== 'admin' && $userRole !== 'staff' && $patient->user_id !== $currentUserId) {
            $this->Flash->error(__('You are not authorized to view this patient.'));
            return $this->redirect(['action' => 'index']);
        }
        
        $this->set(compact('patient'));
    }

    public function edit($id = null)
    {
        $patient = $this->Patients->get($id);
        
        // Check if user has permission to edit this patient
        $currentUser = $this->request->getAttribute('identity');
        $currentUserId = $currentUser->id ?? null;
        $userRole = $currentUser->role ?? 'user';
        
        if ($userRole !== 'admin' && $userRole !== 'staff' && $patient->user_id !== $currentUserId) {
            $this->Flash->error(__('You are not authorized to edit this patient.'));
            return $this->redirect(['action' => 'index']);
        }
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            $patient = $this->Patients->patchEntity($patient, $this->request->getData());
            
            // Prevent regular users from changing user_id
            if ($userRole !== 'admin' && $userRole !== 'staff') {
                $patient->user_id = $currentUserId; // Keep the original user_id
            }
            
            if ($this->Patients->save($patient)) {
                $this->Flash->success(__('The patient has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The patient could not be saved. Please, try again.'));
        }
        
        // Get users for admin/staff to reassign patient
        $users = [];
        if ($userRole === 'admin' || $userRole === 'staff') {
            $users = $this->Patients->Users->find('list', [
                'keyField' => 'id',
                'valueField' => 'fullname'
            ])->toArray();
        }
        
        $this->set(compact('patient', 'users', 'userRole'));
    }

    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $patient = $this->Patients->get($id);
        
        // Check if user has permission to delete this patient
        $currentUser = $this->request->getAttribute('identity');
        $currentUserId = $currentUser->id ?? null;
        $userRole = $currentUser->role ?? 'user';
        
        if ($userRole !== 'admin' && $userRole !== 'staff' && $patient->user_id !== $currentUserId) {
            $this->Flash->error(__('You are not authorized to delete this patient.'));
            return $this->redirect(['action' => 'index']);
        }
        
        if ($this->Patients->delete($patient)) {
            $this->Flash->success(__('The patient has been deleted.'));
        } else {
            $this->Flash->error(__('The patient could not be deleted. Please, try again.'));
        }
        
        return $this->redirect(['action' => 'index']);
    }
}