<?php
declare(strict_types=1);

namespace App\Controller;

use App\Controller\AppController;
use App\Model\Entity\Appointment;
use Cake\Event\EventManager;
use Cake\Routing\Router;
use Cake\Http\Exception\ForbiddenException;


/**
 * Appointments Controller (Non-Admin)
 *
 * @property \App\Model\Table\AppointmentsTable $Appointments
 */
class AppointmentsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();

        $this->loadComponent('Search.Search', [
            'actions' => ['index'],
        ]);
    }

    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);
    }

    /**
     * =========================
     * Helpers
     * =========================
     */
    private function getIdentity()
    {
        // CakePHP Authentication: identity at request attribute
        return $this->request->getAttribute('identity');
    }

    private function isAdmin(): bool
    {
        $identity = $this->getIdentity();
        $roleId = (int)($identity->user_group_id ?? 0); // 1 = Admin
        return $roleId === 1;
    }

    /**
     * ✅ Return all patient_ids under this logged-in user
     * patients.user_id = users.id (login)
     */
    private function getMyPatientIds(): array
    {
        $identity = $this->getIdentity();
        if (!$identity) {
            return [];
        }

        $ids = $this->Appointments->Patients->find()
            ->select(['id'])
            ->where(['Patients.user_id' => $identity->id])
            ->enableHydration(false)
            ->all()
            ->extract('id')
            ->toList();

        return array_map('intval', $ids);
    }

    private function requirePatientIds(): array
    {
        $ids = $this->getMyPatientIds();
        if (empty($ids)) {
            throw new ForbiddenException('Your account is not linked to a patient profile.');
        }
        return $ids;
    }

    /**
     * =========================
     * Export APIs
     * =========================
     */
    public function json()
    {
        $this->viewBuilder()->setLayout('json');

        $query = $this->Appointments->find()->contain(['Users', 'Patients', 'Doctors']);

        if (!$this->isAdmin()) {
            $query->where(['Appointments.patient_id IN' => $this->requirePatientIds()]);
        }

        $this->set('appointments', $this->paginate($query));
        $this->viewBuilder()->setOption('serialize', 'appointments');
    }

    public function csv()
    {
        $this->response = $this->response->withDownload('appointments.csv');

        $query = $this->Appointments->find()->contain(['Users', 'Patients', 'Doctors']);
        if (!$this->isAdmin()) {
            $query->where(['Appointments.patient_id IN' => $this->requirePatientIds()]);
        }

        $_serialize = 'appointments';
        $this->viewBuilder()->setClassName('CsvView.Csv');
        $this->set([
            'appointments' => $query,
            '_serialize' => $_serialize
        ]);
    }

    public function pdfList()
    {
        $this->viewBuilder()->enableAutoLayout(false);

        $this->paginate = [
            'contain' => ['Users', 'Patients', 'Doctors'],
            'maxLimit' => 10,
        ];

        $query = $this->Appointments->find()->contain(['Users', 'Patients', 'Doctors']);
        if (!$this->isAdmin()) {
            $query->where(['Appointments.patient_id IN' => $this->requirePatientIds()]);
        }

        $appointments = $this->paginate($query);

        $this->viewBuilder()->setClassName('CakePdf.Pdf');
        $this->viewBuilder()->setOption('pdfConfig', [
            'orientation' => 'portrait',
            'download' => true,
            'filename' => 'appointments_List.pdf'
        ]);

        $this->set(compact('appointments'));
    }

    /**
     * =========================
     * Index
     * =========================
     */
    public function index()
{
    $this->set('title', 'Appointments List');

    // ✅ for dropdown
    $doctors = $this->Appointments->Doctors->find('list', [
        'keyField' => 'id',
        'valueField' => 'fullname', // change to 'name' if your column is name
        'order' => ['Doctors.fullname' => 'ASC']
    ])->toArray();
    $this->set(compact('doctors'));

    $this->paginate = [
        'maxLimit' => 10,
    ];

    $query = $this->Appointments
        ->find()
        ->contain(['Users', 'Patients', 'Doctors']);

    // ✅ Patient/User only see their appointments (even if created by admin)
    if (!$this->isAdmin()) {
        $query->where(['Appointments.patient_id IN' => $this->requirePatientIds()]);
    }

    // =========================
    // ✅ SEARCH FILTERS (GET)
    // =========================
    $no       = trim((string)$this->request->getQuery('no'));
    $doctorId = trim((string)$this->request->getQuery('doctor_id'));
    $date     = trim((string)$this->request->getQuery('date')); // expected Y-m-d

    if ($no !== '') {
        $query->where(['Appointments.id' => (int)$no]);
    }

    if ($doctorId !== '') {
        $query->where(['Appointments.doctor_id' => (int)$doctorId]);
    }

    if ($date !== '') {
        $query->where(['Appointments.date' => $date]);
    }

    $appointments = $this->paginate($query);

    // (your counts code can stay as-is)
    // ...
    $this->set(compact('appointments'));
}


    /**
     * =========================
     * View (permission check)
     * =========================
     */

public function view($id = null)
{
    $this->set('title', 'Appointments Details');

    $appointment = $this->Appointments->get($id, [
        'contain' => ['Users', 'Patients', 'Doctors']
    ]);

    if ($this->isAdmin()) {
        $this->set(compact('appointment'));
        return;
    }

    $myPatientIds = array_map('intval', $this->requirePatientIds());
    $appointmentPatientId = (int)$appointment->patient_id;

    if (!in_array($appointmentPatientId, $myPatientIds, true)) {
        $this->Flash->error("You don't have permission to view this appointment.");
        return $this->redirect(['action' => 'index']);
    }

    $this->set(compact('appointment'));
}


    /**
     * =========================
     * Add
     * =========================
     */
    public function add()
    {
        $this->set('title', 'New Appointments');

        $identity = $this->getIdentity();
        $currentUserId = (int)($identity->id ?? 0);

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) use ($currentUserId) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + [
                    'a_name' => 'Add',
                    'c_name' => 'Appointments',
                    'ip' => $this->request->clientIp(),
                    'url' => Router::url(null, true),
                    'user_id' => $currentUserId,
                ]);
            }
        });

        $appointment = $this->Appointments->newEmptyEntity();

        if ($this->request->is('post')) {

            // ✅ Patient/User: force patient_id based on logged in user
            if (!$this->isAdmin()) {
                $myPatientIds = $this->requirePatientIds();

                // if user has multiple patient profiles, DO NOT force silently
                // we allow them to choose from dropdown, but must be within their own list.
                $postedPatientId = (int)($this->request->getData('patient_id') ?? 0);
                if ($postedPatientId <= 0) {
                    // default first if not provided
                    $this->request = $this->request->withData('patient_id', $myPatientIds[0]);
                } else if (!in_array($postedPatientId, $myPatientIds, true)) {
                    throw new ForbiddenException("Invalid patient selected.");
                }
            }

            
            $appointment = $this->Appointments->patchEntity($appointment, $this->request->getData());
            
             $appointment->status = 1;
             
            if ($this->Appointments->save($appointment)) {
                $this->Flash->success(__('The appointment has been saved.'));
                return $this->redirect(['action' => 'index']);
            }

            $this->Flash->error(__('The appointment could not be saved. Please, try again.'));
        }

        /**
         * Dropdown lists
         * Admin: can select users/patients
         * Patient: only show their patients
         */
        $users = $this->Appointments->Users->find('list', [
            'keyField' => 'id',
            'valueField' => 'fullname',
            'limit' => 200
        ])->all();

        $patientsQ = $this->Appointments->Patients->find('list', [
            'keyField' => 'id',
            'valueField' => 'fullname',
            'limit' => 200
        ]);

        if (!$this->isAdmin()) {
            $patientsQ->where(['Patients.user_id' => $currentUserId]);
        }
        $patients = $patientsQ->all();

        $doctors = $this->Appointments->Doctors->find('list', [
            'keyField' => 'id',
            'valueField' => 'fullname',
            'limit' => 200
        ])->all();

        $statusOptions = Appointment::getStatusOptions();

        $this->set(compact('appointment', 'users', 'patients', 'doctors', 'statusOptions'));
    }

    /**
     * =========================
     * Edit
     * =========================
     */
    public function edit($id = null)
    {
        $this->set('title', 'Appointments Edit');

        $appointment = $this->Appointments->get($id, ['contain' => []]);

        if (!$this->isAdmin()) {
            $myPatientIds = $this->requirePatientIds();
            if (!in_array((int)$appointment->patient_id, $myPatientIds, true)) {
                throw new ForbiddenException("You don't have permission to edit this appointment.");
            }
        }

        if ($this->request->is(['patch', 'post', 'put'])) {

            if (!$this->isAdmin()) {
                $myPatientIds = $this->requirePatientIds();
                $postedPatientId = (int)($this->request->getData('patient_id') ?? 0);

                if ($postedPatientId <= 0) {
                    $this->request = $this->request->withData('patient_id', $appointment->patient_id);
                } else if (!in_array($postedPatientId, $myPatientIds, true)) {
                    throw new ForbiddenException("Invalid patient selected.");
                }
            }

            $appointment = $this->Appointments->patchEntity($appointment, $this->request->getData());

            if ($this->Appointments->save($appointment)) {
                $this->Flash->success(__('The appointment has been saved.'));
                return $this->redirect(['action' => 'index']);
            }

            $this->Flash->error(__('The appointment could not be saved. Please, try again.'));
        }

        $users = $this->Appointments->Users->find('list', ['limit' => 200])->all();

        $patientsQ = $this->Appointments->Patients->find('list', [
            'keyField' => 'id',
            'valueField' => 'fullname',
            'limit' => 200
        ]);
        if (!$this->isAdmin()) {
            $identity = $this->getIdentity();
            $patientsQ->where(['Patients.user_id' => (int)($identity->id ?? 0)]);
        }
        $patients = $patientsQ->all();

        $doctors = $this->Appointments->Doctors->find('list', ['limit' => 200])->all();

        $this->set(compact('appointment', 'users', 'patients', 'doctors'));
    }

    /**
     * =========================
     * Delete
     * =========================
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $appointment = $this->Appointments->get($id);

        if (!$this->isAdmin()) {
            $myPatientIds = $this->requirePatientIds();
            if (!in_array((int)$appointment->patient_id, $myPatientIds, true)) {
                throw new ForbiddenException("You don't have permission to delete this appointment.");
            }
        }

        if ($this->Appointments->delete($appointment)) {
            $this->Flash->success(__('The appointment has been deleted.'));
        } else {
            $this->Flash->error(__('The appointment could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    /**
     * =========================
     * Archived
     * =========================
     */
    public function archived($id = null)
    {
        $appointment = $this->Appointments->get($id, ['contain' => []]);

        if (!$this->isAdmin()) {
            $myPatientIds = $this->requirePatientIds();
            if (!in_array((int)$appointment->patient_id, $myPatientIds, true)) {
                throw new ForbiddenException("You don't have permission to archive this appointment.");
            }
        }

        if ($this->request->is(['patch', 'post', 'put'])) {
            $appointment = $this->Appointments->patchEntity($appointment, $this->request->getData());
            $appointment->status = 2;

            if ($this->Appointments->save($appointment)) {
                $this->Flash->success(__('The appointment has been archived.'));
                return $this->redirect($this->referer());
            }

            $this->Flash->error(__('The appointment could not be archived. Please, try again.'));
        }

        $this->set(compact('appointment'));
    }

    /**
     * =========================
     * Patient-only listing (all patients under same user)
     * =========================
     */
    public function myappointments()
    {
        $myPatientIds = $this->requirePatientIds();

        $this->paginate = [
            'contain' => ['Patients', 'Doctors'],
            'conditions' => ['Appointments.patient_id IN' => $myPatientIds],
            'order' => ['Appointments.created' => 'DESC']
        ];

        $appointments = $this->paginate($this->Appointments);
        $this->set(compact('appointments'));
    }

    /**
     * =========================
     * Doctor-only listing
     * =========================
     */
    public function doctorappointments()
    {
        $identity = $this->getIdentity();
        $currentUserId = (int)($identity->id ?? 0);

        $this->paginate = [
            'contain' => ['Patients'],
            'conditions' => ['Appointments.doctor_id' => $currentUserId],
            'order' => ['Appointments.created' => 'DESC']
        ];

        $appointments = $this->paginate($this->Appointments);
        $this->set(compact('appointments'));
    }

    /**
     * =========================
     * Confirm (patient confirms own appointment)
     * =========================
     */
    public function confirm($id = null)
    {
        $appointment = $this->Appointments->get($id);

        if (!$this->isAdmin()) {
            $myPatientIds = $this->requirePatientIds();
            if (!in_array((int)$appointment->patient_id, $myPatientIds, true)) {
                throw new ForbiddenException('You can only confirm your own appointments.');
            }
        }

        $appointment->status = 2; // adjust if your "Confirmed" value differs
        if ($this->Appointments->save($appointment)) {
            $this->Flash->success(__('Appointment confirmed.'));
        } else {
            $this->Flash->error(__('Unable to confirm appointment.'));
        }

        return $this->redirect(['action' => 'view', $id]);
    }

    /**
     * =========================
     * Cancel (patient cancels own appointment, admin cancels any)
     * =========================
     */
    public function cancel($id = null)
    {
        $appointment = $this->Appointments->get($id);

        if (!$this->isAdmin()) {
            $myPatientIds = $this->requirePatientIds();
            if (!in_array((int)$appointment->patient_id, $myPatientIds, true)) {
                throw new ForbiddenException('You can only cancel your own appointments.');
            }
        }

        $appointment->status = 4; // adjust if your "Cancelled" value differs
        if ($this->Appointments->save($appointment)) {
            $this->Flash->success(__('Appointment cancelled.'));
        } else {
            $this->Flash->error(__('Unable to cancel appointment.'));
        }

        return $this->redirect(['action' => 'view', $id]);
    }
}
