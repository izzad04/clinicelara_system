<?php
declare(strict_types=1);

namespace App\Controller\Admin;

use App\Controller\AppController;
use AuditStash\Meta\RequestMetadata;
use Cake\Event\EventManager;
use Cake\Routing\Router;

class DoctorsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();

        $this->loadComponent('Search.Search', [
            'actions' => ['index'],
        ]);
    }

    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);
    }

    public function json()
    {
        $this->viewBuilder()->setLayout('json');
        $this->set('doctors', $this->paginate());
        $this->viewBuilder()->setOption('serialize', 'doctors');
    }

    public function csv()
    {
        $this->response = $this->response->withDownload('doctors.csv');
        $doctors = $this->Doctors->find();
        $_serialize = 'doctors';

        $this->viewBuilder()->setClassName('CsvView.Csv');
        $this->set(compact('doctors', '_serialize'));
    }

    public function pdfList()
    {
        $this->viewBuilder()->enableAutoLayout(false);
        $doctors = $this->paginate($this->Doctors);

        $this->viewBuilder()->setClassName('CakePdf.Pdf');
        $this->viewBuilder()->setOption('pdfConfig', [
            'orientation' => 'portrait',
            'download' => true,
            'filename' => 'doctors_List.pdf'
        ]);

        $this->set(compact('doctors'));
    }

    public function index()
{
    $this->set('title', 'Doctors List');

    $this->paginate = [
        'maxLimit' => 10,
        'order' => ['Doctors.id' => 'DESC'],
    ];

    // ✅ Search using query params: id + doctor
    $query = $this->Doctors->find('search', search: $this->request->getQueryParams());
    $doctors = $this->paginate($query);

    // count
    $this->set('total_doctors', $this->Doctors->find()->count());
    $this->set('total_doctors_archived', $this->Doctors->find()->where(['status' => 2])->count());
    $this->set('total_doctors_active', $this->Doctors->find()->where(['status' => 1])->count());
    $this->set('total_doctors_disabled', $this->Doctors->find()->where(['status' => 0])->count());

    // charts/month stuff (keep yours if you want)
    $this->set(compact('doctors'));
}


    public function view($id = null)
    {
        $this->set('title', 'Doctors Details');
        $doctor = $this->Doctors->get($id, contain: ['Appointments']);
        $this->set(compact('doctor'));
    }

    public function add()
    {
        $this->set('title', 'New Doctors');

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Add']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Doctors']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $doctor = $this->Doctors->newEmptyEntity();

        if ($this->request->is('post')) {
            $doctor = $this->Doctors->patchEntity($doctor, $this->request->getData());
            if ($this->Doctors->save($doctor)) {
                $this->Flash->success(__('The doctor has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The doctor could not be saved. Please, try again.'));
        }

        $this->set(compact('doctor'));
    }

    public function edit($id = null)
    {
        $this->set('title', 'Doctors Edit');

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Edit']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Doctors']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $doctor = $this->Doctors->get($id, [
            'contain' => [],
        ]);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $doctor = $this->Doctors->patchEntity($doctor, $this->request->getData());
            if ($this->Doctors->save($doctor)) {
                $this->Flash->success(__('The doctor has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The doctor could not be saved. Please, try again.'));
        }

        $this->set(compact('doctor'));
    }

    public function delete($id = null)
    {
        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Delete']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Doctors']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $this->request->allowMethod(['post', 'delete']);

        $doctor = $this->Doctors->get($id);

        if ($this->Doctors->delete($doctor)) {
            $this->Flash->success(__('The doctor has been deleted.'));
        } else {
            $this->Flash->error(__('The doctor could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function archived($id = null)
    {
        $this->set('title', 'Doctors Edit');

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Archived']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Doctors']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $doctor = $this->Doctors->get($id, [
            'contain' => [],
        ]);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $doctor = $this->Doctors->patchEntity($doctor, $this->request->getData());
            $doctor->status = 2; // archived

            if ($this->Doctors->save($doctor)) {
                $this->Flash->success(__('The doctor has been archived.'));
                return $this->redirect($this->referer());
            }

            $this->Flash->error(__('The doctor could not be archived. Please, try again.'));
        }

        $this->set(compact('doctor'));
    }
}
