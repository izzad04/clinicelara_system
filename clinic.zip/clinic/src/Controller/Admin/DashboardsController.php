<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class DashboardsController extends AppController
{
    public function index()
    {
        // Load required models using TableRegistry
        $appointmentsTable = TableRegistry::getTableLocator()->get('Appointments');
        $patientsTable     = TableRegistry::getTableLocator()->get('Patients');
        $doctorsTable      = TableRegistry::getTableLocator()->get('Doctors');
        $usersTable        = TableRegistry::getTableLocator()->get('Users');

        // Get today's date
        $today = date('Y-m-d');

        // 1. TOTAL APPOINTMENTS
        $totalAppointments = $appointmentsTable->find()->count();

        // 2. TOTAL PATIENTS
        $totalPatients = $patientsTable->find()->count();

        // 3. TOTAL DOCTORS
        $totalDoctors = $doctorsTable->find()->count();

        // 4. TOTAL USERS (Admins)
        $totalUsers = $usersTable->find()->count();

        // 5. TODAY'S APPOINTMENTS COUNT
        $todayAppointments = $appointmentsTable->find()
            ->where(['date' => $today])
            ->count();

        // 6. TODAY'S APPOINTMENTS LIST with patient and doctor names
        $todayAppointmentsList = $appointmentsTable->find()
            ->contain(['Patients', 'Doctors'])
            ->where(['date' => $today])
            ->order(['time' => 'ASC'])
            ->limit(10)
            ->toArray();

        // Format today's appointments for display
        $formattedAppointments = [];
        foreach ($todayAppointmentsList as $appointment) {
            // Determine status color
            $statusColor = 'secondary'; // default
            if ($appointment->status == 1) $statusColor = 'success'; // Active
            if ($appointment->status == 2) $statusColor = 'info';    // Completed
            if ($appointment->status == 3) $statusColor = 'danger';  // Cancelled
            if ($appointment->status == 4) $statusColor = 'warning'; // No Show

            // Get status text
            $statusText = 'Active';
            if ($appointment->status == 2) $statusText = 'Completed';
            if ($appointment->status == 3) $statusText = 'Cancelled';
            if ($appointment->status == 4) $statusText = 'No Show';

            $formattedAppointments[] = [
                'time'         => $appointment->time ? date('h:i A', strtotime($appointment->time)) : 'N/A',
                'patient_name' => $appointment->patient ? $appointment->patient->fullname : 'N/A',
                'doctor_name'  => $appointment->doctor ? $appointment->doctor->fullname : 'N/A',
                'status'       => $statusText,
                'status_color' => $statusColor
            ];
        }

        // 7. PENDING APPOINTMENTS (status = 1 for Active)
        $pendingAppointments = $appointmentsTable->find()
            ->where(['status' => 1])
            ->count();

        // ============================
        // CHART DATA (FOR CHART.JS)
        // ============================

        /**
         * Patients status mapping (INTEGER)
         * Change these numbers if your DB uses different values.
         * Example:
         * 1 = Active
         * 2 = Inactive
         * 3 = Archived
         */
        $activePatients = $patientsTable->find()
            ->where(['status' => 1]) // Active
            ->count();

        $inactivePatients = $patientsTable->find()
            ->where(['status' => 2]) // Inactive
            ->count();

        $archivedPatients = $patientsTable->find()
            ->where(['status' => 3]) // Archived
            ->count();

        // Appointments chart (based on your existing status mapping)
        $completedAppointments = $appointmentsTable->find()
            ->where(['status' => 2]) // Completed
            ->count();

        $cancelledAppointments = $appointmentsTable->find()
            ->where(['status' => 3]) // Cancelled
            ->count();

        // Pass all data to view
        $this->set([
            'totalAppointments'      => $totalAppointments,
            'totalPatients'          => $totalPatients,
            'totalDoctors'           => $totalDoctors,
            'totalUsers'             => $totalUsers,
            'todayAppointments'      => $todayAppointments,
            'todayAppointmentsList'  => $formattedAppointments,
            'pendingAppointments'    => $pendingAppointments,
            'todayDate'              => date('F j, Y'),

            // Chart data
            'activePatients'         => $activePatients,
            'inactivePatients'       => $inactivePatients,
            'archivedPatients'       => $archivedPatients,
            'completedAppointments'  => $completedAppointments,
            'cancelledAppointments'  => $cancelledAppointments,
        ]);
    }
}
