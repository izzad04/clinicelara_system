<?php
declare(strict_types=1);

namespace App\Controller\Admin;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{
    public function initialize(): void
    {
        parent::initialize();

        // Use admin layout automatically
        $this->viewBuilder()->setLayout('admin');
    }
}
