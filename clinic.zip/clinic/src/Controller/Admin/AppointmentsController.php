<?php
declare(strict_types=1);

namespace App\Controller\Admin;

use App\Controller\AppController;
use AuditStash\Meta\RequestMetadata;
use Cake\Event\EventManager;
use Cake\Routing\Router;

/**
 * Appointments Controller
 *
 * @property \App\Model\Table\AppointmentsTable $Appointments
 */
class AppointmentsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();

        // Search plugin
        $this->loadComponent('Search.Search', [
            'actions' => ['index'],
        ]);
    }

    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);
    }

    public function json()
    {
        $this->viewBuilder()->setLayout('json');
        $this->set('appointments', $this->paginate());
        $this->viewBuilder()->setOption('serialize', 'appointments');
    }

    public function csv()
    {
        $this->response = $this->response->withDownload('appointments.csv');
        $appointments = $this->Appointments->find();
        $_serialize = 'appointments';

        $this->viewBuilder()->setClassName('CsvView.Csv');
        $this->set(compact('appointments', '_serialize'));
    }

    public function pdfList()
    {
        $this->viewBuilder()->enableAutoLayout(false);
        $this->paginate = [
            'contain' => ['Users', 'Patients', 'Doctors'],
            'maxLimit' => 10,
        ];

        $appointments = $this->paginate($this->Appointments);

        $this->viewBuilder()->setClassName('CakePdf.Pdf');
        $this->viewBuilder()->setOption('pdfConfig', [
            'orientation' => 'portrait',
            'download' => true,
            'filename' => 'appointments_List.pdf'
        ]);

        $this->set(compact('appointments'));
    }

    public function index()
    {
        $this->set('title', 'Appointments List');

        $this->paginate = [
            'maxLimit' => 10,
            'order' => ['Appointments.id' => 'DESC'],
        ];

        /**
         * ✅ SEARCH
         * Works with query params:
         * ?id=12
         * ?patient=ali
         * ?doctor=tan
         * ?patient=ali&doctor=tan
         *
         * IMPORTANT:
         * You must define the searchManager() in AppointmentsTable.php
         * (fields: id, Patients.fullname, Doctors.fullname)
         */
        $searchQuery = $this->Appointments
            ->find('search', search: $this->request->getQueryParams())
            ->contain(['Users', 'Patients', 'Doctors']);

        $appointments = $this->paginate($searchQuery);

        // ============================
        // COUNTS (cards)
        // ============================
        $this->set('total_appointments', $this->Appointments->find()->count());
        $this->set('total_appointments_archived', $this->Appointments->find()->where(['status' => 2])->count());
        $this->set('total_appointments_active', $this->Appointments->find()->where(['status' => 1])->count());
        $this->set('total_appointments_disabled', $this->Appointments->find()->where(['status' => 0])->count());

        // ============================
        // COUNT BY MONTH (your original)
        // ============================
        $this->set('january',   $this->Appointments->find()->where(['MONTH(created)' => 1,  'YEAR(created)' => date('Y')])->count());
        $this->set('february',  $this->Appointments->find()->where(['MONTH(created)' => 2,  'YEAR(created)' => date('Y')])->count());
        $this->set('march',     $this->Appointments->find()->where(['MONTH(created)' => 3,  'YEAR(created)' => date('Y')])->count());
        $this->set('april',     $this->Appointments->find()->where(['MONTH(created)' => 4,  'YEAR(created)' => date('Y')])->count());
        $this->set('may',       $this->Appointments->find()->where(['MONTH(created)' => 5,  'YEAR(created)' => date('Y')])->count());
        $this->set('jun',       $this->Appointments->find()->where(['MONTH(created)' => 6,  'YEAR(created)' => date('Y')])->count());
        $this->set('july',      $this->Appointments->find()->where(['MONTH(created)' => 7,  'YEAR(created)' => date('Y')])->count());
        $this->set('august',    $this->Appointments->find()->where(['MONTH(created)' => 8,  'YEAR(created)' => date('Y')])->count());
        $this->set('september', $this->Appointments->find()->where(['MONTH(created)' => 9,  'YEAR(created)' => date('Y')])->count());
        $this->set('october',   $this->Appointments->find()->where(['MONTH(created)' => 10, 'YEAR(created)' => date('Y')])->count());
        $this->set('november',  $this->Appointments->find()->where(['MONTH(created)' => 11, 'YEAR(created)' => date('Y')])->count());
        $this->set('december',  $this->Appointments->find()->where(['MONTH(created)' => 12, 'YEAR(created)' => date('Y')])->count());

        // ============================
        // REPORT CHART: last 12 months
        // (IMPORTANT: use $chartQuery variable so we don't overwrite search query)
        // ============================
        $chartQuery = $this->Appointments->find();

        $expectedMonths = [];
        for ($i = 11; $i >= 0; $i--) {
            $expectedMonths[] = date('M-Y', strtotime("-$i months"));
        }

        $chartQuery->select([
            'count' => $chartQuery->func()->count('*'),
            'date'  => $chartQuery->func()->date_format(['created' => 'identifier', "%b-%Y"]),
            'month' => 'MONTH(created)',
            'year'  => 'YEAR(created)'
        ])
        ->where([
            'created >=' => date('Y-m-01', strtotime('-11 months')),
            'created <=' => date('Y-m-t')
        ])
        ->groupBy(['year', 'month'])
        ->orderBy(['year' => 'ASC', 'month' => 'ASC']);

        $results = $chartQuery->all()->toArray();

        $totalByMonth = [];
        foreach ($expectedMonths as $expectedMonth) {
            $count = 0;

            foreach ($results as $result) {
                if ($expectedMonth === $result->date) {
                    $count = $result->count;
                    break;
                }
            }

            $totalByMonth[] = [
                'month' => $expectedMonth,
                'count' => $count
            ];
        }

        // data arrays for charts
        $monthArray = [];
        $countArray = [];
        foreach ($totalByMonth as $data) {
            $monthArray[] = $data['month'];
            $countArray[] = $data['count'];
        }

        // ============================
        // SET VARIABLES FOR VIEW
        // ============================
        $this->set([
            'results' => $totalByMonth,
            '_serialize' => ['results']
        ]);

        $this->set(compact('appointments', 'monthArray', 'countArray'));
    }

    public function view($id = null)
    {
        $this->set('title', 'Appointments Details');
        $appointment = $this->Appointments->get($id, contain: ['Users', 'Patients', 'Doctors']);
        $this->set(compact('appointment'));
    }

    /**
     * ✅ AJAX: get patients by selected user
     * URL: /admin/appointments/patients-by-user/{userId}
     */
    public function patientsByUser($userId = null)
    {
        $this->request->allowMethod(['get']);

        $userId = (int)$userId;

        if ($userId <= 0) {
            $payload = ['patients' => []];
            return $this->response
                ->withType('application/json')
                ->withStringBody(json_encode($payload));
        }

        $patients = $this->Appointments->Patients->find('list', [
                'keyField' => 'id',
                'valueField' => 'fullname',
            ])
            ->where(['Patients.user_id' => $userId])
            ->orderBy(['Patients.fullname' => 'ASC'])
            ->toArray();

        $payload = ['patients' => $patients];

        return $this->response
            ->withType('application/json')
            ->withStringBody(json_encode($payload));
    }

    public function add()
    {
        $this->set('title', 'New Appointments');

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Add']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Appointments']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $appointment = $this->Appointments->newEmptyEntity();

        if ($this->request->is('post')) {
            $appointment = $this->Appointments->patchEntity($appointment, $this->request->getData());
            if ($this->Appointments->save($appointment)) {
                $this->Flash->success(__('The appointment has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The appointment could not be saved. Please, try again.'));
        }

        $users = $this->Appointments->Users->find('list', [
            'keyField' => 'id',
            'valueField' => 'fullname',
            'limit' => 200
        ])->order(['fullname' => 'ASC'])->all();

        // Start empty - loaded by AJAX after choose user
        $patients = [];

        $doctors = $this->Appointments->Doctors->find('list', ['limit' => 200])->all();

        $this->set(compact('appointment', 'users', 'patients', 'doctors'));
    }

    public function edit($id = null)
    {
        $this->set('title', 'Appointments Edit');

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Edit']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Appointments']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $appointment = $this->Appointments->get($id, [
            'contain' => [],
        ]);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $appointment = $this->Appointments->patchEntity($appointment, $this->request->getData());
            if ($this->Appointments->save($appointment)) {
                $this->Flash->success(__('The appointment has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The appointment could not be saved. Please, try again.'));
        }

        $users = $this->Appointments->Users->find('list', [
            'keyField' => 'id',
            'valueField' => 'fullname',
            'limit' => 200
        ])->order(['fullname' => 'ASC'])->all();

        // For edit: load patients for existing user_id so dropdown shows current patient
        $patients = [];
        if (!empty($appointment->user_id)) {
            $patients = $this->Appointments->Patients->find('list', [
                    'keyField' => 'id',
                    'valueField' => 'fullname',
                    'limit' => 200
                ])
                ->where(['Patients.user_id' => $appointment->user_id])
                ->orderBy(['Patients.fullname' => 'ASC'])
                ->all();
        }

        $doctors = $this->Appointments->Doctors->find('list', ['limit' => 200])->all();

        $this->set(compact('appointment', 'users', 'patients', 'doctors'));
    }

    public function delete($id = null)
    {
        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Delete']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Appointments']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $this->request->allowMethod(['post', 'delete']);
        $appointment = $this->Appointments->get($id);

        if ($this->Appointments->delete($appointment)) {
            $this->Flash->success(__('The appointment has been deleted.'));
        } else {
            $this->Flash->error(__('The appointment could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function archived($id = null)
    {
        $this->set('title', 'Appointments Edit');

        EventManager::instance()->on('AuditStash.beforeLog', function ($event, array $logs) {
            foreach ($logs as $log) {
                $log->setMetaInfo($log->getMetaInfo() + ['a_name' => 'Archived']);
                $log->setMetaInfo($log->getMetaInfo() + ['c_name' => 'Appointments']);
                $log->setMetaInfo($log->getMetaInfo() + ['ip' => $this->request->clientIp()]);
                $log->setMetaInfo($log->getMetaInfo() + ['url' => Router::url(null, true)]);
                $log->setMetaInfo($log->getMetaInfo() + ['slug' => $this->Authentication->getIdentity('slug')->getIdentifier('slug')]);
            }
        });

        $appointment = $this->Appointments->get($id, [
            'contain' => [],
        ]);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $appointment = $this->Appointments->patchEntity($appointment, $this->request->getData());
            $appointment->status = 2; // archived
            if ($this->Appointments->save($appointment)) {
                $this->Flash->success(__('The appointment has been archived.'));
                return $this->redirect($this->referer());
            }
            $this->Flash->error(__('The appointment could not be archived. Please, try again.'));
        }

        $this->set(compact('appointment'));
    }
}
