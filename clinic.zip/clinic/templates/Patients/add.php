<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Patient $patient
 */

// Load required CSS/JS
echo $this->Html->css('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css');
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxMwy2scQbITxI"
        crossorigin="anonymous"></script>

<style>
/* Patient Add Form Specific Styles */
:root {
    --primary-color: #A53860;
    --primary-light: rgba(165, 56, 96, 0.08);
    --secondary-color: #6c757d;
    --active-color: #28a745;
    --inactive-color: #6c757d;
    --archived-color: #ffc107;
}

.patient-form-wrapper {
    background: linear-gradient(135deg, #f8f9fa 0%, #f5f5f5 100%);
    padding: 20px;
}

.page-title {
    color: var(--primary-color);
    font-weight: 700;
    font-size: 2rem;
}

.patient-form-card {
    border-radius: 16px;
    border: 1px solid rgba(0,0,0,0.05);
    overflow: hidden;
}

.patient-form-card .card-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, #C44569 100%);
    padding: 25px 30px;
    border-bottom: none;
}

.patient-form-card .form-icon {
    width: 60px;
    height: 60px;
    background: rgba(255,255,255,0.2);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.patient-form .form-label {
    font-size: 0.95rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #495057;
}

.patient-form .form-control-lg,
.patient-form .form-select-lg {
    padding: 0.75rem 1rem;
    font-size: 1rem;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.patient-form .form-control-lg:focus,
.patient-form .form-select-lg:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(165, 56, 96, 0.15);
    outline: none;
}

.patient-form .form-section-title {
    color: var(--primary-color);
    font-size: 1.1rem;
    font-weight: 600;
    padding-bottom: 0.75rem;
    border-bottom: 2px solid rgba(165, 56, 96, 0.1);
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.patient-form .form-text {
    font-size: 0.85rem;
    color: #6c757d;
    margin-top: 6px;
}

/* Input formatting */
.ic-input, .phone-input {
    font-family: 'Courier New', monospace;
    letter-spacing: 1px;
}

/* ===== FORM ACTIONS (BOTTOM BUTTONS) ===== */
.form-actions .actions-row{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
    flex-wrap:wrap;
}

.form-actions .right-actions{
    margin-left:auto;               
    display:flex;
    gap:18px;                        
    align-items:center;
    justify-content:flex-end;
}

@media (max-width: 768px){
    .form-actions .actions-row{
        flex-direction:column;
        align-items:stretch;
    }
    .form-actions .right-actions{
        margin-left:0;
        width:100%;
        flex-direction:column;
        gap:12px;
    }
    .form-actions .right-actions .btn,
    .form-actions .left-actions .btn{
        width:100%;
        justify-content:center;
    }
}

/* header back button spacing like admin */
.header-actions .btn{
    border-radius: 10px;
    padding: 8px 12px;
}
</style>

<div class="admin-wrapper">
    <!-- SIDEBAR (same as admin style) -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Patient Portal</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar" type="button">
                <i class="fas fa-times"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <button class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar" type="button">
                    <i class="fas fa-bars fs-4"></i>
                </button>
                <h5 class="m-0 d-none d-md-block">Add New Patient</h5>
                <h5 class="m-0 d-md-none">New Patient</h5>
            </div>

            <div class="header-actions d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT -->
        <main class="content-area">
            <div class="patient-form-wrapper">
                <!-- Form Card -->
                <div class="card patient-form-card shadow-lg">
                    <div class="card-header text-white">
                        <div class="d-flex align-items-center">
                            <div class="form-icon me-3">
                                <i class="fa-solid fa-user-plus fa-2x"></i>
                            </div>
                            <div>
                                <h4 class="mb-0">Patient Information</h4>
                                <small>Fill in all required patient details</small>
                            </div>
                        </div>
                    </div>

                    <div class="card-body p-4 p-lg-5">
                        <?= $this->Form->create($patient, [
                            'id' => 'patient-add-form',
                            'class' => 'patient-form',
                            'novalidate' => true
                        ]) ?>

                        <?= $this->Form->hidden('status', ['value' => 1]) ?>

                        <div class="row g-4">
                            <div class="col-12">
                                <h5 class="form-section-title">
                                    <i class="fa-solid fa-id-card me-2"></i>
                                    Personal Information
                                </h5>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('fullname', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'Enter patient full name',
                                        'required' => true,
                                        'tabindex' => 1
                                    ]) ?>
                                    <div class="form-text">Legal name as per identification</div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">IC Number <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('ic', [
                                        'class' => 'form-control form-control-lg ic-input',
                                        'label' => false,
                                        'placeholder' => 'e.g., 900101-01-1234',
                                        'required' => true,
                                        'maxlength' => 14,
                                        'tabindex' => 2
                                    ]) ?>
                                    <div class="form-text">Format: 900101-01-1234</div>
                                </div>
                            </div>

                            <div class="col-12 mt-4">
                                <h5 class="form-section-title">
                                    <i class="fa-solid fa-address-book me-2"></i>
                                    Contact Information
                                </h5>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('phone', [
                                        'class' => 'form-control form-control-lg phone-input',
                                        'label' => false,
                                        'placeholder' => 'e.g., 012-3456789',
                                        'required' => true,
                                        'type' => 'tel',
                                        'tabindex' => 3
                                    ]) ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Email Address</label>
                                    <?= $this->Form->control('email', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'patient@example.com',
                                        'type' => 'email',
                                        'tabindex' => 4
                                    ]) ?>
                                </div>
                            </div>

                            <div class="col-12 mt-4">
                                <h5 class="form-section-title">
                                    <i class="fa-solid fa-location-dot me-2"></i>
                                    Address Information
                                </h5>
                            </div>

                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-label">Street Address 1 <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('street1', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'House number, street name',
                                        'required' => true,
                                        'tabindex' => 5
                                    ]) ?>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-label">Street Address 2</label>
                                    <?= $this->Form->control('street2', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'Apartment, suite, unit, building, floor, etc.',
                                        'tabindex' => 6
                                    ]) ?>
                                    <div class="form-text">Optional additional address information</div>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="form-label">Postcode <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('postcode', [
                                        'class' => 'form-control form-control-lg postcode-input',
                                        'label' => false,
                                        'placeholder' => 'e.g., 50000',
                                        'required' => true,
                                        'maxlength' => 5,
                                        'tabindex' => 7
                                    ]) ?>
                                </div>
                            </div>

                            <div class="col-md-5">
                                <div class="form-group">
                                    <label class="form-label">City <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('city', [
                                        'class' => 'form-control form-control-lg city-input',
                                        'label' => false,
                                        'placeholder' => 'City name',
                                        'required' => true,
                                        'tabindex' => 8
                                    ]) ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">State <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('state', [
                                        'class' => 'form-select form-control-lg',
                                        'label' => false,
                                        'required' => true,
                                        'options' => [
                                            'JOHOR' => 'Johor',
                                            'KEDAH' => 'Kedah',
                                            'KELANTAN' => 'Kelantan',
                                            'MELAKA' => 'Melaka',
                                            'NEGERI SEMBILAN' => 'Negeri Sembilan',
                                            'PAHANG' => 'Pahang',
                                            'PENANG' => 'Penang',
                                            'PERAK' => 'Perak',
                                            'PERLIS' => 'Perlis',
                                            'SABAH' => 'Sabah',
                                            'SARAWAK' => 'Sarawak',
                                            'SELANGOR' => 'Selangor',
                                            'TERENGGANU' => 'Terengganu',
                                            'KUALA LUMPUR' => 'Kuala Lumpur',
                                            'LABUAN' => 'Labuan',
                                            'PUTRAJAYA' => 'Putrajaya'
                                        ],
                                        'empty' => '-- Select State --',
                                        'tabindex' => 9
                                    ]) ?>
                                </div>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="form-actions mt-5 pt-4 border-top">
                            <div class="actions-row">
                                <div class="left-actions">
                                            <?= $this->Html->link(
                                                '<i class="bi bi-x-circle me-2"></i> Cancel',
                                                ['action' => 'view', $patient->id],
                                                ['class' => 'btn btn-outline-secondary btn-lg', 'escape' => false]
                                            ) ?>
                                </div>

                                <div class="right-actions">
                                    <?= $this->Form->button(
                                        '<i class="fa-solid fa-rotate-right me-2"></i> Clear Form',
                                        [
                                            'type' => 'reset',
                                            'class' => 'btn btn-outline-warning btn-lg',
                                            'tabindex' => 11,
                                            'escapeTitle' => false
                                        ]
                                    ) ?>

                                    <?= $this->Form->button(
                                        '<i class="fa-solid fa-user-plus me-2"></i> Add Patient',
                                        [
                                            'type' => 'submit',
                                            'class' => 'btn btn-primary btn-lg px-5',
                                            'tabindex' => 10,
                                            'escapeTitle' => false,
                                            'style' => '
                                                    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
                                                    border: none;
                                                    border-radius: 10px;
                                                    padding: 10px 18px;
                                                    box-shadow: 0 4px 12px rgba(165, 56, 96, 0.28);
                                                ',
                                            'id' => 'submitBtn'
                                        ]
                                    ) ?>
                                </div>
                            </div>
                        </div>

                        <?= $this->Form->end() ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Sidebar toggle like admin
    const toggleBtn = document.getElementById("toggleSidebar");
    const closeBtn  = document.getElementById("closeSidebar");
    const sidebar   = document.getElementById("sidebar");
    const mainContent = document.querySelector(".main-content");

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener("click", function() {
            sidebar.classList.toggle("hide");
            mainContent.classList.toggle("expanded");
        });
    }
    if (closeBtn && sidebar) {
        closeBtn.addEventListener("click", function() {
            sidebar.classList.add("hide");
            mainContent.classList.add("expanded");
        });
    }

    // IC formatting
    const icInput = document.querySelector(".ic-input");
    if (icInput) {
        icInput.addEventListener("input", function(e) {
            let value = e.target.value.replace(/[^0-9]/g, "");
            if (value.length > 6) value = value.substring(0, 6) + "-" + value.substring(6);
            if (value.length > 9) value = value.substring(0, 9) + "-" + value.substring(9);
            if (value.length > 14) value = value.substring(0, 14);
            e.target.value = value;
        });
    }

    // Phone formatting
    const phoneInput = document.querySelector(".phone-input");
    if (phoneInput) {
        phoneInput.addEventListener("input", function(e) {
            let value = e.target.value.replace(/[^0-9]/g, "");
            if (value.length > 3) value = value.substring(0, 3) + "-" + value.substring(3);
            if (value.length > 7) value = value.substring(0, 7) + "-" + value.substring(7);
            if (value.length > 12) value = value.substring(0, 12);
            e.target.value = value;
        });
    }

    // Postcode numeric only
    const postcodeInput = document.querySelector(".postcode-input");
    if (postcodeInput) {
        postcodeInput.addEventListener("input", function(e) {
            e.target.value = e.target.value.replace(/[^0-9]/g, "").slice(0, 5);
        });
    }

    // City uppercase
    const cityInput = document.querySelector(".city-input");
    if (cityInput) {
        cityInput.addEventListener("blur", function() {
            this.value = this.value.toUpperCase();
        });
    }

    // Name capitalize
    const nameInput = document.querySelector("[name='fullname']");
    if (nameInput) {
        nameInput.addEventListener("blur", function() {
            this.value = this.value.replace(/\b\w/g, function(char) {
                return char.toUpperCase();
            });
        });
    }
});
</script>
