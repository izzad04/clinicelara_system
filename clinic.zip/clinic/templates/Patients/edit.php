<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Patient $patient
 */

// Load required CSS/JS
echo $this->Html->css('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css');
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxMwy2scQbITxI" crossorigin="anonymous"></script>

<style>
/* Patient Edit Form Specific Styles */
:root {
    --primary-color: #A53860;
    --primary-light: rgba(165, 56, 96, 0.08);
    --secondary-color: #6c757d;
    --active-color: #28a745;
    --inactive-color: #6c757d;
    --archived-color: #ffc107;
}

.patient-edit-form .form-label {
    font-size: 0.95rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #495057;
}

.patient-edit-form .form-control-lg,
.patient-edit-form .form-select-lg {
    padding: 0.75rem 1rem;
    font-size: 1rem;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.patient-edit-form .form-control-lg:focus,
.patient-edit-form .form-select-lg:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(165, 56, 96, 0.15);
    outline: none;
}

.patient-edit-form .section-title {
    color: var(--primary-color);
    font-size: 1.1rem;
    font-weight: 600;
    padding-bottom: 0.75rem;
    border-bottom: 2px solid rgba(165, 56, 96, 0.1);
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.patient-edit-form .edit-icon {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, rgba(165, 56, 96, 0.1) 0%, rgba(248, 182, 200, 0.1) 100%);
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
}

.patient-edit-form .btn-lg {
    padding: 0.75rem 1.75rem;
    font-size: 1rem;
    border-radius: 10px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.patient-edit-form .btn-primary {
    background: linear-gradient(135deg, var(--primary-color) 0%, #C44569 100%);
    border: none;
}

.patient-edit-form .btn-primary:hover {
    background: linear-gradient(135deg, #8c2e4f 0%, #a53758 100%);
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(165, 56, 96, 0.3);
}

.patient-edit-form .form-text {
    font-size: 0.85rem;
    color: #6c757d;
    margin-top: 6px;
}

/* Status Badge Styles */
.status-badge {
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.status-badge.active {
    background-color: rgba(40, 167, 69, 0.15);
    color: var(--active-color);
    border: 1px solid rgba(40, 167, 69, 0.3);
}
.status-badge.inactive {
    background-color: rgba(108, 117, 125, 0.15);
    color: var(--inactive-color);
    border: 1px solid rgba(108, 117, 125, 0.3);
}
.status-badge.archived {
    background-color: rgba(255, 193, 7, 0.15);
    color: var(--archived-color);
    border: 1px solid rgba(255, 193, 7, 0.3);
}

/* Input formatting */
.ic-input, .phone-input {
    font-family: 'Courier New', monospace;
    letter-spacing: 1px;
}

/* Read-only fields */
.bg-light {
    background-color: #f8f9fa !important;
    color: #6c757d;
    cursor: not-allowed;
}

/* Card styling */
.card-modern {
    background: white;
    border-radius: 16px;
    padding: 30px;
    margin: 20px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.08);
    border: 1px solid rgba(0,0,0,0.05);
}
.card-header-bg {
    background: linear-gradient(135deg, var(--primary-light) 0%, rgba(248, 182, 200, 0.1) 100%);
    border-bottom: 2px solid rgba(165, 56, 96, 0.1);
}

/* Toast Notification */
.toast-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    min-width: 300px;
    opacity: 0;
    transform: translateX(100%);
    transition: all 0.5s ease;
}
.toast-notification.show {
    opacity: 1;
    transform: translateX(0);
}

/* Success Modal */
.modal-success {
    background: rgba(0, 0, 0, 0.5);
}
.modal-success .modal-dialog {
    max-width: 420px;
}
.modal-success .modal-content {
    border-radius: 16px;
    overflow: hidden;
    border: none;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
}
.modal-success .modal-header {
    background: linear-gradient(135deg, var(--active-color) 0%, #34ce57 100%);
    color: white;
    border: none;
    padding: 20px 24px;
}
.modal-success .modal-body {
    padding: 26px;
    text-align: center;
}
.modal-success .modal-footer {
    border: none;
    padding: 18px 26px 26px;
    justify-content: center;
}

.success-icon {
    width: 84px;
    height: 84px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 18px;
    border: 4px solid var(--active-color);
}
.success-icon i {
    font-size: 2.5rem;
    color: var(--active-color);
}
.archived-icon {
    border-color: var(--archived-color);
}
.archived-icon i {
    color: var(--archived-color);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .card-modern {
        margin: 10px;
        padding: 20px;
    }
    .patient-edit-form .btn-lg {
        width: 100%;
        justify-content: center;
    }
    .toast-notification {
        left: 10px;
        right: 10px;
        top: 10px;
        min-width: auto;
    }
}
</style>

<!-- Toast Notification Template -->
<div id="successToast" class="toast-notification" style="display:none;">
    <div class="alert alert-success alert-dismissible fade show shadow-lg" role="alert">
        <div class="d-flex align-items-center">
            <i class="fas fa-check-circle fs-4 me-3"></i>
            <div>
                <h5 class="alert-heading mb-1">Success!</h5>
                <p class="mb-0">Patient information has been updated successfully.</p>
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</div>

<!-- ✅ Success Modal (added because your JS uses it) -->
<div class="modal modal-success fade" id="successModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-check-circle me-2"></i>Saved</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="success-icon" id="successIcon">
                    <i class="fas fa-save"></i>
                </div>
                <h4 class="fw-bold mb-2" id="successTitle">Saved Successfully!</h4>
                <p class="text-muted mb-0" id="successMessage">Patient information has been updated.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary px-4" data-bs-dismiss="modal">
                    <i class="fas fa-thumbs-up me-2"></i> OK
                </button>
            </div>
        </div>
    </div>
</div>

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width:120px;height:120px;">
                <?= $this->Html->image('logo.png', ['alt'=>'Elara Clinic Logo','class'=>'logo-img']) ?>
            </div>
            <h5 class="fw-bold" style="color:#A53860;font-size:1.3rem;">Elara Medical Clinic</h5>
            <small class="text-muted">Patient Portal</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar" type="button">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- ✅ HEADER with buttons like others -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="fas fa-bars fs-4"></i>
                </span>
                <div class="d-flex flex-column">
                    <h5 class="m-0 d-none d-md-block">Edit Patient: <?= h($patient->fullname) ?></h5>
                    <h5 class="m-0 d-md-none">Edit Patient</h5>
                    <small class="text-white-50 d-none d-md-block">Update patient details and status</small>
                </div>
            </div>

            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="fas fa-arrow-left me-2"></i> Back',
                    ['controller'=>'Patients','action'=>'Index', $patient->id],
                    ['class'=>'btn btn-outline-light btn-sm', 'escape'=>false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <div class="row justify-content-center">
                <div class="col-xxl-10 col-xl-11">
                    <div class="card-modern patient-edit-form">
                        <div class="card-header-bg p-4 border-bottom">
                            <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
                                <div class="d-flex align-items-center">
                                    <div class="edit-icon me-4">
                                        <i class="fas fa-user-edit fs-2" style="color:#A53860;"></i>
                                    </div>
                                    <div>
                                        <h3 class="mb-1 fw-bold" style="color:#2c3e50;">Edit Patient Information</h3>
                                        <p class="text-muted mb-0">Update the details for patient #<?= $this->Number->format($patient->id) ?></p>
                                    </div>
                                </div>

                                <div class="d-none d-md-block text-end">
                                    <span class="badge bg-primary px-3 py-2 fs-6">
                                        <i class="fas fa-id-card me-2"></i>ID: <?= $this->Number->format($patient->id) ?>
                                    </span>

                                    <?php
                                    $statusClass = 'inactive';
                                    $statusText  = 'Inactive';
                                    if ((int)$patient->status === 1) {
                                        $statusClass = 'active';
                                        $statusText  = 'Active';
                                    } elseif ((int)$patient->status === 2) {
                                        $statusClass = 'archived';
                                        $statusText  = 'Archived';
                                    }
                                    ?>
                                    <span class="status-badge <?= h($statusClass) ?> ms-2">
                                        <i class="fas fa-circle fa-xs"></i> <?= h($statusText) ?>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="card-body p-4 p-lg-5">
                            <?= $this->Form->create($patient, [
                                'class' => 'patient-form',
                                'id' => 'patientEditForm',
                                'type' => 'post'
                            ]) ?>

                            <div class="row g-4">
                                <!-- Personal Information -->
                                <div class="col-12 mb-4">
                                    <h5 class="section-title">
                                        <i class="fas fa-id-card fs-5"></i>
                                        Personal Information
                                    </h5>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('fullname', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'Enter full name',
                                        'required' => true
                                    ]) ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">IC Number <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('ic', [
                                        'class' => 'form-control form-control-lg ic-input',
                                        'label' => false,
                                        'placeholder' => '900101-01-1234',
                                        'required' => true
                                    ]) ?>
                                </div>

                                <!-- Status Information -->
                                <div class="col-12 mt-5 mb-4">
                                    <h5 class="section-title">
                                        <i class="fas fa-chart-line fs-5"></i>
                                        Account Status
                                    </h5>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Patient Status <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('status', [
                                        'class' => 'form-select form-control-lg',
                                        'label' => false,
                                        'options' => [
                                            1 => 'Active - Patient is currently active and can book appointments',
                                            0 => 'Inactive - Patient account is temporarily disabled',
                                            2 => 'Archived - Patient record is archived (read-only)'
                                        ],
                                        'required' => true
                                    ]) ?>
                                    <div class="form-text">
                                        <ul class="list-unstyled mt-2">
                                            <li><span class="text-success">● Active:</span> Can book appointments and receive notifications</li>
                                            <li><span class="text-secondary">● Inactive:</span> Cannot book appointments, but record remains</li>
                                            <li><span class="text-warning">● Archived:</span> Historical record, cannot be modified</li>
                                        </ul>
                                    </div>
                                </div>

                                <!-- Contact Information -->
                                <div class="col-12 mt-5 mb-4">
                                    <h5 class="section-title">
                                        <i class="fas fa-address-book fs-5"></i>
                                        Contact Information
                                    </h5>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('phone', [
                                        'class' => 'form-control form-control-lg phone-input',
                                        'label' => false,
                                        'placeholder' => '012-345-6789',
                                        'required' => true
                                    ]) ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Email Address</label>
                                    <?= $this->Form->control('email', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'patient@example.com',
                                        'type' => 'email'
                                    ]) ?>
                                </div>

                                <!-- Address Information -->
                                <div class="col-12 mt-5 mb-4">
                                    <h5 class="section-title">
                                        <i class="fas fa-location-dot fs-5"></i>
                                        Address Information
                                    </h5>
                                </div>

                                <div class="col-12">
                                    <label class="form-label">Street Address 1 <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('street1', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'House number, street name',
                                        'required' => true
                                    ]) ?>
                                </div>

                                <div class="col-12">
                                    <label class="form-label">Street Address 2</label>
                                    <?= $this->Form->control('street2', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'Apartment, suite, unit, building, floor, etc.'
                                    ]) ?>
                                </div>

                                <div class="col-md-3">
                                    <label class="form-label">Postcode <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('postcode', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => '50000',
                                        'required' => true
                                    ]) ?>
                                </div>

                                <div class="col-md-5">
                                    <label class="form-label">City <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('city', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'City name',
                                        'required' => true
                                    ]) ?>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label">State <span class="text-danger">*</span></label>
                                    <?= $this->Form->control('state', [
                                        'class' => 'form-select form-control-lg',
                                        'label' => false,
                                        'options' => [
                                            'JOHOR' => 'Johor',
                                            'KEDAH' => 'Kedah',
                                            'KELANTAN' => 'Kelantan',
                                            'MELAKA' => 'Melaka',
                                            'NEGERI SEMBILAN' => 'Negeri Sembilan',
                                            'PAHANG' => 'Pahang',
                                            'PENANG' => 'Penang',
                                            'PERAK' => 'Perak',
                                            'PERLIS' => 'Perlis',
                                            'SABAH' => 'Sabah',
                                            'SARAWAK' => 'Sarawak',
                                            'SELANGOR' => 'Selangor',
                                            'TERENGGANU' => 'Terengganu',
                                            'KUALA LUMPUR' => 'Kuala Lumpur',
                                            'LABUAN' => 'Labuan',
                                            'PUTRAJAYA' => 'Putrajaya'
                                        ],
                                        'empty' => '-- Select State --',
                                        'required' => true
                                    ]) ?>
                                </div>

                                <!-- System Info -->
                                <div class="col-12 mt-5 mb-4">
                                    <h5 class="section-title">
                                        <i class="fas fa-clock-rotate-left fs-5"></i>
                                        System Information
                                    </h5>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Created On</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-0">
                                            <i class="fas fa-calendar-plus text-muted"></i>
                                        </span>
                                        <input type="text" class="form-control form-control-lg bg-light"
                                               value="<?= $patient->created->format('F j, Y h:i A') ?>" readonly>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Last Modified</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-0">
                                            <i class="fas fa-clock text-muted"></i>
                                        </span>
                                        <input type="text" class="form-control form-control-lg bg-light"
                                               value="<?= $patient->modified->format('F j, Y h:i A') ?>" readonly>
                                    </div>
                                </div>
                            </div>

                            <!-- ✅ Form Actions (Cancel only on left) -->
                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mt-5 pt-4 border-top">
                                <div>
                                    <?= $this->Html->link(
                                        '<i class="fas fa-times-circle me-2"></i> Cancel',
                                        ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'view', $patient->id],
                                        ['class' => 'btn btn-lg btn-outline-secondary', 'escape' => false]
                                    ) ?>
                                </div>

                                <div class="d-flex gap-3 flex-wrap">
                                    <?= $this->Form->button(
                                        '<i class="fas fa-redo me-2"></i> Reset Form',
                                        [
                                            'type' => 'reset',
                                            'class' => 'btn btn-lg btn-outline-warning',
                                            'escapeTitle' => false
                                        ]
                                    ) ?>

                                    <?= $this->Form->button(
                                        '<i class="fas fa-save me-2"></i> Save Changes',
                                        [
                                            'type' => 'submit',
                                            'class' => 'btn btn-lg btn-primary',
                                            'escapeTitle' => false,
                                            'id' => 'submitBtn'
                                        ]
                                    ) ?>
                                </div>
                            </div>

                            <?= $this->Form->end() ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const toggleBtn = document.getElementById('toggleSidebar');
    const sidebar   = document.getElementById('sidebar');
    const closeBtn  = document.getElementById('closeSidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar)  closeBtn.onclick  = () => sidebar.classList.add('hide');

    const patientName = <?= json_encode($patient->fullname ?? 'Patient') ?>;

    // IC formatting
    const icInput = document.querySelector('.ic-input');
    if (icInput) {
        icInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            if (value.length > 6) value = value.substring(0, 6) + '-' + value.substring(6);
            if (value.length > 9) value = value.substring(0, 9) + '-' + value.substring(9);
            if (value.length > 14) value = value.substring(0, 14);
            e.target.value = value;
        });
    }

    // Phone formatting
    const phoneInput = document.querySelector('.phone-input');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            if (value.length > 3) value = value.substring(0, 3) + '-' + value.substring(3);
            if (value.length > 7) value = value.substring(0, 7) + '-' + value.substring(7);
            if (value.length > 12) value = value.substring(0, 12);
            e.target.value = value;
        });
    }

    // Auto-capitalize name
    const nameInput = document.querySelector('[name="fullname"]');
    if (nameInput) {
        nameInput.addEventListener('blur', function() {
            this.value = this.value.replace(/\b\w/g, (char) => char.toUpperCase());
        });
    }

    // Auto-capitalize city
    const cityInput = document.querySelector('[name="city"]');
    if (cityInput) {
        cityInput.addEventListener('blur', function() {
            this.value = this.value.toUpperCase();
        });
    }

    // Status badge update
    const statusSelect = document.querySelector('[name="status"]');
    const originalStatus = String(<?= (int)$patient->status ?>);

    function updateStatusDisplay() {
        if (!statusSelect) return;
        const v = String(statusSelect.value);

        let text = 'Inactive';
        let cls  = 'inactive';
        if (v === '1') { text = 'Active'; cls = 'active'; }
        else if (v === '2') { text = 'Archived'; cls = 'archived'; }

        const badge = document.querySelector('.status-badge');
        if (badge) {
            badge.className = 'status-badge ' + cls;
            badge.innerHTML = `<i class="fas fa-circle fa-xs"></i> ${text}`;
        }
    }

    if (statusSelect) {
        updateStatusDisplay();
        statusSelect.addEventListener('change', function() {
            if (String(this.value) === '2') {
                const confirmed = confirm(
                    'Are you sure you want to archive this patient?\n\nArchived patients:\n• Cannot book new appointments\n• Cannot be modified\n• Will be moved to historical records\n\nYou can reverse this by changing status back to Active.'
                );
                if (!confirmed) {
                    this.value = originalStatus;
                }
            }
            updateStatusDisplay();
        });
    }

    // Simple validation + loading state
    const form = document.getElementById('patientEditForm');
    const submitBtn = document.getElementById('submitBtn');

    if (form && submitBtn) {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            const requiredFields = form.querySelectorAll('[required]');

            requiredFields.forEach(field => {
                if (!field.value || !field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            if (!isValid) {
                e.preventDefault();
                showErrorNotification('Please fill in all required fields marked with *');
                return false;
            }

            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Saving...';
            submitBtn.disabled = true;
            return true;
        });

        form.addEventListener('input', function(e) {
            if (e.target && e.target.classList) e.target.classList.remove('is-invalid');
        });

        // If you redirect back with ?success=1&status=...
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('success')) {
            const st = urlParams.get('status') || originalStatus;
            showSuccessModal(st);
        }
    }

    function showSuccessModal(status) {
        const modalEl = document.getElementById('successModal');
        if (!modalEl) return;

        const modal = new bootstrap.Modal(modalEl);
        const successIcon = document.getElementById('successIcon');
        const successTitle = document.getElementById('successTitle');
        const successMessage = document.getElementById('successMessage');
        const header = modalEl.querySelector('.modal-header');

        if (String(status) === '2') {
            successIcon.className = 'success-icon archived-icon';
            successIcon.innerHTML = '<i class="fas fa-archive"></i>';
            successTitle.textContent = 'Patient Archived Successfully!';
            successMessage.innerHTML = `
                Patient <strong>${patientName}</strong> has been archived.<br><br>
                <small class="text-warning">
                    <i class="fas fa-exclamation-triangle me-1"></i>
                    Archived patients cannot book appointments and are moved to historical records.
                </small>
            `;
            if (header) header.style.background = 'linear-gradient(135deg, var(--archived-color) 0%, #ffd351 100%)';
        } else if (String(status) === '1') {
            successIcon.className = 'success-icon';
            successIcon.innerHTML = '<i class="fas fa-check"></i>';
            successTitle.textContent = 'Patient Active!';
            successMessage.textContent = `Patient ${patientName} is now active and can book appointments.`;
            if (header) header.style.background = 'linear-gradient(135deg, var(--active-color) 0%, #34ce57 100%)';
        } else {
            successIcon.className = 'success-icon';
            successIcon.innerHTML = '<i class="fas fa-save"></i>';
            successTitle.textContent = 'Saved Successfully!';
            successMessage.textContent = 'Patient information has been updated and saved.';
            if (header) header.style.background = 'linear-gradient(135deg, var(--active-color) 0%, #34ce57 100%)';
        }

        modal.show();
    }

    function showErrorNotification(message) {
        let errorToast = document.getElementById('errorToast');
        if (!errorToast) {
            errorToast = document.createElement('div');
            errorToast.id = 'errorToast';
            errorToast.className = 'toast-notification';
            errorToast.innerHTML = `
                <div class="alert alert-danger alert-dismissible fade show shadow-lg" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-exclamation-triangle fs-4 me-3"></i>
                        <div>
                            <h5 class="alert-heading mb-1">Error!</h5>
                            <p class="mb-0">${message}</p>
                        </div>
                    </div>
                    <button type="button" class="btn-close" onclick="this.closest('.toast-notification').remove()"></button>
                </div>
            `;
            document.body.appendChild(errorToast);
        }

        errorToast.style.display = 'block';
        setTimeout(() => errorToast.classList.add('show'), 100);

        setTimeout(() => {
            errorToast.classList.remove('show');
            setTimeout(() => (errorToast.style.display = 'none'), 500);
        }, 5000);
    }
});
</script>
