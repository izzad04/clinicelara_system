<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Patient $patient
 */

// Get current user info
$currentUser = $this->request->getAttribute('identity');
$userRole = $currentUser->role ?? 'user';

// Determine status variables
$statusClass = 'badge-inactive';
$statusText  = 'Inactive';
$statusIcon  = 'bi-dash-circle';

if ($patient->status == 1) {
    $statusClass = 'badge-active';
    $statusText  = 'Active';
    $statusIcon  = 'bi-check-circle';
} elseif ($patient->status == 2) {
    $statusClass = 'badge-archived';
    $statusText  = 'Archived';
    $statusIcon  = 'bi-archive';
}

// Load required CSS/JS
echo $this->Html->css('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css');
echo $this->Html->css('appointment_admin');
?>

<style>
:root {
    --primary-color: #A53860;
    --primary-light: rgba(165, 56, 96, 0.10);
    --primary-soft: rgba(165, 56, 96, 0.06);
    --secondary-color: #6c757d;
}

body {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: linear-gradient(135deg, #f8f9fa 0%, #f5f5f5 100%);
    min-height: 100vh;
}

/* Header */
.top-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, #c44569 100%);
    color: white;
    padding: 18px 26px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 20px rgba(165,56,96,0.2);
    position: sticky;
    top: 0;
    z-index: 100;
}

.toggle-btn {
    background: rgba(255,255,255,0.15);
    border: none;
    color: white;
    width: 48px;
    height: 48px;
    border-radius: 12px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
}
.toggle-btn:hover { background: rgba(255,255,255,0.25); }

/* Patient Profile Header */
.patient-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, #c44569 100%);
    color: white;
    padding: 40px;
    border-radius: 20px;
    margin: 30px;
    box-shadow: 0 10px 40px rgba(165,56,96,0.25);
    position: relative;
    overflow: hidden;
}

.patient-header::before {
    content: '';
    position: absolute;
    top: -100px;
    right: -100px;
    width: 300px;
    height: 300px;
    background: rgba(255,255,255,0.08);
    border-radius: 50%;
}

.patient-header::after {
    content: '';
    position: absolute;
    bottom: -50px;
    left: -50px;
    width: 200px;
    height: 200px;
    background: rgba(255,255,255,0.05);
    border-radius: 50%;
}

.patient-avatar {
    width: 110px;
    height: 110px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    border: 5px solid rgba(255,255,255,0.3);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    position: relative;
    z-index: 2;
}

.patient-avatar i {
    font-size: 3.2rem;
    background: linear-gradient(135deg, var(--primary-color) 0%, #c44569 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* Cards */
.card-modern {
    background: white;
    border-radius: 16px;
    padding: 28px;
    margin: 20px 30px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.08);
    border: 1px solid rgba(0,0,0,0.05);
}

/* Section Headers */
.section-header {
    color: var(--primary-color);
    font-weight: 800;
    margin-bottom: 22px;
    padding-bottom: 14px;
    border-bottom: 3px solid rgba(165, 56, 96, 0.10);
    display: flex;
    align-items: center;
    gap: 12px;
}

.section-header i {
    background: var(--primary-color);
    color: white;
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* ===== NEW BOX STYLE (NOT like old one) ===== */
.info-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    margin-top: 18px;
}

.address-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
    margin-top: 16px;
}

/* New box: soft bg + border + icon circle */
.info-item {
    border: 1px solid rgba(0,0,0,0.06);
    background: linear-gradient(180deg, #ffffff 0%, #fafafa 100%);
    border-radius: 14px;
    padding: 18px 18px;
    transition: all 0.2s ease;
    display: flex;
    gap: 14px;
    align-items: flex-start;
}

.info-item:hover {
    box-shadow: 0 10px 22px rgba(0,0,0,0.08);
    transform: translateY(-2px);
}

.info-icon {
    width: 44px;
    height: 44px;
    border-radius: 12px;
    background: var(--primary-soft);
    color: var(--primary-color);
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    font-size: 1.2rem;
}

.info-text {
    display: flex;
    flex-direction: column;
    min-width: 0;
}

.info-label {
    color: #7a7a7a;
    font-size: 0.85rem;
    font-weight: 700;
    margin-bottom: 6px;
}

.info-value {
    font-size: 1.05rem;
    font-weight: 700;
    color: #22313f;
    line-height: 1.4;
    word-break: break-word;
}

/* Status Badges */
.badge-status {
    padding: 10px 18px;
    border-radius: 25px;
    font-size: 0.95rem;
    font-weight: 800;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.10);
}

.badge-active {
    background: rgba(40, 167, 69, 0.14);
    color: #28a745;
    border: 2px solid rgba(40, 167, 69, 0.25);
}

.badge-inactive {
    background: rgba(255, 193, 7, 0.14);
    color: #b8860b;
    border: 2px solid rgba(255, 193, 7, 0.25);
}

.badge-archived {
    background: rgba(108, 117, 125, 0.14);
    color: #6c757d;
    border: 2px solid rgba(108, 117, 125, 0.25);
}

/* System grid */
.system-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    margin-top: 16px;
}

/* Responsive */
@media (max-width: 992px) {
    .patient-header { margin: 20px; padding: 28px 20px; }
    .card-modern { margin: 20px; padding: 22px; }
}
@media (max-width: 768px) {
    .card-modern { margin: 15px; }
    .patient-header { margin: 15px; padding: 24px 18px; }
    .info-grid { grid-template-columns: 1fr; }
    .address-grid { grid-template-columns: 1fr; }
    .system-grid { grid-template-columns: 1fr; }
}
</style>

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold" style="color: #A53860; font-size: 1.3rem;">Elara Medical Clinic</h5>
            <small class="text-muted">Patient Portal</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar" type="button">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER (Back button only) -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <button class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar" type="button">
                    <i class="bi bi-list fs-4"></i>
                </button>
                <h5 class="m-0">Patient Profile</h5>
            </div>

            <div class="d-flex gap-2">
                <a href="<?= $this->Url->build(['action' => 'index']) ?>" class="btn btn-outline-light btn-sm px-3">
                    <i class="bi bi-arrow-left me-2"></i> Back
                </a>
            </div>
        </header>

        <main>
            <!-- Patient Profile Header -->
            <div class="patient-header">
                <div class="text-center" style="position: relative; z-index: 2;">
                    <div class="patient-avatar">
                        <i class="bi bi-person-heart"></i>
                    </div>

                    <h1 class="mb-2 fw-bold"><?= h($patient->fullname) ?></h1>

                    <div class="d-flex justify-content-center flex-wrap gap-3 mb-3">
                        <span class="badge bg-white text-dark px-3 py-2">
                            <i class="bi bi-person me-2"></i>ID: #<?= $patient->id ?>
                        </span>

                        <span class="badge-status <?= $statusClass ?>">
                            <i class="bi <?= $statusIcon ?>"></i> <?= $statusText ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Personal Information -->
            <div class="card-modern">
                <h4 class="section-header">
                    <i class="bi bi-person-vcard"></i>
                    Personal Information
                </h4>

                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-person"></i></div>
                        <div class="info-text">
                            <div class="info-label">Full Name</div>
                            <div class="info-value"><?= h($patient->fullname) ?></div>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-id-card"></i></div>
                        <div class="info-text">
                            <div class="info-label">IC Number</div>
                            <div class="info-value"><?= h($patient->ic) ?></div>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-telephone"></i></div>
                        <div class="info-text">
                            <div class="info-label">Phone Number</div>
                            <div class="info-value"><?= h($patient->phone) ?></div>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-envelope"></i></div>
                        <div class="info-text">
                            <div class="info-label">Email Address</div>
                            <div class="info-value"><?= h($patient->email) ?></div>
                        </div>
                    </div>
                </div>

                <!-- Address Information -->
                <h5 class="section-header mt-5">
                    <i class="bi bi-geo-alt"></i>
                    Address Information
                </h5>

                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-house"></i></div>
                        <div class="info-text">
                            <div class="info-label">Street 1</div>
                            <div class="info-value"><?= h($patient->street1) ?></div>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-house-add"></i></div>
                        <div class="info-text">
                            <div class="info-label">Street 2</div>
                            <div class="info-value"><?= h($patient->street2) ?></div>
                        </div>
                    </div>
                </div>

                <div class="address-grid mt-3">
                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-buildings"></i></div>
                        <div class="info-text">
                            <div class="info-label">City</div>
                            <div class="info-value"><?= h($patient->city) ?></div>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-geo"></i></div>
                        <div class="info-text">
                            <div class="info-label">State</div>
                            <div class="info-value"><?= h($patient->state) ?></div>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-mailbox"></i></div>
                        <div class="info-text">
                            <div class="info-label">Postcode</div>
                            <div class="info-value"><?= $this->Number->format($patient->postcode) ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Information -->
            <div class="card-modern">
                <h4 class="section-header">
                    <i class="bi bi-info-circle"></i>
                    System Information
                </h4>

                <div class="system-grid">
                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-calendar-plus"></i></div>
                        <div class="info-text">
                            <div class="info-label">Created On</div>
                            <div class="info-value">
                                <?= $patient->created->format('F j, Y') ?>
                                <div class="text-muted small mt-1">
                                    <i class="bi bi-clock me-1"></i><?= $patient->created->format('h:i A') ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="bi bi-clock-history"></i></div>
                        <div class="info-text">
                            <div class="info-label">Last Updated</div>
                            <div class="info-value">
                                <?= $patient->modified->format('F j, Y') ?>
                                <div class="text-muted small mt-1">
                                    <i class="bi bi-clock me-1"></i><?= $patient->modified->format('h:i A') ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>
</div>

<?= $this->Html->script('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js') ?>
<?= $this->Html->scriptBlock('
document.addEventListener("DOMContentLoaded", function() {
    const toggleBtn = document.getElementById("toggleSidebar");
    const sidebar   = document.getElementById("sidebar");
    const closeBtn  = document.getElementById("closeSidebar");

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener("click", function() {
            sidebar.classList.toggle("hide");
        });
    }
    if (closeBtn && sidebar) {
        closeBtn.addEventListener("click", function() {
            sidebar.classList.add("hide");
        });
    }

    function handleResize() {
        if (window.innerWidth < 768) sidebar.classList.add("hide");
    }
    window.addEventListener("resize", handleResize);
    handleResize();
});
') ?>
