<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Patient> $patients
 */

// current user
$currentUser   = $this->request->getAttribute('identity');
$currentUserId = $currentUser->id ?? null;
$userRole      = $currentUser->role ?? 'user';

// CSS
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Bootstrap (remove if already in layout) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

<style>
/* =========================
   HEADER SEARCH (admin-like)
   ========================= */
.header-search { display:flex; align-items:center; }
.search-form { margin:0; }
.search-wrap { display:flex; align-items:center; gap:10px; }
.search-input{
    height:44px !important;
    line-height:44px !important;
    padding-top:0 !important;
    padding-bottom:0 !important;
    border-radius:10px !important;
    width:240px;
}
.search-btn{
    height:44px !important;
    width:44px !important;
    padding:0 !important;
    border-radius:10px !important;
    background:#fff !important;
    border:1px solid rgba(255,255,255,0.35) !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    cursor:pointer !important;
}
@media (max-width:768px){ .search-input{ width:170px; } }

/* =========================
   PATIENTS INDEX STYLES
   ========================= */
.patient-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 1.1rem;
    margin-right: 12px;
}

.patient-info { display:flex; align-items:center; }
.patient-details { line-height: 1.4; }
.patient-name { font-weight: 700; color:#333; margin-bottom: 2px; }
.patient-ic { font-size: .85rem; color:#666; }

/* Stat Boxes */
.stat-box {
    background: white;
    border-radius: 14px;
    padding: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,.05);
    border: 1px solid rgba(0,0,0,.05);
    transition: all .25s ease;
    height: 100%;
}
.stat-box:hover { transform: translateY(-3px); box-shadow: 0 10px 24px rgba(0,0,0,.10); }

.stat-icon {
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background: #f8f9fa;   /* soft background */
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    margin-bottom: 14px;
}

.stat-blue   { color: #2563eb; background: rgba(37, 99, 235, 0.08); }
.stat-green  { color: #16a34a; background: rgba(22, 163, 74, 0.08); }
.stat-gray   { color: #6b7280; background: rgba(107, 114, 128, 0.08); }
.stat-red    { color: #dc2626; background: rgba(220, 38, 38, 0.08); }


.stat-number { font-size: 2rem; font-weight: 800; color:#222; line-height: 1; margin-bottom: 6px; }
.stat-label { font-size: .95rem; color:#666; margin:0; }

/* Table */
.table-modern { --bs-table-hover-bg: rgba(248, 182, 200, 0.05); }
.table-modern thead th {
    font-weight: 700;
    color: #495057;
    border-bottom: 2px solid #dee2e6;
    background: #f8f9fa;
}
.table-modern tbody td { vertical-align: middle; padding: 16px 12px; }
.table-modern tbody tr:hover { background-color: rgba(248,182,200,.08) !important; }

/* Actions */
.action-group { display:flex; gap:10px; justify-content:flex-end; }
.btn-action {
    width: 34px;
    height: 34px;
    padding: 0;
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius: 10px;
    border: 1px solid #dee2e6;
    background: #fff;
    color: #666;
    transition: all .2s;
}
.btn-action:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.08); }
.btn-view:hover   { background: rgba(13,110,253,.10); color:#0d6efd; border-color: rgba(13,110,253,.20); }
.btn-edit:hover   { background: rgba(255,193,7,.12);  color:#b58100; border-color: rgba(255,193,7,.30); }
.btn-book:hover   { background: rgba(165,56,96,.10);  color:#A53860; border-color: rgba(165,56,96,.22); }
.btn-delete:hover { background: rgba(220,53,69,.10);  color:#dc3545; border-color: rgba(220,53,69,.22); }

/* Empty State */
.empty-state { text-align:center; padding: 60px 20px; }
.empty-icon { font-size: 4rem; color:#dee2e6; margin-bottom: 20px; }
</style>

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', ['alt' => 'Elara Clinic Logo', 'class' => 'logo-img']) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Patient Portal</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar" type="button">
                <i class="fas fa-times"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <button class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar" type="button">
                    <i class="fas fa-bars fs-4"></i>
                </button>
                <h5 class="m-0 d-none d-md-block">My Patients</h5>
                <h5 class="m-0 d-md-none">Patients</h5>
            </div>

        </header>

        <!-- CONTENT -->
        <main class="content-area">

            <!-- STAT CARDS -->
            <div class="row mb-4 g-3">
                <div class="col-md-3 col-sm-6">
                    <div class="stat-box">
                        <div class="stat-icon stat-blue">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-number"><?= $total_patients ?? (is_countable($patients) ? count($patients) : 0) ?></div>
                        <div class="stat-label">Total Patients</div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <div class="stat-box">
                        <div class="stat-icon stat-green">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <div class="stat-number"><?= $total_patients_active ?? 0 ?></div>
                        <div class="stat-label">Active Patients</div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <div class="stat-box">
                        <div class="stat-icon stat-gray">
                            <i class="fas fa-box-archive"></i>
                        </div>
                        <div class="stat-number"><?= $total_patients_archived ?? 0 ?></div>
                        <div class="stat-label">Archived</div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <div class="stat-box">
                        <div class="stat-icon stat-red">
                            <i class="fas fa-user-slash"></i>
                        </div>
                        <div class="stat-number"><?= $total_patients_disabled ?? 0 ?></div>
                        <div class="stat-label">Disabled</div>
                    </div>
                </div>
            </div>

            <!-- ✅ SEARCH BAR (PUTS IN YOUR RED BOX AREA) -->
            <div class="card-modern shadow-sm mb-4">
                <div class="header-search">
                    <?= $this->Form->create(null, [
                        'url' => ['action' => 'index'],
                        'type' => 'get',
                        'valueSources' => 'query',
                        'class' => 'search-form'
                    ]) ?>

                    <div class="search-wrap">

                        <?= $this->Form->control('id', [
                            'label' => false,
                            'placeholder' => 'Patient ID',
                            'class' => 'form-control search-input',
                            'style' => 'width:140px;',
                            'value' => (string)$this->request->getQuery('id'),
                            'type' => 'number',
                            'min' => 1
                        ]) ?>

                        <?= $this->Form->control('name', [
                            'label' => false,
                            'placeholder' => 'Patient Name',
                            'class' => 'form-control search-input',
                            'style' => 'width:240px;',
                            'value' => (string)$this->request->getQuery('name'),
                            'type' => 'text'
                        ]) ?>

                        <?= $this->Form->control('ic', [
                            'label' => false,
                            'placeholder' => 'IC Number',
                            'class' => 'form-control search-input',
                            'style' => 'width:200px;',
                            'value' => (string)$this->request->getQuery('ic'),
                            'type' => 'text'
                        ]) ?>

                        <?= $this->Form->button('<i class="fas fa-search"></i>', [
                            'class' => 'btn search-btn',
                            'escape' => false,
                            'escapeTitle' => false,
                            'title' => 'Search'
                        ]) ?>

                        <?= $this->Html->link('<i class="fas fa-xmark"></i>',
                            ['action' => 'index'],
                            ['class' => 'btn search-btn', 'escape' => false, 'escapeTitle' => false, 'title' => 'Reset']
                        ) ?>

                    </div>

                    <?= $this->Form->end() ?>
                </div>
            </div>

            <!-- TABLE CARD -->
            <div class="card-modern shadow-sm">
                <div class="card-header bg-transparent border-bottom py-3 d-flex justify-content-between align-items-center">
                    <h6 class="mb-0 fw-bold">
                        <i class="fas fa-list me-2"></i> Patient List
                    </h6>

                    <?= $this->Html->link(
                        '<i class="fas fa-user-plus me-2"></i> Add New Patient',
                        ['action' => 'add'],
                        [
                            'class' => 'btn btn-primary fw-bold',
                            'escape' => false,
                            'escapeTitle' => false,
                            'style' => '
                                background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
                                border: none;
                                border-radius: 10px;
                                padding: 10px 18px;
                                box-shadow: 0 4px 12px rgba(165, 56, 96, 0.28);
                            '
                        ]
                    ) ?>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-modern table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Patient ID</th>
                                    <th>Patient Info</th>
                                    <th>Contact</th>
                                    <th>Location</th>
                                    <th class="text-end" width="160">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (empty($patients)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-5">
                                        <div class="empty-state">
                                            <i class="fas fa-user-slash empty-icon mb-3"></i>
                                            <h5 class="text-muted">No patients found</h5>
                                            <p class="text-muted mb-4">You haven't added any patient profiles yet.</p>
                                            <?= $this->Html->link(
                                                '<i class="fas fa-user-plus me-2"></i> Add Your First Patient',
                                                ['action' => 'add'],
                                                ['class' => 'btn btn-primary', 'escape' => false]
                                            ) ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                               
                                <?php foreach ($patients as $patient): ?>
                                    <tr>
                                        <td class="fw-bold">#<?= h($patient->id) ?></td>
                                        <td>
                                            <div class="patient-info">
                                                <div class="patient-avatar">
                                                    <?= strtoupper(substr((string)$patient->fullname, 0, 1)) ?>
                                                </div>
                                                <div class="patient-details">
                                                    <div class="patient-name"><?= h($patient->fullname) ?></div>
                                                    <div class="patient-ic">IC: <?= h($patient->ic) ?></div>
                                                </div>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="small">
                                                <div><i class="fas fa-phone me-1 text-muted"></i> <?= h($patient->phone) ?></div>
                                                <div class="text-muted"><?= h($patient->email) ?></div>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="small">
                                                <div><?= h($patient->city) ?>, <?= h($patient->state) ?></div>
                                                <div class="text-muted"><?= h($patient->postcode) ?></div>
                                            </div>
                                        </td>

                                        <td class="text-end">
                                            <div class="action-group">
                                                <?= $this->Html->link(
                                                    '<i class="fas fa-eye"></i>',
                                                    ['action' => 'view', $patient->id],
                                                    ['class' => 'btn-action btn-view', 'escape' => false, 'title' => 'View Details']
                                                ) ?>

                                                <?= $this->Html->link(
                                                    '<i class="fas fa-edit"></i>',
                                                    ['action' => 'edit', $patient->id],
                                                    ['class' => 'btn-action btn-edit', 'escape' => false, 'title' => 'Edit']
                                                ) ?>

                                                <?= $this->Form->postLink(
                                                    '<i class="fas fa-trash"></i>',
                                                    ['action' => 'delete', $patient->id],
                                                    [
                                                        'confirm' => __('Are you sure you want to delete patient: {0}?', h($patient->fullname)),
                                                        'class' => 'btn-action btn-delete',
                                                        'escape' => false,
                                                        'title' => 'Delete'
                                                    ]
                                                ) ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if (!empty($patients)): ?>
                    <div class="card-footer bg-transparent border-top py-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="text-muted">
                                <?= $this->Paginator->counter('Showing {{start}} to {{end}} of {{count}} patients') ?>
                            </div>
                            <nav>
                                <ul class="pagination pagination-sm mb-0">
                                    <?= $this->Paginator->first('«', ['label' => 'First']) ?>
                                    <?= $this->Paginator->prev('‹', ['label' => 'Previous']) ?>
                                    <?= $this->Paginator->numbers() ?>
                                    <?= $this->Paginator->next('›', ['label' => 'Next']) ?>
                                    <?= $this->Paginator->last('»', ['label' => 'Last']) ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

        </main>
    </div>
</div>

<?= $this->Html->scriptBlock('
document.addEventListener("DOMContentLoaded", function() {
    const toggleBtn = document.getElementById("toggleSidebar");
    const sidebar = document.getElementById("sidebar");
    const closeSidebar = document.getElementById("closeSidebar");
    const mainContent = document.querySelector(".main-content");

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener("click", function() {
            sidebar.classList.toggle("hide");
            if (mainContent) mainContent.classList.toggle("expanded");
        });
    }

    if (closeSidebar && sidebar) {
        closeSidebar.addEventListener("click", function() {
            sidebar.classList.add("hide");
            if (mainContent) mainContent.classList.add("expanded");
        });
    }

    const tooltipTriggerList = [].slice.call(document.querySelectorAll("[title]"));
    tooltipTriggerList.map(function (el) { return new bootstrap.Tooltip(el); });
});
') ?>
