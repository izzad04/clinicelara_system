<?php
// Page-specific CSS
echo $this->Html->css('appointment_admin');
echo $this->Html->css('index_dashboard');

// ✅ get logged in user
$identity = $this->request->getAttribute('identity');
$currentUserId   = $identity['id'] ?? $identity->id ?? null;
$currentUserName = $identity['fullname'] ?? $identity->fullname ?? 'Patient';

// ✅ Expect $appointments passed from controller (filtered by user_id + upcoming)
$appointments = $appointments ?? []; // prevent error if not set

// ✅ counts for quick stats (optional: pass these from controller for accuracy)
$totalAppointments     = $totalAppointments ?? null;
$upcomingCount         = $upcomingCount ?? null;
$completedCount        = $completedCount ?? null;
$medicalRecordsCount   = $medicalRecordsCount ?? null;
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
/* ✅ small header datetime pill */
.header-datetime{
    background: rgba(255,255,255,0.16);
    border: 1px solid rgba(255,255,255,0.22);
    padding: 8px 12px;
    border-radius: 12px;
    display:flex;
    align-items:center;
    gap:10px;
    line-height:1.1;
}
.header-datetime .dt-day{ font-weight:800; font-size:.95rem; }
.header-datetime .dt-time{ font-weight:700; font-size:.85rem; opacity:.9; }

/* ✅ upcoming list nicer (if not already in your css) */
.appointment-item{
    background:#fff;
    border:1px solid rgba(0,0,0,0.06);
    border-radius: 16px;
    padding: 16px 18px;
    box-shadow: 0 8px 22px rgba(0,0,0,0.06);
    display:flex;
    justify-content: space-between;
    align-items:center;
    gap:14px;
    margin-bottom: 12px;
}
.appointment-date{
    min-width: 180px;
    font-weight: 800;
    color:#A53860;
    display:flex;
    flex-direction: column;
    gap:6px;
}
.appointment-date .date-line{
    display:flex;
    align-items:center;
    gap:8px;
}
.appointment-details h5{ margin:0; font-weight:800; }
.appointment-details p{ margin:4px 0 0; color:#6c757d; }
.btn-view{
    border-radius: 12px;
    padding: 10px 14px;
    font-weight: 700;
}
.empty-state{
    text-align:center;
    padding: 40px 18px;
    border: 2px dashed rgba(165,56,96,0.25);
    border-radius: 18px;
    background: rgba(165,56,96,0.05);
}
.empty-state i{ font-size: 2rem; color:#A53860; margin-bottom: 10px;}
</style>

<!-- User Dashboard Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Patient Portal</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="fas fa-times"></i> Close
            </button>
        </div>

        <!-- User Menu -->
        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="fas fa-bars fs-4"></i>
                </span>
                <div>
                    <h5 class="m-0 d-none d-md-block">Patient Dashboard</h5>
                    <h5 class="m-0 d-md-none">Dashboard</h5>
                </div>
            </div>

            <!-- ✅ Day + Time at header + user info -->
            <div class="d-flex align-items-center gap-3">
                <div class="header-datetime">
                    <i class="fas fa-calendar-day"></i>
                    <div>
                        <div class="dt-day" id="hdrDay">-</div>
                        <div class="dt-time" id="hdrTime">-</div>
                    </div>
                </div>

                <div class="user-avatar">
                    <div class="avatar-circle-sm">
                        <i class="fas fa-user"></i>
                    </div>
                </div>

                <div class="user-info d-none d-md-block">
                    <small class="text-light">Welcome back</small>
                    <h6 class="m-0"><?= h($currentUserName) ?></h6>
                </div>
            </div>
        </header>

        <!-- DASHBOARD CONTENT -->
        <main class="content-area">
            <!-- Welcome Section -->
            <div class="welcome-card">
                <h2>Welcome, <?= h($currentUserName) ?>! 👋</h2>
                <p>This is your patient dashboard. Manage appointments, view medical records, and update your profile.</p>
            </div>

            <!-- Quick Stats -->
            <div class="quick-stats">
                <div class="stat-card">
                    <i class="fas fa-calendar-check"></i>
                    <h3><?= $totalAppointments !== null ? (int)$totalAppointments : '-' ?></h3>
                    <p>Total Appointments</p>
                </div>

                <div class="stat-card">
                    <i class="fas fa-clock"></i>
                    <h3><?= $upcomingCount !== null ? (int)$upcomingCount : count($appointments) ?></h3>
                    <p>Upcoming Appointments</p>
                </div>

                <div class="stat-card">
                    <i class="fas fa-check-circle"></i>
                    <h3><?= $completedCount !== null ? (int)$completedCount : '-' ?></h3>
                    <p>Completed Appointments</p>
                </div>

                <div class="stat-card">
                    <i class="fas fa-star"></i>
                    <h3><?= $medicalRecordsCount !== null ? (int)$medicalRecordsCount : '-' ?></h3>
                    <p>Medical Records</p>
                </div>
            </div>

            <!-- Upcoming Appointments -->
            <div class="upcoming-appointments">
                <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                    <h4 class="m-0"><i class="fas fa-calendar-day me-2"></i>Upcoming Appointments</h4>

                    <?= $this->Html->link(
                        '<i class="fas fa-plus me-2"></i> New Appointment',
                        ['controller' => 'Appointments', 'action' => 'add'],
                        ['class' => 'btn-new-appointment', 'escape' => false]
                    ) ?>
                </div>

                <?php
                // ✅ extra safety: only show appointment with the same user_id
                $filteredAppointments = [];
                foreach ($appointments as $a) {
                    $aUserId = $a->user_id ?? null;
                    if ($currentUserId !== null && (string)$aUserId === (string)$currentUserId) {
                        $filteredAppointments[] = $a;
                    }
                }
                ?>

                <?php if (!empty($filteredAppointments)) : ?>
                    <?php foreach ($filteredAppointments as $a) : ?>
                        <?php
                        $dateText = !empty($a->date)
                            ? (is_object($a->date) ? $a->date->format('D, M d, Y') : date('D, M d, Y', strtotime($a->date)))
                            : '-';

                        $timeText = !empty($a->time)
                            ? (is_object($a->time) ? $a->time->format('h:i A') : date('h:i A', strtotime($a->time)))
                            : '-';

                        // Doctor name (adjust if your association field differs)
                        $doctorName = $a->doctor->fullname ?? $a->doctor->name ?? 'Doctor';

                        // Status label (based on your table)
                        $statusLabel = 'Unknown';
                        if (isset($a->status)) {
                            if ($a->status == 1) $statusLabel = 'Confirmed';
                            elseif ($a->status == 2) $statusLabel = 'Scheduled';
                            elseif ($a->status == 4) $statusLabel = 'Cancelled';
                        }
                        ?>

                        <div class="appointment-item">
                            <div class="appointment-date">
                                <div class="date-line">
                                    <i class="fas fa-calendar me-2"></i>
                                    <?= h($dateText) ?>
                                </div>
                                <small class="text-muted fw-semibold">
                                    <i class="fas fa-circle me-1" style="font-size:7px;"></i>
                                    <?= h($statusLabel) ?>
                                </small>
                            </div>

                            <div class="appointment-details">
                                <h5 class="mb-1"><?= h($doctorName) ?></h5>
                                <p class="mb-0">
                                    <i class="fas fa-clock me-1"></i> <?= h($timeText) ?>
                                </p>
                            </div>

                            <div class="appointment-actions">
                                <?= $this->Html->link(
                                    '<i class="fas fa-eye"></i> View',
                                    ['controller' => 'Appointments', 'action' => 'view', $a->id],
                                    ['class' => 'btn btn-sm btn-outline-primary btn-view', 'escape' => false]
                                ) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>

                <?php else : ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-times"></i>
                        <p class="mb-3 fw-bold">No upcoming appointments</p>
                        <?= $this->Html->link(
                            '<i class="fas fa-plus me-2"></i> Book Your First Appointment',
                            ['controller' => 'Appointments', 'action' => 'add'],
                            ['class' => 'btn btn-primary', 'escape' => false]
                        ) ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    const toggleBtn = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const closeBtn = document.getElementById('closeSidebar');

    if (toggleBtn && sidebar) {
        toggleBtn.onclick = function() {
            sidebar.classList.toggle('hide');
        };
    }

    if (closeBtn && sidebar) {
        closeBtn.onclick = function() {
            sidebar.classList.add('hide');
        };
    }

    // ✅ Header Day + Time
    const dayEl  = document.getElementById('hdrDay');
    const timeEl = document.getElementById('hdrTime');

    function pad(n){ return n.toString().padStart(2,'0'); }
    function updateHeaderTime(){
        const now = new Date();
        const dayStr = now.toLocaleDateString(undefined, { weekday:'long', year:'numeric', month:'short', day:'2-digit' });
        let hours = now.getHours();
        const minutes = pad(now.getMinutes());
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12; hours = hours ? hours : 12;

        if(dayEl)  dayEl.textContent  = dayStr;
        if(timeEl) timeEl.textContent = hours + ':' + minutes + ' ' + ampm;
    }
    updateHeaderTime();
    setInterval(updateHeaderTime, 30000);

    // Tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>
