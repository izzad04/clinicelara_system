<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Appointment $appointment
 * @var \App\Model\Entity\Patient[]|\Cake\Collection\CollectionInterface $patients
 * @var \App\Model\Entity\Doctor[]|\Cake\Collection\CollectionInterface $doctors
 * @var \App\Model\Entity\User[]|\Cake\Collection\CollectionInterface $users
 */

// Page-specific CSS
echo $this->Html->css('appointment_edit');
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
/* Small polish for this page */
.edit-icon{
    width: 52px;
    height: 52px;
    border-radius: 14px;
    background: rgba(165, 56, 96, 0.10);
    display:flex;
    align-items:center;
    justify-content:center;
}

/* ===== FORM FOOTER BUTTONS (Cancel / Reset / Save) ===== */
.form-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;            /* allow wrap instead of squeezing */
}

.form-actions .left-actions,
.form-actions .right-actions {
    display: flex;
    gap: 14px;                  /* consistent spacing */
    flex-wrap: wrap;
    align-items: center;
}

/* Make all buttons same height & nicer */
.form-actions .btn {
    min-height: 54px;
    border-radius: 12px;
    padding: 12px 18px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    white-space: nowrap;        /* stop text breaking weirdly */
}

/* Make Save button pink like your theme */
.form-actions .btn-save {
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%) !important;
    border: none !important;
    color: #fff !important;
    box-shadow: 0 6px 16px rgba(165, 56, 96, 0.25);
    padding-left: 26px;
    padding-right: 26px;
}

.form-actions .btn-save:hover {
    transform: translateY(-1px);
    box-shadow: 0 10px 22px rgba(165, 56, 96, 0.35);
    filter: brightness(1.02);
}

/* On smaller width, make buttons full width (nice stacking) */
@media (max-width: 992px) {
    .form-actions {
        flex-direction: column;
        align-items: stretch;
    }
    .form-actions .left-actions,
    .form-actions .right-actions {
        justify-content: center;
    }
    .form-actions .btn {
        width: 100%;
    }
}

.top-actions .btn{
    border-radius: 10px;
    padding: 8px 12px;
}

</style>

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar" type="button">
                <i class="fas fa-times"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['prefix' => 'Admin', 'controller' => 'Dashboards', 'action' => 'index'],
                ['escape' => false, 'escapeTitle' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'escapeTitle' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user-doctor"></i> Doctors',
                ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'index'],
                ['escape' => false, 'escapeTitle' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-users"></i> Patients',
                ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'escapeTitle' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'escapeTitle' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user-gear"></i> Users',
                ['prefix' => 'Admin', 'controller' => 'Users', 'action' => 'index'],
                ['escape' => false, 'escapeTitle' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'escapeTitle' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="fas fa-bars fs-4"></i>
                </span>

                <h5 class="m-0 d-none d-md-block">
                    <?= $appointment->isNew() ? 'Add New' : 'Edit' ?> Appointment
                    <?php if (!empty($appointment->id)): ?>
                        #<?= h($appointment->id) ?>
                    <?php endif; ?>
                </h5>

                <h5 class="m-0 d-md-none">
                    <?= $appointment->isNew() ? 'New' : 'Edit' ?> Appointment
                </h5>
            </div>

            <!-- Action Buttons -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT -->
        <main class="content-area">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="card-modern shadow-lg">
                        <div class="card-header bg-transparent border-bottom py-4">
                            <div class="d-flex align-items-center">
                                <div class="edit-icon me-3">
                                    <i class="fas fa-calendar-pen text-primary fs-3"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0 fw-bold text-primary">
                                        <?= $appointment->isNew() ? 'Create New Appointment' : 'Edit Appointment Details' ?>
                                    </h4>
                                    <p class="text-muted mb-0">
                                        <?= $appointment->isNew()
                                            ? 'Schedule a new appointment'
                                            : 'Update appointment details' . (!empty($appointment->id) ? ' #' . h($appointment->id) : '')
                                        ?>
                                    </p>
                                </div>

                                <?php if (!$appointment->isNew() && !empty($appointment->id)): ?>
                                    <div class="ms-auto">
                                        <span class="badge bg-info fs-6">ID: <?= h($appointment->id) ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="card-body p-4 p-lg-5">
                            <?= $this->Form->create($appointment) ?>

                            <div class="row g-3">
                                <!-- Patient -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="fas fa-user-heart me-2 text-primary"></i>Patient
                                        </label>
                                        <?= $this->Form->control('patient_id', [
                                            'options' => $patients,
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'empty' => '-- Select Patient --',
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Doctor -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="fas fa-user-doctor me-2 text-success"></i>Doctor
                                        </label>
                                        <?= $this->Form->control('doctor_id', [
                                            'options' => $doctors,
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'empty' => '-- Select Doctor --',
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Assigned User -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="fas fa-user-circle me-2 text-warning"></i>Assigned To
                                        </label>
                                        <?= $this->Form->control('user_id', [
                                            'options' => $users,
                                            'empty' => '-- Registered By (User) --',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Status -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="fas fa-circle me-2 text-info"></i>Status
                                        </label>
                                        <?= $this->Form->control('status', [
                                            'options' => [
                                                1 => 'Confirmed',
                                                2 => 'Scheduled',
                                                3 => 'Cancelled',
                                            ],
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'value' => $appointment->status ?? 1,
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Date -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="fas fa-calendar-day me-2 text-info"></i>Appointment Date
                                        </label>
                                        <?= $this->Form->control('date', [
                                            'type' => 'date',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Time -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="fas fa-clock me-2 text-info"></i>Appointment Time
                                        </label>
                                        <?= $this->Form->control('time', [
                                            'type' => 'time',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Notes -->
                                <div class="col-12">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="fas fa-note-sticky me-2"></i>Notes & Details
                                        </label>
                                        <?= $this->Form->control('notes', [
                                            'type' => 'textarea',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'rows' => 4,
                                            'placeholder' => 'Enter appointment notes, symptoms, or special instructions...',
                                        ]) ?>
                                    </div>
                                </div>
                            </div>

                            <div class="form-actions mt-5 pt-4 border-top">
                            <div class="left-actions">
                                <?= $this->Html->link(
                                    '<i class="fas fa-xmark-circle"></i> Cancel',
                                    ['action' => 'index'],
                                    ['class' => 'btn btn-lg btn-outline-secondary', 'escape' => false, 'escapeTitle' => false]
                                ) ?>
                            </div>

                            <div class="right-actions">
                                <?= $this->Form->button(
                                    '<i class="fas fa-rotate-right"></i> Reset',
                                    ['type' => 'reset', 'class' => 'btn btn-lg btn-outline-warning', 'escape' => false, 'escapeTitle' => false]
                                ) ?>

                                <?= $this->Form->button(
                                    $appointment->isNew()
                                        ? '<i class="fas fa-calendar-plus"></i> Create Appointment'
                                        : '<i class="fas fa-floppy-disk"></i> Save Changes',
                                    ['type' => 'submit', 'class' => 'btn btn-lg btn-save', 'escape' => false, 'escapeTitle' => false]
                                ) ?>
                            </div>
                        </div>


                            <?= $this->Form->end() ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- JavaScript -->
<?= $this->Html->scriptBlock('
document.addEventListener("DOMContentLoaded", function() {
    const toggleBtn = document.getElementById("toggleSidebar");
    const closeBtn  = document.getElementById("closeSidebar");
    const sidebar   = document.getElementById("sidebar");

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle("hide");
    if (closeBtn && sidebar)  closeBtn.onclick  = () => sidebar.classList.add("hide");

    // Date min = today (no past date)
    const dateInput = document.querySelector(\'input[type="date"]\');
    if (dateInput) {
        const today = new Date().toISOString().split("T")[0];
        dateInput.setAttribute("min", today);
    }
});
') ?>
