<?php
// Page-specific CSS
echo $this->Html->css('appointment_admin');
?>

<style>
/* =========================
   SEARCH (inline + same height)
   ========================= */
.search-form { margin: 0; }
.search-wrap {
    display: flex !important;
    align-items: center !important;
    gap: 10px;
    position: relative;
}
.search-input {
    height: 44px !important;
    line-height: 44px !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    border-radius: 10px !important;
    width: 240px;
}
.search-btn {
    height: 44px !important;
    width: 44px !important;
    padding: 0 !important;
    border-radius: 10px !important;
    background: #fff !important;
    border: 1px solid rgba(255,255,255,0.35) !important;
    cursor: pointer !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
}
@media (max-width: 768px) {
    .search-input { width: 170px; }
}

.search-wrap-wide{
    width: 100%;
    justify-content: flex-start; 
    flex-wrap: wrap;
}

.search-wrap-wide .search-input{
    width: 220px;
}

.search-wrap-wide .search-input:first-child{
    width: 140px; /* ID field smaller */
}

@media (max-width: 992px){
    .search-wrap-wide{
        justify-content: flex-start;
    }
    .search-wrap-wide .search-input{
        width: 100%;
    }
    .search-btn{
        width: 48px !important;
    }
}

/* =========================
   STATUS PILL (Active / Completed)
   ========================= */
.status-text {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}

.status-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: #adb5bd;
}

.status-text-active { color: #198754; }
.status-text-active .status-dot { background: #198754; }

.status-text-completed { color: #6c757d; }
.status-text-completed .status-dot { background: #6c757d; }

.status-text-default { color: #6c757d; }
.status-text-default .status-dot { background: #adb5bd; }


/* =========================
   ACTION BUTTONS (compact spacing)
   ========================= */
.action-buttons-sm {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px; /* smaller gap */
}
.action-buttons-sm .btn {
    padding: 4px 8px;
}

/* Optional: keep table looking clean */
.table-modern tbody tr { transition: all 0.2s ease; }
.table-modern tbody tr:hover { background-color: rgba(248, 182, 200, 0.1); }
</style>

<!-- Appointment Admin Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>

        <!-- Sidebar Footer -->
        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Appointments Management</h5>
                <h5 class="m-0 d-md-none">Elara Clinic</h5>
            </div>

            <div class="header-search">
    <?= $this->Form->create(null, [
        'valueSources' => 'query',
        'url' => ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
        'type' => 'get',
        'class' => 'search-form'
    ]) ?>

</div>
        </header>

        <!-- CONTENT -->
        <main class="content-area">
            <!-- CARDS -->
            <div class="row mb-4 g-3">
                <div class="col-md-4">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-calendar2-check fs-1 text-primary"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $total_appointments ?? 0 ?></h3>
                        <p class="text-muted mb-0">Total Appointments</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-clock-history fs-1 text-success"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $total_appointments_active ?? 0 ?></h3>
                        <p class="text-muted mb-0">Active Appointments</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-archive fs-1 text-warning"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $total_appointments_archived ?? 0 ?></h3>
                        <p class="text-muted mb-0">Archived Appointments</p>
                    </div>
                </div>
            </div>

            <div class="card-modern shadow-sm mb-4">
                <div class="card-body py-3">
                    <?= $this->Form->create(null, [
                        'valueSources' => 'query',
                        'url' => ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                        'type' => 'get',
                        'class' => 'search-form'
                    ]) ?>

                    <div class="search-wrap search-wrap-wide">
                        <?= $this->Form->control('id', [
                            'label' => false,
                            'placeholder' => 'ID (number)',
                            'class' => 'form-control search-input',
                            'value' => $this->request->getQuery('id'),
                            'type' => 'number',
                            'min' => 1
                        ]) ?>

                        <?= $this->Form->control('patient', [
                            'label' => false,
                            'placeholder' => 'Patient name',
                            'class' => 'form-control search-input',
                            'value' => $this->request->getQuery('patient'),
                            'type' => 'text'
                        ]) ?>

                        <?= $this->Form->control('doctor', [
                            'label' => false,
                            'placeholder' => 'Doctor name',
                            'class' => 'form-control search-input',
                            'value' => $this->request->getQuery('doctor'),
                            'type' => 'text'
                        ]) ?>

                        <?= $this->Form->button('<i class="bi bi-search-heart-fill"></i>', [
                            'class' => 'btn search-btn',
                            'escape' => false,
                            'title' => 'Search',
                            'escapeTitle' => false,
                        ]) ?>

                        <?= $this->Html->link('<i class="bi bi-x-lg"></i>',
                            ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                            ['class' => 'btn search-btn', 'escape' => false, 'escapeTitle' => false, 'title' => 'Reset']
                        ) ?>
                    </div>

                    <?= $this->Form->end() ?>
                </div>
            </div>

            <!-- TABLE -->
            <div class="card-modern shadow-sm">
                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center py-3">
                    <h6 class="mb-0 fw-bold">Appointment Management</h6>

                    <?= $this->Html->link(
                        '<i class="bi bi-plus-circle me-2"></i> Add New Appointment',
                        ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'add'],
                        [
                            'class' => 'btn btn-primary fw-bold',
                            'escape' => false,
                            'escapeTitle' => false,
                            'style' => '
                                background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
                                border: none;
                                border-radius: 8px;
                                padding: 10px 20px;
                                box-shadow: 0 4px 12px rgba(165, 56, 96, 0.3);
                                transition: all 0.3s ease;
                            '
                        ]
                    ) ?>
                </div>

                <div class="table-responsive">
                    <table class="table table-modern table-hover mb-0">
                        <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Patient</th>
                            <th>Doctor</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Status</th>
                            <th class="text-center">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($appointments as $a): ?>
                        <tr>
                        <td><span class="badge bg-secondary">#<?= h($a->id) ?></span></td>

                        <td>
                            <?php if ($a->has('patient')): ?>
                                <?= h($a->patient->fullname) ?>
                            <?php else: ?>
                                <?= h($a->patient_id) ?>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($a->has('doctor')): ?>
                                <?= h($a->doctor->fullname) ?>
                            <?php else: ?>
                                <?= h($a->doctor_id) ?>
                            <?php endif; ?>
                        </td>

                        <td><?= h($a->date) ?></td>
                        <td><?= h($a->time) ?></td>

                        <td>
                            <?php
                            $appointmentDateTime = strtotime($a->date . ' ' . $a->time);
                            $now = time();

                            if ($appointmentDateTime !== false && $appointmentDateTime < $now) {
                                $text  = 'Completed';
                                $class = 'status-text-completed';
                            } else {
                                $text  = 'Active';
                                $class = 'status-text-active';
                            }
                            ?>
                            <span class="status-text <?= $class ?>">
                                <span class="status-dot"></span>
                                <?= $text ?>
                            </span>
                        </td>

                        <td class="text-center">
                            <div class="action-buttons-sm">
                                <?= $this->Html->link('<i class="bi bi-eye"></i>',
                                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'view', $a->id],
                                    ['class' => 'btn btn-outline-primary btn-sm', 'escape' => false]
                                ) ?>

                                <?= $this->Html->link('<i class="bi bi-pencil"></i>',
                                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'edit', $a->id],
                                    ['class' => 'btn btn-outline-warning btn-sm', 'escape' => false]
                                ) ?>

                                <?= $this->Form->postLink('<i class="bi bi-trash"></i>',
                                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'delete', $a->id],
                                    ['class' => 'btn btn-outline-danger btn-sm', 'escape' => false,
                                    'confirm' => 'Are you sure you want to delete appointment #' . h($a->id) . '?'
                                    ]
                                ) ?>
                            </div>
                        </td>
                    </tr>

                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination (kept as your current static one) -->
                <div class="card-footer bg-white border-top py-3">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <li class="page-item disabled">
                                <a class="page-link" href="#">Previous</a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>

            </div>
        </main>
    </div>
</div>

<!-- JavaScript for tooltips -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (el) { return new bootstrap.Tooltip(el); });

    // sidebar toggle
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn = document.getElementById('closeSidebar');
    var sidebar = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar) closeBtn.onclick = () => sidebar.classList.add('hide');
});
</script>
