<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Appointment $appointment
 * @var \Cake\Collection\CollectionInterface|string[] $users
 * @var \Cake\Collection\CollectionInterface|string[] $patients
 * @var \Cake\Collection\CollectionInterface|string[] $doctors
 */

// Page-specific CSS
echo $this->Html->css('appointment_admin');
?>

<div class="admin-wrapper">
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar" type="button">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false,'escapeTitle'=>false,'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <div class="main-content">
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Add New Appointment</h5>
                <h5 class="m-0 d-md-none">New Appointment</h5>
            </div>

            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <main class="content-area">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="card-modern shadow-lg">
                        <div class="card-header bg-transparent border-bottom py-4">
                            <h4 class="mb-1 fw-bold text-primary">
                                <i class="bi bi-calendar-plus me-2"></i>Schedule New Appointment
                            </h4>
                            <p class="text-muted mb-0">Fill in the details to create a new appointment</p>
                        </div>

                        <div class="card-body p-4 p-lg-5">
                            <?= $this->Form->create($appointment, [
                                'class' => 'needs-validation',
                                'novalidate' => true
                            ]) ?>

                            <div class="row g-4">

                                <!-- ✅ USER FIRST -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-person-circle me-1 text-warning"></i> User (Registered By)
                                        </label>
                                        <?= $this->Form->control('user_id', [
                                            'options' => $users,
                                            'empty' => '-- Select User First --',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'id' => 'user-id',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Choose user first to load patients</div>
                                    </div>
                                </div>

                                <!-- ✅ PATIENT DEPENDS ON USER -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-person me-1 text-primary"></i> Patient
                                        </label>
                                        <?= $this->Form->control('patient_id', [
                                            'options' => $patients, // add() = []
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'empty' => '-- Select Patient --',
                                            'required' => true,
                                            'id' => 'patient-id',
                                            'disabled' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Patients will appear after selecting user</div>
                                    </div>
                                </div>

                                <!-- Doctor -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-person-badge me-1 text-success"></i> Doctor
                                        </label>
                                        <?= $this->Form->control('doctor_id', [
                                            'options' => $doctors,
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'empty' => '-- Select Doctor --',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Doctor will be selected by name</div>
                                    </div>
                                </div>

                                <!-- Date -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-calendar-date me-1 text-info"></i> Appointment Date
                                        </label>
                                        <?= $this->Form->control('date', [
                                            'type' => 'date',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'required' => true,
                                            'min' => date('Y-m-d')
                                        ]) ?>
                                        <div class="form-text text-muted">Select appointment date</div>
                                    </div>
                                </div>

                                <!-- Time -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-clock me-1 text-info"></i> Appointment Time
                                        </label>
                                        <?= $this->Form->control('time', [
                                            'type' => 'time',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'required' => true,
                                            'step' => '900'
                                        ]) ?>
                                        <div class="form-text text-muted">Select appointment time (15-min intervals)</div>
                                    </div>
                                </div>

                                <!-- Notes -->
                                <div class="col-12">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-journal-text me-1"></i> Notes & Details
                                        </label>
                                        <?= $this->Form->control('notes', [
                                            'type' => 'textarea',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'rows' => 4,
                                            'placeholder' => 'Enter any additional notes, symptoms, or special instructions...'
                                        ]) ?>
                                        <div class="form-text text-muted">Optional notes for this appointment</div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-actions mt-5 pt-4 border-top">
                            <div class="left-actions">
                                <?= $this->Html->link(
                                    '<i class="fas fa-xmark-circle"></i> Cancel',
                                    ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                                    ['class'=>'btn btn-lg btn-outline-secondary','escape'=>false,'escapeTitle'=>false]
                                ) ?>

                            <div class="right-actions">
                                <?= $this->Form->button(
                                    '<i class="fas fa-rotate-right"></i> Reset',
                                    ['type' => 'reset', 'class' => 'btn btn-lg btn-outline-warning', 'escape' => false, 'escapeTitle' => false]
                                ) ?>

                                <?= $this->Form->button(
                                    $appointment->isNew()
                                        ? '<i class="fas fa-calendar-plus"></i> Add Appointment'
                                        : '<i class="fas fa-floppy-disk"></i> Add',
                                    ['type' => 'submit', 'class' => 'btn btn-lg btn-save', 'escape' => false, 'escapeTitle' => false]
                                ) ?>
                            </div>

                            <?= $this->Form->end() ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
.top-actions .btn{ border-radius: 10px; padding: 8px 12px; }

.btn-save{
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%) !important;
    border: none !important;
    color: #fff !important;
    border-radius: 12px !important;
    padding: 14px 40px !important;
    box-shadow: 0 6px 20px rgba(165, 56, 96, 0.30);
    transition: all 0.25s ease;
}
.btn-save:hover{
    transform: translateY(-1px);
    filter: brightness(1.02);
    box-shadow: 0 10px 26px rgba(165, 56, 96, 0.40);
}

/* ===== FORM FOOTER BUTTONS (Cancel / Reset / Save) ===== */
.form-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;            /* allow wrap instead of squeezing */
}

.form-actions .left-actions,
.form-actions .right-actions {
    display: flex;
    gap: 14px;                  /* consistent spacing */
    flex-wrap: wrap;
    align-items: center;
}

/* Make all buttons same height & nicer */
.form-actions .btn {
    min-height: 54px;
    border-radius: 12px;
    padding: 12px 18px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    white-space: nowrap;        /* stop text breaking weirdly */
}

/* Make Save button pink like your theme */
.form-actions .btn-save {
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%) !important;
    border: none !important;
    color: #fff !important;
    box-shadow: 0 6px 16px rgba(165, 56, 96, 0.25);
    padding-left: 26px;
    padding-right: 26px;
}

.form-actions .btn-save:hover {
    transform: translateY(-1px);
    box-shadow: 0 10px 22px rgba(165, 56, 96, 0.35);
    filter: brightness(1.02);
}

/* On smaller width, make buttons full width (nice stacking) */
@media (max-width: 992px) {
    .form-actions {
        flex-direction: column;
        align-items: stretch;
    }
    .form-actions .left-actions,
    .form-actions .right-actions {
        justify-content: center;
    }
    .form-actions .btn {
        width: 100%;
    }
}

.top-actions .btn{
    border-radius: 10px;
    padding: 8px 12px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn = document.getElementById('closeSidebar');
    var sidebar = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar) closeBtn.onclick = () => sidebar.classList.add('hide');

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Date min = today
    const dateInput = document.querySelector('input[type="date"]');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.setAttribute('min', today);
    }

    // ✅ DEPENDENT DROPDOWN: patients by user
    const userSelect = document.getElementById('user-id');
    const patientSelect = document.getElementById('patient-id');

    function resetPatients(text) {
        patientSelect.innerHTML = '';
        const opt = document.createElement('option');
        opt.value = '';
        opt.textContent = text || '-- Select Patient --';
        patientSelect.appendChild(opt);
        patientSelect.value = '';
    }

    async function loadPatientsByUser(userId) {
        resetPatients('Loading patients...');
        patientSelect.disabled = true;

        try {
            const baseUrl = "<?= $this->Url->build(['prefix'=>'Admin','controller'=>'Appointments','action'=>'patientsByUser']) ?>";
            const res = await fetch(baseUrl + '/' + userId, {
                headers: { 'Accept': 'application/json' }
            });

            if (!res.ok) throw new Error('Request failed');

            const data = await res.json();
            const patients = data.patients || {};

            resetPatients('-- Select Patient --');

            const ids = Object.keys(patients);
            if (ids.length === 0) {
                resetPatients('No patients for this user');
                patientSelect.disabled = true;
                return;
            }

            ids.forEach(function(id) {
                const opt = document.createElement('option');
                opt.value = id;
                opt.textContent = patients[id];
                patientSelect.appendChild(opt);
            });

            patientSelect.disabled = false;
        } catch (err) {
            console.error(err);
            resetPatients('Failed to load patients');
            patientSelect.disabled = true;
        }
    }

    if (userSelect && patientSelect) {
        userSelect.addEventListener('change', function() {
            const userId = this.value;
            if (!userId) {
                resetPatients('-- Select Patient --');
                patientSelect.disabled = true;
                return;
            }
            loadPatientsByUser(userId);
        });
    }
});
</script>
