<?php
echo $this->Html->css('appointment_admin');

/**
 * Auto Status (UI only, not DB update)
 * - Completed if appointment date+time passed
 * - Active if upcoming
 */
$appointmentDateTime = strtotime($appointment->date . ' ' . $appointment->time);
$now = time();

if ($appointmentDateTime !== false && $appointmentDateTime < $now) {
    $statusText  = 'Completed';
    $statusClass = 'status-text-completed';
} else {
    $statusText  = 'Active';
    $statusClass = 'status-text-active';
}

/**
 * Safe display format for created/modified
 */
$createdText  = $appointment->created ? $appointment->created->format('M d, Y h:i A') : 'Not set';
$modifiedText = $appointment->modified ? $appointment->modified->format('M d, Y h:i A') : 'Not set';
?>

<style>
/* ===== remove scrollbar caused by wide elements ===== */
.admin-wrapper, .main-content, .content-area {
    overflow-x: hidden;
}

/* ===== status like Patients (dot + text) ===== */
.status-text {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.status-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: #adb5bd;
}
.status-text-active { color: #198754; }
.status-text-active .status-dot { background: #198754; }

.status-text-completed { color: #6c757d; }
.status-text-completed .status-dot { background: #6c757d; }

/* ===== timeline easier to read ===== */
.timeline {
    position: relative;
    padding-left: 28px;
    border-left: 2px solid #e9ecef;
}
.timeline-item {
    position: relative;
    padding: 10px 0 10px 0;
}
.timeline-marker {
    position: absolute;
    left: -9px;
    top: 16px;
    width: 14px;
    height: 14px;
    border-radius: 999px;
    background: #adb5bd;
    border: 3px solid #fff;
    box-shadow: 0 0 0 2px #e9ecef;
}
.timeline-item.done .timeline-marker { background: #198754; box-shadow: 0 0 0 2px rgba(25,135,84,0.25); }
.timeline-item.upcoming .timeline-marker { background: #0d6efd; box-shadow: 0 0 0 2px rgba(13,110,253,0.20); }
.timeline-item.muted .timeline-marker { background: #6c757d; }

.timeline-content h6 { margin: 0; font-weight: 700; }
.timeline-content small { color: #6c757d; }



/* ===== remove any table scroll if used somewhere ===== */
.table-no-scroll { overflow-x: hidden; }
</style>

<!-- Appointment Admin Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Appointment Details</h5>
                <h5 class="m-0 d-md-none">Details</h5>
            </div>

            <!-- Action Buttons -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <div class="row">
                <!-- FULL WIDTH (removed right sidebar) -->
                <div class="col-12">
                    <div class="card-modern shadow-lg mb-4">
                        <div class="card-header bg-transparent border-bottom py-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <h4 class="mb-0 fw-bold text-primary">
                                    <i class="bi bi-calendar3 me-2"></i>Appointment #<?= h($appointment->id) ?>
                                </h4>

                                <!-- STATUS (Patients style) -->
                                <span class="status-text <?= $statusClass ?>">
                                    <span class="status-dot"></span>
                                    <?= $statusText ?>
                                </span>
                            </div>
                        </div>

                        <div class="card-body p-4">
                            <div class="row g-4">
                                <!-- Patient Info -->
                                <div class="col-md-6">
                                    <div class="info-card">
                                        <div class="info-icon">
                                            <i class="bi bi-person-heart text-primary"></i>
                                        </div>
                                        <div class="info-content">
                                            <small class="text-muted">PATIENT</small>
                                            <h5 class="mb-1"><?= $appointment->hasValue('patient') ? h($appointment->patient->fullname) : 'N/A' ?></h5>
                                            <?php if ($appointment->hasValue('patient')): ?>
                                                <a href="<?= $this->Url->build(['prefix'=>'Admin','controller' => 'Patients', 'action' => 'view', $appointment->patient->id]) ?>"
                                                   class="btn btn-sm btn-outline-primary mt-2">
                                                    <i class="bi bi-eye me-1"></i> View Patient
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Doctor Info -->
                                <div class="col-md-6">
                                    <div class="info-card">
                                        <div class="info-icon">
                                            <i class="bi bi-person-badge text-success"></i>
                                        </div>
                                        <div class="info-content">
                                            <small class="text-muted">DOCTOR</small>
                                            <h5 class="mb-1"><?= $appointment->hasValue('doctor') ? h($appointment->doctor->fullname) : 'N/A' ?></h5>
                                            <?php if ($appointment->hasValue('doctor')): ?>
                                                <a href="<?= $this->Url->build(['prefix'=>'Admin','controller' => 'Doctors', 'action' => 'view', $appointment->doctor->id]) ?>"
                                                   class="btn btn-sm btn-outline-success mt-2">
                                                    <i class="bi bi-eye me-1"></i> View Doctor
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Appointment Date & Time -->
                                <div class="col-md-6">
                                    <div class="info-card">
                                        <div class="info-icon">
                                            <i class="bi bi-calendar-date text-info"></i>
                                        </div>
                                        <div class="info-content">
                                            <small class="text-muted">APPOINTMENT DATE</small>
                                           <h5 class="mb-1">
                                                <?php if (!empty($appointment->date)): ?>
                                                    <?php if (is_object($appointment->date) && method_exists($appointment->date, 'format')): ?>
                                                        <?= h($appointment->date->format('d/m/Y')) ?>
                                                    <?php else: ?>
                                                        <?= h(date('d/m/Y', strtotime($appointment->date))) ?>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </h5>
                                            <p class="text-muted mb-0">
                                                <i class="bi bi-clock me-1"></i> <?= h($appointment->time) ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Assigned To -->
                                <div class="col-md-6">
                                    <div class="info-card">
                                        <div class="info-icon">
                                            <i class="bi bi-person-circle text-warning"></i>
                                        </div>
                                        <div class="info-content">
                                            <small class="text-muted">ASSIGNED TO</small>
                                            <h5 class="mb-1">User #<?= h($appointment->user_id) ?></h5>
                                            <?php if ($appointment->hasValue('user')): ?>
                                                <a href="<?= $this->Url->build(['prefix'=>'Admin','controller' => 'Users', 'action' => 'view', $appointment->user->id]) ?>"
                                                   class="btn btn-sm btn-outline-warning mt-2">
                                                    <i class="bi bi-eye me-1"></i> View User
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Appointment Timeline (compact) -->
                                <div class="col-12">
                                    <div class="timeline-section mt-3">
                                        <h6 class="fw-bold mb-2">
                                            <i class="bi bi-clock-history me-2"></i>Appointment Timeline
                                        </h6>

                                        <div class="row g-2">
                                            <div class="col-md-6">
                                                <div class="timeline-mini-card">
                                                    <small class="text-muted d-block mb-1">CREATED</small>
                                                    <?php if (!empty($appointment->created)): ?>
                                                        <div class="fw-bold"><?= h($appointment->created->format('d/m/Y')) ?></div>
                                                        <div class="text-muted small"><?= h($appointment->created->format('h:i A')) ?></div>
                                                    <?php else: ?>
                                                        <div class="text-muted fst-italic">Not set</div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="timeline-mini-card">
                                                    <small class="text-muted d-block mb-1">LAST UPDATED</small>
                                                    <?php if (!empty($appointment->modified)): ?>
                                                        <div class="fw-bold"><?= h($appointment->modified->format('d/m/Y')) ?></div>
                                                        <div class="text-muted small"><?= h($appointment->modified->format('h:i A')) ?></div>
                                                    <?php else: ?>
                                                        <div class="text-muted fst-italic">Not set</div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- row -->
                        </div><!-- body -->
                    </div><!-- card -->

                    <!-- Notes Card -->
                    <div class="card-modern shadow-sm">
                        <div class="card-header bg-transparent border-bottom py-3">
                            <h5 class="mb-0 fw-bold">
                                <i class="bi bi-journal-text me-2"></i>Notes & Details
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="notes-content">
                                <?php if (!empty($appointment->notes)): ?>
                                    <?= $this->Text->autoParagraph(h($appointment->notes)); ?>
                                <?php else: ?>
                                    <div class="text-center py-5">
                                        <i class="bi bi-journal-x text-muted fs-1 mb-3"></i>
                                        <p class="text-muted">No notes available for this appointment.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div><!-- col-12 -->
            </div><!-- row -->
        </main>
    </div>
</div>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn = document.getElementById('closeSidebar');
    var sidebar = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar) closeBtn.onclick = () => sidebar.classList.add('hide');
});
</script>
