<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Doctor $doctor
 */

// Page-specific CSS (same style family)
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Doctors Admin Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width:120px;height:120px;">
                <?= $this->Html->image('logo.png', ['alt'=>'Elara Clinic Logo','class'=>'logo-img']) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                    ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                    ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                    ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                    ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                    ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                    ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                    ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                    ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-clipboard-pulse"></i> Treatments',
                    ['prefix'=>'Admin','controller'=>'Treatments','action'=>'index'],
                    ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                    ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                    ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                    ['controller'=>'Users','action'=>'logout'],
                    ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="fas fa-bars"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Add Doctor</h5>
                <h5 class="m-0 d-md-none">Add</h5>
            </div>

            <!-- Header Actions -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="fas fa-arrow-left me-2"></i> Back',
                    ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                    ['class'=>'btn btn-outline-light btn-sm','escape'=>false,'escapeTitle'=>false]
                ) ?>

                <div class="dropdown">
                    <button class="btn btn-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-gear me-1"></i> Actions
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><?= $this->Html->link(
                            '<i class="fas fa-list me-2"></i> List Doctors',
                            ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                            ['class'=>'dropdown-item','escape'=>false,'escapeTitle'=>false]
                        ) ?></li>
                    </ul>
                </div>
            </div>
        </header>

        <!-- CONTENT -->
        <main class="content-area">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="card-modern shadow-lg">
                        <div class="card-header bg-transparent border-bottom py-4">
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <i class="fa-solid fa-user-doctor text-primary fs-3"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0 fw-bold text-primary">Add Doctor Information</h4>
                                    <p class="text-muted mb-0">Fill in the details to register a new doctor</p>
                                </div>
                            </div>
                        </div>

                        <div class="card-body p-4 p-lg-5">
                            <?= $this->Form->create($doctor) ?>

                            <div class="row g-3">
                                <div class="col-12">
                                    <h5 class="section-title mb-3">
                                        <i class="fa-solid fa-id-card me-2"></i>
                                        Doctor Information
                                    </h5>
                                </div>

                                <div class="col-md-6">
                                    <?= $this->Form->control('fullname', [
                                        'label' => 'Full Name',
                                        'class' => 'form-control form-control-lg',
                                        'placeholder' => 'e.g., Dr. John Smith',
                                    ]) ?>
                                    <small class="form-text text-muted">Enter doctor’s full name</small>
                                </div>

                                <div class="col-md-6">
                                    <?= $this->Form->control('specialization', [
                                        'label' => 'Specialization',
                                        'class' => 'form-control form-control-lg',
                                        'placeholder' => 'e.g., General Doctor, Cardiology',
                                    ]) ?>
                                    <small class="form-text text-muted">Medical specialization</small>
                                </div>

                                <div class="col-12 mt-4">
                                    <h5 class="section-title mb-3">
                                        <i class="fa-solid fa-circle-info me-2"></i>
                                        Status Information
                                    </h5>
                                </div>

                                <div class="col-md-6">
                                    <?= $this->Form->control('status', [
                                        'label' => 'Status',
                                        'class' => 'form-control form-control-lg',
                                        'options' => [
                                            1 => 'Active',
                                            2 => 'Inactive',
                                            3 => 'On Leave',
                                            4 => 'Retired',
                                        ],
                                        'empty' => false,
                                        'value' => $doctor->status ?? 1
                                    ]) ?>
                                    <small class="form-text text-muted">Doctor’s current status</small>
                                </div>
                            </div>

                            <!-- Form Actions -->
                            <div class="d-flex justify-content-between align-items-center mt-5 pt-4 border-top">
                                <div>
                                    <?= $this->Html->link(
                                        '<i class="fa-solid fa-xmark-circle me-2"></i> Cancel',
                                        ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                                        ['class'=>'btn btn-lg btn-outline-secondary','escape'=>false,'escapeTitle'=>false]
                                    ) ?>
                                </div>

                                <div class="d-flex gap-3">
                                    <?= $this->Form->button(
                                        '<i class="fa-solid fa-rotate-right me-2"></i> Reset',
                                        [
                                            'type' => 'reset',
                                            'class' => 'btn btn-lg btn-outline-warning',
                                            'escape' => false,
                                            'escapeTitle' => false
                                        ]
                                    ) ?>

                                    <?= $this->Form->button(
                                        '<i class="fa-solid fa-paper-plane me-2"></i> Submit',
                                        [
                                            'type' => 'submit',
                                            'class' => 'btn btn-lg btn-primary px-5 fw-bold',
                                            'escape' => false,
                                            'escapeTitle' => false
                                        ]
                                    ) ?>
                                </div>
                            </div>

                            <?= $this->Form->end() ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    const toggleBtn = document.getElementById('toggleSidebar');
    const closeBtn = document.getElementById('closeSidebar');
    const sidebar = document.getElementById('sidebar');

    if (toggleBtn && sidebar) {
        toggleBtn.onclick = function () {
            sidebar.classList.toggle('hide');
        };
    }

    if (closeBtn && sidebar) {
        closeBtn.onclick = function () {
            sidebar.classList.add('hide');
        };
    }

    // Auto-capitalize fullname + specialization (same as your edit page style)
    const fullname = document.getElementById('fullname');
    if (fullname) {
        fullname.addEventListener('blur', function() {
            this.value = this.value.replace(/\b\w/g, c => c.toUpperCase());
        });
    }

    const specialization = document.getElementById('specialization');
    if (specialization) {
        specialization.addEventListener('blur', function() {
            this.value = this.value.replace(/\b\w/g, c => c.toUpperCase());
        });
    }
});
</script>
