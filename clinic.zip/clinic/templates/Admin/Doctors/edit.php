<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Doctor $doctor
 */
// Page-specific CSS
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" 
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Doctor Admin Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>
            
            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'escapeTitle'=>false, 'class' => 'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>
        
        <!-- Sidebar Footer -->
        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="fas fa-bars"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Edit Doctor: <?= h($doctor->fullname) ?></h5>
                <h5 class="m-0 d-md-none">Edit Doctor</h5>
            </div>

            <!-- Action Buttons -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
                
                <div class="dropdown">
                    <button class="btn btn-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-gear me-1"></i> Actions
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><?= $this->Html->link(
                            '<i class="fas fa-eye me-2"></i> View Doctor',
                            ['action' => 'view', $doctor->id],
                            ['class' => 'dropdown-item', 'escape' => false, 'escapeTitle' => false]
                        ) ?></li>
                        <li><?= $this->Form->postLink(
                            '<i class="fas fa-trash me-2"></i> Delete Doctor',
                            ['action' => 'delete', $doctor->id],
                            [
                                'confirm' => __('Are you sure you want to delete doctor: "{0}"?', $doctor->fullname),
                                'class' => 'dropdown-item text-danger',
                                'escape' => false,
                                'escapeTitle' => false
                            ]
                        ) ?></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><?= $this->Html->link(
                            '<i class="fas fa-list me-2"></i> All Doctors',
                            ['action' => 'index'],
                            ['class' => 'dropdown-item', 'escape' => false, 'escapeTitle' => false]
                        ) ?></li>
                        <li><?= $this->Html->link(
                            '<i class="fas fa-user-plus me-2"></i> New Doctor',
                            ['action' => 'add'],
                            ['class' => 'dropdown-item', 'escape' => false, 'escapeTitle' => false]
                        ) ?></li>
                    </ul>
                </div>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <!-- Edit Form Card -->
                    <div class="card-modern shadow-lg">
                        <div class="card-header bg-transparent border-bottom py-4">
                            <div class="d-flex align-items-center">
                                <div class="edit-icon me-3">
                                    <i class="fa-solid fa-user-doctor text-primary fs-3"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0 fw-bold text-primary">Edit Doctor Information</h4>
                                    <p class="text-muted mb-0">Update the details for Dr. <?= h($doctor->fullname) ?></p>
                                </div>
                                <div class="ms-auto">
                                    <span class="badge bg-info fs-6">ID: <?= $this->Number->format($doctor->id) ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-body p-4 p-lg-5">
                            <?= $this->Form->create($doctor) ?>
                            
                            <div class="row g-3">
                                <!-- Doctor Information -->
                                <div class="col-12">
                                    <h5 class="section-title mb-4">
                                        <i class="fa-solid fa-id-card me-2"></i>
                                        Doctor Information
                                    </h5>
                                </div>
                                
                                <div class="col-md-6">
                                    <?= $this->Form->control('fullname', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => 'Full Name',
                                        'placeholder' => 'Enter doctor\'s full name',
                                        'value' => $doctor->fullname
                                    ]) ?>
                                    <small class="form-text text-muted">e.g., Dr. John Smith</small>
                                </div>
                                
                                <div class="col-md-6">
                                    <?= $this->Form->control('specialization', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => 'Specialization',
                                        'placeholder' => 'e.g., Cardiology, Pediatrics',
                                        'value' => $doctor->specialization
                                    ]) ?>
                                    <small class="form-text text-muted">Medical specialization</small>
                                </div>
                                
                                <!-- Status Information -->
                                <div class="col-12 mt-4">
                                    <h5 class="section-title mb-4">
                                        <i class="fa-solid fa-circle-info me-2"></i>
                                        Status Information
                                    </h5>
                                </div>
                                
                                <div class="col-md-6">
                                    <?= $this->Form->control('status', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => 'Status',
                                        'options' => [
                                            1 => 'Active',
                                            2 => 'Inactive',
                                            3 => 'On Leave',
                                            4 => 'Retired'
                                        ],
                                        'value' => $doctor->status ?? 1
                                    ]) ?>
                                    <small class="form-text text-muted">Doctor's current status</small>
                                </div>
                                
                                <!-- Record Information -->
                                <div class="col-12 mt-4">
                                    <h5 class="section-title mb-4">
                                        <i class="fa-solid fa-clock-rotate-left me-2"></i>
                                        Record Information
                                    </h5>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">Created On</label>
                                        <input type="text" class="form-control form-control-lg bg-light" 
                                               value="<?= h($doctor->created) ?>" readonly>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">Last Modified</label>
                                        <input type="text" class="form-control form-control-lg bg-light" 
                                               value="<?= h($doctor->modified) ?>" readonly>
                                    </div>
                                </div>
                                
                                <!-- Current Status Display -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">Current Status</label>
                                        <input type="text" class="form-control form-control-lg bg-light" 
                                               value="<?= 
                                                   $doctor->status == 1 ? 'Active' : 
                                                   ($doctor->status == 2 ? 'Inactive' : 
                                                   ($doctor->status == 3 ? 'On Leave' : 
                                                   ($doctor->status == 4 ? 'Retired' : 'Unknown')))
                                               ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Form Actions -->
                            <div class="d-flex justify-content-between align-items-center mt-5 pt-4 border-top">
                                <div>
                                    <?= $this->Html->link(
                                        '<i class="fa-solid fa-xmark-circle me-2"></i> Cancel',
                                        ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'view', $doctor->id],
                                        [
                                            'class' => 'btn btn-lg btn-outline-secondary',
                                            'escape' => false,
                                            'escapeTitle' => false
                                        ]
                                    ) ?>
                                </div>
                                
                                <div class="d-flex gap-3">
                                    <?= $this->Form->button(
                                        '<i class="fa-solid fa-rotate-right me-2"></i> Reset',
                                        [
                                            'type' => 'reset',
                                            'class' => 'btn btn-lg btn-outline-warning',
                                            'escape' => false,
                                            'escapeTitle' => false
                                        ]
                                    ) ?>
                                    
                                    <?= $this->Form->button(
                                        '<i class="fa-solid fa-floppy-disk me-2"></i> Save Changes',
                                        [
                                            'type' => 'submit',
                                            'class' => 'btn btn-lg btn-primary px-5 fw-bold',
                                            'escape' => false,
                                            'escapeTitle' => false
                                        ]
                                    ) ?>
                                </div>
                            </div>
                            
                            <?= $this->Form->end() ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i>
                    Confirm Doctor Deletion
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <div class="mb-4">
                    <i class="fa-solid fa-user-doctor-slash fa-4x text-danger"></i>
                </div>
                <h5 class="mb-3">Are you sure?</h5>
                <p class="text-muted">
                    You are about to delete doctor:<br>
                    <strong class="text-danger">Dr. <?= h($doctor->fullname) ?></strong><br>
                    <small>(ID: <?= $this->Number->format($doctor->id) ?>)</small>
                </p>
                <p class="text-warning">
                    <i class="fa-solid fa-exclamation-triangle me-1"></i>
                    This will remove the doctor from all appointments and cannot be undone.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fa-solid fa-xmark me-1"></i>
                    Cancel
                </button>
                <?= $this->Form->postLink(
                    '<i class="fa-solid fa-trash me-1"></i> Delete Doctor',
                    ['action' => 'delete', $doctor->id],
                    [
                        'class' => 'btn btn-danger',
                        'escape' => false,
                        'escapeTitle' => false
                    ]
                ) ?>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<?= $this->Html->scriptBlock('
document.addEventListener("DOMContentLoaded", function() {
    // Sidebar toggle
    const toggleBtn = document.getElementById("toggleSidebar");
    const sidebar = document.getElementById("sidebar");
    
    if (toggleBtn && sidebar) {
        toggleBtn.onclick = function() {
            sidebar.classList.toggle("hide");
        };
    }
    
    // Auto-capitalize name
    const nameInput = document.getElementById("fullname");
    if (nameInput) {
        nameInput.addEventListener("blur", function() {
            this.value = this.value.replace(/\\b\\w/g, function(char) {
                return char.toUpperCase();
            });
        });
    }
    
    // Auto-capitalize specialization
    const specializationInput = document.getElementById("specialization");
    if (specializationInput) {
        specializationInput.addEventListener("blur", function() {
            this.value = this.value.replace(/\\b\\w/g, function(char) {
                return char.toUpperCase();
            });
        });
    }
});
') ?>
