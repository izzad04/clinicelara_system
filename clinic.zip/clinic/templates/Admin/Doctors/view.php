<?php
// Page-specific CSS
echo $this->Html->css('doctor_admin');
echo $this->Html->css('appointment_admin');
echo $this->Html->css('view_doctors');

/**
 * Parse appointment datetime from your formats:
 * Example from your UI: 1/12/26 and 12:30 PM
 */
function parseAppointmentDateTime($dateStr, $timeStr): ?DateTime
{
    $dateStr = trim((string)$dateStr);
    $timeStr = trim((string)$timeStr);

    if ($dateStr === '' || $timeStr === '') {
        return null;
    }

    // ✅ month/day/year format ONLY
    $formats = [
        // UI format examples: 1/12/26 12:30 PM  (m/d/y)
        'm/d/y g:i A',
        'm/d/y h:i A',
        'm/d/y H:i',
        'm/d/y H:i:s',

        // If sometimes full year: 1/12/2026 (m/d/Y)
        'm/d/Y g:i A',
        'm/d/Y h:i A',
        'm/d/Y H:i',
        'm/d/Y H:i:s',
    ];

    foreach ($formats as $fmt) {
        $dt = DateTime::createFromFormat($fmt, $dateStr . ' ' . $timeStr);
        if ($dt instanceof DateTime) {
            return $dt;
        }
    }

    return null;
}

?>

<!-- Admin Doctor View Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>
            
            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>
            
            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>
        
        <!-- Sidebar Footer -->
        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Doctor Profile: Dr. <?= h($doctor->fullname) ?></h5>
                <h5 class="m-0 d-md-none">Dr. <?= h($doctor->fullname) ?></h5>
            </div>

            <!-- Action Buttons -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <div class="content-container">
                <!-- Main Content -->
                <div class="doctor-profile-section">
                    <!-- Profile Header -->
                    <div class="profile-header">
                        <div class="profile-avatar">
                            <div class="avatar-circle">
                                <i class="bi bi-person-badge"></i>
                            </div>
                        </div>
                        <div class="profile-info">
                            <h2>Dr. <?= h($doctor->fullname) ?></h2>
                            <div class="profile-tags">
                                <?php 
                                $statusText = '';
                                $statusClass = 'tag';
                                if ($doctor->status == 1) {
                                    $statusText = 'Active';
                                    $statusClass = 'tag-success';
                                } elseif ($doctor->status == 2) {
                                    $statusText = 'Inactive';
                                    $statusClass = 'tag-danger';
                                } elseif ($doctor->status == 3) {
                                    $statusText = 'On Leave';
                                    $statusClass = 'tag-warning';
                                } elseif ($doctor->status == 4) {
                                    $statusText = 'Retired';
                                    $statusClass = 'tag-info';
                                } else {
                                    $statusText = 'Unknown';
                                }
                                ?>
                                <span class="tag <?= $statusClass ?>">
                                    <i class="bi bi-circle-fill"></i> <?= $statusText ?>
                                </span>
                                <span class="tag tag-info">
                                    <i class="bi bi-star"></i> <?= h($doctor->specialization) ?>
                                </span>
                                <span class="tag">
                                    <i class="bi bi-hash"></i> ID: #<?= h($doctor->id) ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Details Grid -->
                    <div class="details-grid">
                        <!-- Doctor ID -->
                        <div class="detail-card">
                            <div class="detail-icon">
                                <i class="bi bi-person-vcard"></i>
                            </div>
                            <div class="detail-content">
                                <label>Doctor ID</label>
                                <h3>#<?= h($doctor->id) ?></h3>
                            </div>
                        </div>

                        <!-- Specialization -->
                        <div class="detail-card">
                            <div class="detail-icon">
                                <i class="bi bi-award"></i>
                            </div>
                            <div class="detail-content">
                                <label>Specialization</label>
                                <h3><?= h($doctor->specialization) ?></h3>
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="detail-card">
                            <div class="detail-icon">
                                <i class="bi bi-info-circle"></i>
                            </div>
                            <div class="detail-content">
                                <label>Current Status</label>
                                <h3><?= $statusText ?></h3>
                            </div>
                        </div>

                        <!-- Member Since -->
                        <div class="detail-card">
                            <div class="detail-icon">
                                <i class="bi bi-calendar-plus"></i>
                            </div>
                            <div class="detail-content">
                                <label>Member Since</label>
                                <h3>
                                    <?php if ($doctor->created): ?>
                                        <?= h($doctor->created->format('M d, Y')) ?>
                                    <?php else: ?>
                                        <span class="text-muted">Not set</span>
                                    <?php endif; ?>
                                </h3>
                                <small>
                                    <?php if ($doctor->created): ?>
                                        <i class="bi bi-clock-history me-1"></i> <?= h($doctor->created->format('h:i A')) ?>
                                    <?php else: ?>
                                        <span class="text-muted">No timestamp</span>
                                    <?php endif; ?>
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- Appointments Section -->
                    <div class="appointments-section">
                        <div class="section-header">
                            <h3>
                                <i class="bi bi-calendar-check"></i>
                                Appointments
                                <span class="badge"><?= !empty($doctor->appointments) ? count($doctor->appointments) : 0 ?></span>
                            </h3>
                        </div>

                        <?php if (!empty($doctor->appointments)): ?>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Date & Time</th>
                                            <th>Patient</th>
                                            <th>Type</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $now = new DateTime('now');
                                        foreach ($doctor->appointments as $appointment):

                                            // ✅ AUTO COMPLETED LOGIC
                                            $dt = parseAppointmentDateTime($appointment->date, $appointment->time);
                                            $isPast = ($dt instanceof DateTime) ? ($dt < $now) : false;
                                            $isCancelledOrNoShow = in_array((int)$appointment->status, [4,5], true);

                                            $statusBadge = '';

                                            if ($isPast && !$isCancelledOrNoShow) {
                                                $statusBadge = '<span class="status-badge status-completed"><i class="bi bi-check-all"></i> Completed</span>';
                                            } else {
                                                if ($appointment->status == 1) {
                                                    $statusBadge = '<span class="status-badge status-active"><i class="bi bi-clock"></i> Scheduled</span>';
                                                } elseif ($appointment->status == 2) {
                                                    $statusBadge = '<span class="status-badge status-active"><i class="bi bi-check-circle"></i> Confirmed</span>';
                                                } elseif ($appointment->status == 3) {
                                                    $statusBadge = '<span class="status-badge status-completed"><i class="bi bi-check-all"></i> Completed</span>';
                                                } elseif ($appointment->status == 4) {
                                                    $statusBadge = '<span class="status-badge status-cancelled"><i class="bi bi-x-circle"></i> Cancelled</span>';
                                                } elseif ($appointment->status == 5) {
                                                    $statusBadge = '<span class="status-badge status-cancelled"><i class="bi bi-person-x"></i> No Show</span>';
                                                } else {
                                                    $statusBadge = '<span class="status-badge">Unknown</span>';
                                                }
                                            }
                                        ?>
                                        <tr>
                                            <td>
                                                <div class="datetime-cell">
                                                    <strong><?= h($appointment->date) ?></strong>
                                                    <small><?= h($appointment->time) ?></small>
                                                </div>
                                            </td>
                                            <td>
                                                <?php if ($appointment->has('patient')): ?>
                                                    <?= h($appointment->patient->fullname) ?>
                                                <?php else: ?>
                                                    Patient #<?= h($appointment->patient_id) ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary">Consultation</span>
                                            </td>
                                            <td><?= $statusBadge ?></td>
                                            <td>
                                            <div class="action-buttons d-flex gap-2">
                                                <?= $this->Html->link(
                                                    '<i class="bi bi-eye"></i>',
                                                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'view', $appointment->id],
                                                    [
                                                        'class' => 'btn btn-sm btn-outline-primary',
                                                        'escape' => false,
                                                        'title' => 'View'
                                                    ]
                                                ) ?>

                                                <?= $this->Html->link(
                                                    '<i class="bi bi-pencil"></i>',
                                                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'edit', $appointment->id],
                                                    [
                                                        'class' => 'btn btn-sm btn-outline-warning',
                                                        'escape' => false,
                                                        'title' => 'Edit'
                                                    ]
                                                ) ?>
                                            </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="bi bi-calendar-x"></i>
                                <p>No appointments scheduled for this doctor</p>
                                <?= $this->Html->link(
                                    '<i class="bi bi-calendar-plus me-2"></i> Schedule First Appointment',
                                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'add'],
                                    ['class' => 'btn btn-primary']
                                ) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Right Sidebar -->
                <div class="right-sidebar">
                    <!-- Statistics -->
                    <div class="sidebar-card">
                        <h4><i class="bi bi-graph-up"></i> Statistics</h4>
                        <ul class="stats-list">
                            <li>
                                <span>Total Appointments</span>
                                <strong><?= !empty($doctor->appointments) ? count($doctor->appointments) : 0 ?></strong>
                            </li>

                            <li>
                                <span>Active Appointments</span>
                                <?php 
                                $activeCount = 0;
                                $completedCountAuto = 0;
                                $now = new DateTime('now');

                                if (!empty($doctor->appointments)) {
                                    foreach ($doctor->appointments as $app) {
                                        $dt = parseAppointmentDateTime($app->date, $app->time);
                                        $isPast = ($dt instanceof DateTime) ? ($dt < $now) : false;
                                        $isCancelledOrNoShow = in_array((int)$app->status, [4,5], true);

                                        // completed if status=3 OR already past (unless cancelled/no show)
                                        if ($app->status == 3 || ($isPast && !$isCancelledOrNoShow)) {
                                            $completedCountAuto++;
                                            continue;
                                        }

                                        // active = scheduled or confirmed
                                        if ($app->status == 1 || $app->status == 2) {
                                            $activeCount++;
                                        }
                                    }
                                }
                                ?>
                                <span class="badge success"><?= $activeCount ?></span>
                            </li>

                            <li>
                                <span>Completed</span>
                                <span class="badge bg-secondary"><?= $completedCountAuto ?></span>
                            </li>
                        </ul>
                    </div>

                    <!-- Contact Info -->
                    <div class="sidebar-card">
                        <h4><i class="bi bi-telephone"></i> Contact Information</h4>
                        <div class="contact-info">
                            <div class="contact-item">
                                <i class="bi bi-envelope"></i>
                                <span><?= strtolower(str_replace(' ', '.', $doctor->fullname)) ?>@elaraclinic.com</span>
                            </div>
                            <div class="contact-item">
                                <i class="bi bi-phone"></i>
                                <span>+60 12-345 6789</span>
                            </div>
                            <div class="contact-item">
                                <i class="bi bi-clock"></i>
                                <span>Office Hours: 8AM - 6PM</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    const toggleBtn = document.getElementById('toggleSidebar');
    if (toggleBtn) {
        toggleBtn.onclick = function () {
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                sidebar.classList.toggle('hide');
            }
        };
    }
    
    // Close sidebar (for mobile close button)
    const closeBtn = document.getElementById('closeSidebar');
    if (closeBtn) {
        closeBtn.onclick = function () {
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                sidebar.classList.add('hide');
            }
        };
    }
    
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>
