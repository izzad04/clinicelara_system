<?php
echo $this->Html->css('appointment_admin');
?>

<style>
/* =========================
   SEARCH (box + same height)
   ========================= */
.search-form { margin: 0; }
.search-wrap {
    display: flex !important;
    align-items: center !important;
    gap: 10px;
    flex-wrap: wrap;
}
.search-input {
    height: 44px !important;
    line-height: 44px !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    border-radius: 10px !important;
}
.search-btn {
    height: 44px !important;
    width: 44px !important;
    padding: 0 !important;
    border-radius: 10px !important;
    background: #fff !important;
    border: 1px solid rgba(255,255,255,0.35) !important;
    cursor: pointer !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
}
@media (max-width: 768px) {
    .search-wrap { gap: 8px; }
}

/* =========================================================
   Remove horizontal scrollbar
   ========================================================= */
.table-no-scroll { overflow-x: hidden; }

/* =========================================================
   STATUS: clean text (not boxed)
   ========================================================= */
.status-text {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.status-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: #adb5bd;
}
.status-text-active { color: #198754; }
.status-text-active .status-dot { background: #198754; }

.status-text-inactive { color: #d39e00; }
.status-text-inactive .status-dot { background: #d39e00; }

.status-text-leave { color: #0dcaf0; }
.status-text-leave .status-dot { background: #0dcaf0; }

.status-text-retired { color: #6c757d; }
.status-text-retired .status-dot { background: #6c757d; }

.status-text-default { color: #6c757d; }
.status-text-default .status-dot { background: #adb5bd; }

/* =========================================================
   ACTIONS
   ========================================================= */
.action-buttons {
    display: inline-flex;
    gap: 10px;
    align-items: center;
    justify-content: center;
}
.action-btn {
    width: 34px;
    height: 34px;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 1px solid #dee2e6;
    background: #fff;
    cursor: pointer;
    text-decoration: none;
    transition: transform .12s ease, box-shadow .12s ease;
}
.action-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 14px rgba(0,0,0,0.08);
}
.action-view { color: #0d6efd; border-color: #0d6efd; }
.action-edit { color: #ffc107; border-color: #ffc107; }
.action-delete { color: #dc3545; border-color: #dc3545; }

/* Existing styles */
.doctor-avatar { width: 40px; height: 40px; }
.avatar-circle-sm {
    width: 40px; height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
    color: white;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.2rem;
}
.specialization-badge {
    background: rgba(23, 162, 184, 0.1);
    color: #17a2b8;
    padding: 4px 12px;
    border-radius: 15px;
    font-size: 0.85rem;
    font-weight: 500;
    border: 1px solid rgba(23, 162, 184, 0.2);
}
.table-modern tbody tr { transition: all 0.2s ease; }
.table-modern tbody tr:hover {
    background-color: rgba(248, 182, 200, 0.1);
    transform: translateX(3px);
}
</style>

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix'=>'Admin','controller'=>'Treatments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Doctors Management</h5>
                <h5 class="m-0 d-md-none">Doctors</h5>
            </div>

            <!-- (NO SEARCH HERE) -->
            <div></div>
        </header>

        <main class="content-area">
            <!-- STATS -->
            <div class="row mb-4 g-3">
                <div class="col-md-4">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-person-badge fs-1 text-primary"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $total_doctors ?? 0 ?></h3>
                        <p class="text-muted mb-0">Total Doctors</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-check-circle fs-1 text-success"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $total_doctors_active ?? 0 ?></h3>
                        <p class="text-muted mb-0">Active Doctors</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-archive fs-1 text-warning"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $total_doctors_archived ?? 0 ?></h3>
                        <p class="text-muted mb-0">Archived Doctors</p>
                    </div>
                </div>
            </div>

            <div class="card-modern shadow-sm mb-4">
                <div class="card-body">
                    <?= $this->Form->create(null, [
                        'valueSources' => 'query',
                        'url' => ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                        'type' => 'get',
                        'class' => 'search-form'
                    ]) ?>

                    <div class="search-wrap">
                        <?= $this->Form->control('id', [
                            'label' => false,
                            'placeholder' => 'Doctor ID (number)',
                            'class' => 'form-control search-input',
                            'style' => 'width:140px;',
                            'value' => $this->request->getQuery('id'),
                            'type' => 'number',
                            'min' => 1
                        ]) ?>

                        <?= $this->Form->control('doctor', [
                            'label' => false,
                            'placeholder' => 'Doctor name',
                            'class' => 'form-control search-input',
                            'style' => 'width:260px;',
                            'value' => $this->request->getQuery('doctor'),
                            'type' => 'text'
                        ]) ?>

                        <?= $this->Form->button('<i class="bi bi-search-heart-fill"></i>', [
                            'class' => 'btn search-btn',
                            'escape' => false,
                            'title' => 'Search',
                            'escapeTitle' => false,
                        ]) ?>

                        <?= $this->Html->link('<i class="bi bi-x-lg"></i>',
                            ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                            ['class' => 'btn search-btn', 'escape' => false, 'title' => 'Reset']
                        ) ?>
                    </div>

                    <?= $this->Form->end() ?>
                </div>
            </div>

            <!-- TABLE CARD -->
            <div class="card-modern shadow-sm">
                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center py-3">
                    <h6 class="mb-0 fw-bold">Doctors Management</h6>

                    <?= $this->Html->link(
                        '<i class="bi bi-plus-circle me-2"></i> Add New Doctor',
                        ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'add'],
                        [
                            'class' => 'btn btn-primary fw-bold',
                            'escape' => false,
                            'style' => '
                                background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
                                border: none;
                                border-radius: 8px;
                                padding: 10px 20px;
                                box-shadow: 0 4px 12px rgba(165, 56, 96, 0.3);
                                transition: all 0.3s ease;
                            '
                        ]
                    ) ?>
                </div>

                <div class="table-no-scroll">
                    <table class="table table-modern table-hover mb-0 w-100">
                        <thead class="table-light">
                        <tr>
                            <th style="width:80px;">ID</th>
                            <th>Doctor Name</th>
                            <th style="width:160px;">Specialization</th>
                            <th style="width:120px;">Status</th>
                            <th style="width:150px;">Created</th>
                            <th class="text-center" style="width:150px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($doctors as $doctor): ?>
                            <tr>
                                <!-- ✅ ONLY Doctor ID (no more 1,2,3 column) -->
                                <td><span class="badge bg-secondary">#<?= h($doctor->id) ?></span></td>

                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="doctor-avatar me-2">
                                            <div class="avatar-circle-sm">
                                                <i class="bi bi-person-badge"></i>
                                            </div>
                                        </div>
                                        <div>
                                            <strong>Dr. <?= h($doctor->fullname) ?></strong>
                                            <div class="small text-muted">ID: <?= h($doctor->id) ?></div>
                                        </div>
                                    </div>
                                </td>

                                <td>
                                    <span class="specialization-badge">
                                        <?= h($doctor->specialization) ?>
                                    </span>
                                </td>

                                <td>
                                    <?php
                                    $statusText = [
                                        1 => 'Active',
                                        2 => 'Inactive',
                                        3 => 'On Leave',
                                        4 => 'Retired'
                                    ];
                                    $statusTextClass = [
                                        1 => 'status-text-active',
                                        2 => 'status-text-inactive',
                                        3 => 'status-text-leave',
                                        4 => 'status-text-retired'
                                    ];
                                    ?>
                                    <span class="status-text <?= $statusTextClass[$doctor->status] ?? 'status-text-default' ?>">
                                        <span class="status-dot"></span>
                                        <?= $statusText[$doctor->status] ?? 'Unknown' ?>
                                    </span>
                                </td>

                                <td>
                                    <small class="text-muted">
                                        <?php if ($doctor->created): ?>
                                            <?= h($doctor->created->format('M d, Y')) ?><br>
                                            <?= h($doctor->created->format('h:i A')) ?>
                                        <?php else: ?>
                                            <span class="text-muted fst-italic">Not set</span>
                                        <?php endif; ?>
                                    </small>
                                </td>

                                <td class="text-center">
                                    <div class="action-buttons">
                                        <?= $this->Html->link(
                                            '<i class="bi bi-eye"></i>',
                                            ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'view', $doctor->id],
                                            [
                                                'class' => 'action-btn action-view',
                                                'title' => 'View Details',
                                                'escape' => false,
                                                'escapeTitle' => false,
                                                'data-bs-toggle' => 'tooltip'
                                            ]
                                        ) ?>

                                        <?= $this->Html->link(
                                            '<i class="bi bi-pencil"></i>',
                                            ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'edit', $doctor->id],
                                            [
                                                'class' => 'action-btn action-edit',
                                                'title' => 'Edit Doctor',
                                                'escape' => false,
                                                'escapeTitle' => false,
                                                'data-bs-toggle' => 'tooltip'
                                            ]
                                        ) ?>

                                        <?= $this->Form->postLink(
                                            '<i class="bi bi-trash"></i>',
                                            ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'delete', $doctor->id],
                                            [
                                                'class' => 'action-btn action-delete',
                                                'title' => 'Delete Doctor',
                                                'escape' => false,
                                                'escapeTitle' => false,
                                                'data-bs-toggle' => 'tooltip',
                                                'confirm' => sprintf('Are you sure you want to delete Dr. %s ?', h($doctor->fullname))
                                            ]
                                        ) ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="card-footer bg-white border-top py-3">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="text-muted small">
                                <?= $this->Paginator->counter(__('Showing {{start}} to {{end}} of {{count}} doctors')) ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <nav aria-label="Page navigation" class="float-md-end">
                                <ul class="pagination pagination-sm justify-content-center mb-0">
                                    <?= $this->Paginator->first('<i class="bi bi-chevron-double-left"></i>', ['escape' => false]) ?>
                                    <?= $this->Paginator->prev('<i class="bi bi-chevron-left"></i>', ['escape' => false]) ?>
                                    <?= $this->Paginator->numbers() ?>
                                    <?= $this->Paginator->next('<i class="bi bi-chevron-right"></i>', ['escape' => false]) ?>
                                    <?= $this->Paginator->last('<i class="bi bi-chevron-double-right"></i>', ['escape' => false]) ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (el) { return new bootstrap.Tooltip(el); });

    // sidebar
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn = document.getElementById('closeSidebar');
    var sidebar = document.getElementById('sidebar');
    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar) closeBtn.onclick = () => sidebar.classList.add('hide');
});
</script>
