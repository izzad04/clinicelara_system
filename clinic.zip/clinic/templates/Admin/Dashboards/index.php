<?php
// Page-specific CSS
echo $this->Html->css('dashboard_admin');
echo $this->Html->css('appointment_admin');
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Admin Dashboard Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>
            
            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>
        
        <!-- Sidebar Footer -->
        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Dashboard Overview</h5>
                <h5 class="m-0 d-md-none">Dashboard</h5>
            </div>

            <div class="d-flex align-items-center gap-3">
                <div class="date-display">
                    <i class="bi bi-calendar3 me-2"></i>
                    <span id="current-date"><?= date('F j, Y') ?></span>
                </div>
                <div class="user-profile">
                    <div class="dropdown">
                        <button class="btn btn-light btn-sm dropdown-toggle d-flex align-items-center" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-2"></i>
                            <span>Admin User</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="#"><i class="bi bi-gear me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><?= $this->Html->link(
                                '<i class="bi bi-box-arrow-right me-2"></i> Logout',
                                ['controller'=>'Users','action'=>'logout'],
                                ['class' => 'dropdown-item text-danger', 'escape' => false]
                            ) ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <!-- WELCOME CARD -->
            <div class="card-modern shadow-lg mb-4 welcome-card">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="fw-bold mb-2">Welcome back, Administrator! 👋</h3>
                            <p class="text-muted mb-0">Here's what's happening with your clinic today. You have 
                                <strong><?= $todayAppointments ?? 0 ?> appointments</strong> scheduled for <?= date('F j, Y') ?>.
                            </p>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <div class="quick-stats">
                                <div class="stat-item">
                                    <i class="bi bi-clock-history text-primary"></i>
                                    <span class="ms-2">Clinic Hours: 8AM - 8PM</span>
                                </div>
                                <div class="stat-item mt-2">
                                    <i class="bi bi-telephone text-success"></i>
                                    <span class="ms-2">Emergency: 24/7</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- STATS CARDS -->
            <div class="row mb-4 g-3">
                <!-- Total Appointments -->
                <div class="col-xl-4 col-md-6">
                    <div class="card-modern stats-card">
                        <div class="card-body text-center">
                            <div class="stats-icon bg-primary">
                                <i class="bi bi-calendar2-check"></i>
                            </div>
                            <h3 class="stats-number mt-3"><?= $totalAppointments ?? 0 ?></h3>
                            <p class="stats-label">Total Appointments</p>
                            <div class="stats-trend text-success">
                               
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Active Patients -->
                <div class="col-xl-4 col-md-6">
                    <div class="card-modern stats-card">
                        <div class="card-body text-center">
                            <div class="stats-icon bg-success">
                                <i class="bi bi-people"></i>
                            </div>
                            <h3 class="stats-number mt-3"><?= $totalPatients ?? 0 ?></h3>
                            <p class="stats-label">Total Patients</p>
                            <div class="stats-trend text-success">

                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Available Doctors -->
                <div class="col-xl-4 col-md-6">
                    <div class="card-modern stats-card">
                        <div class="card-body text-center">
                            <div class="stats-icon bg-warning">
                                <i class="bi bi-person-badge"></i>
                            </div>
                            <h3 class="stats-number mt-3"><?= $totalDoctors ?? 0 ?></h3>
                            <p class="stats-label">Available Doctors</p>
                            <div class="stats-trend text-success">

                            </div>
                        </div>
                    </div>
                </div>
                
            </div>

            <!-- CHARTS & DETAILS -->
            <div class="row g-4">
                <!-- Today's Appointments -->
                <div class="col-lg-8">
                    <div class="card-modern shadow-sm">
                        <div class="card-header bg-transparent border-bottom py-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="mb-0 fw-bold">
                                    <i class="bi bi-calendar-day me-2"></i>Today's Appointments
                                </h5>
                                <?= $this->Html->link(
                                    'View All',
                                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'index'],
                                    ['class' => 'btn btn-sm btn-outline-primary']
                                ) ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($todayAppointmentsList)): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th>Time</th>
                                                <th>Patient</th>
                                                <th>Doctor</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($todayAppointmentsList as $appointment): ?>
                                            <tr>
                                                <td><strong><?= h($appointment['time']) ?></strong></td>
                                                <td><?= h($appointment['patient_name']) ?></td>
                                                <td><?= h($appointment['doctor_name']) ?></td>
                                                <td>
                                                    <span class="badge bg-<?= $appointment['status_color'] ?>">
                                                        <?= h($appointment['status']) ?>
                                                    </span>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-5">
                                    <i class="bi bi-calendar-x text-muted fs-1 mb-3"></i>
                                    <p class="text-muted">No appointments scheduled for today.</p>
                                    <?= $this->Html->link(
                                        'Schedule New Appointment',
                                        ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'add'],
                                        ['class' => 'btn btn-primary']
                                    ) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="col-lg-4">
                    <div class="card-modern shadow-sm">
                        <div class="card-header bg-transparent border-bottom py-3">
                            <h5 class="mb-0 fw-bold">
                                <i class="bi bi-lightning-charge me-2"></i>Quick Actions
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-3">
                                <?= $this->Html->link(
                                    '<i class="bi bi-plus-circle me-2"></i> New Appointment',
                                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'add'],
                                    ['class' => 'btn btn-primary btn-lg', 'escape' => false]
                                ) ?>
                                
                                <?= $this->Html->link(
                                    '<i class="bi bi-person-plus me-2"></i> Add New Patient',
                                    ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'add'],
                                    ['class' => 'btn btn-success btn-lg', 'escape' => false]
                                ) ?>
                                
                                <?= $this->Html->link(
                                    '<i class="bi bi-person-badge me-2"></i> Manage Doctors',
                                    ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'index'],
                                    ['class' => 'btn btn-warning btn-lg', 'escape' => false]
                                ) ?>
                                
                                <?= $this->Html->link(
                                    '<i class="bi bi-file-earmark-text me-2"></i> Generate MC',
                                    ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                                    ['class' => 'btn btn-info btn-lg', 'escape' => false]
                                ) ?>
                            </div>
                        </div>
                    </div>
                </div>
                    <!-- CHART ROW -->
                    <div class="row g-4 mb-4">
                        
                        <!-- Patients Chart -->
                        <div class="col-md-6">
                            <div class="card-modern shadow-sm p-3">
                                <h6 class="fw-bold mb-3">Patients Overview</h6>
                                <canvas id="patientsChart"></canvas>
                            </div>
                        </div>

                        <!-- Appointments Chart -->
                        <div class="col-md-6">
                            <div class="card-modern shadow-sm p-3">
                                <h6 class="fw-bold mb-3">Appointments Overview</h6>
                                <canvas id="appointmentsChart"></canvas>
                            </div>
                        </div>

</div>
            </div>
        </main>
    </div>
</div>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    document.getElementById('toggleSidebar').onclick = function () {
        document.getElementById('sidebar').classList.toggle('hide');
    };
    
    // Update current date and time
    function updateDateTime() {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        };
        document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
    }
    
    // Update time every second
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

const patientsCtx = document.getElementById('patientsChart');
new Chart(patientsCtx, {
  type: 'bar',
  data: {
    labels: ['Active', 'Inactive', 'Archived'],
    datasets: [{
      label: 'Patients',
      data: [
        <?= (int)$activePatients ?>,
        <?= (int)$inactivePatients ?>,
        <?= (int)$archivedPatients ?>
      ],
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    scales: {
      y: { beginAtZero: true }
    }
  }
});

const appointmentsCtx = document.getElementById('appointmentsChart');
new Chart(appointmentsCtx, {
  type: 'line',
  data: {
    labels: ['Today', 'Completed', 'Cancelled'],
    datasets: [{
      label: 'Appointments',
      data: [
        <?= (int)$todayAppointments ?>,
        <?= (int)$completedAppointments ?>,
        <?= (int)$cancelledAppointments ?>
      ],
      tension: 0.3
    }]
  },
  options: {
    responsive: true,
    scales: {
      y: { beginAtZero: true }
    }
  }
});
</script>