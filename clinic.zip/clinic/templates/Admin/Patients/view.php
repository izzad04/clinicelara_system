<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Patient $patient
 */

// Load required CSS/JS
echo $this->Html->css('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css');
echo $this->Html->css('appointment_admin');
echo $this->Html->script('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js');
?>

<style>
/* SIMPLE STYLING THAT WILL WORK */
:root {
    --primary-color: #A53860;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background: #f8f9fa;
    margin: 0;
    padding: 0;
}

.container-fluid {
    padding: 0;
}

/* Sidebar */
#sidebar {
    width: 280px;
    background: white;
    min-height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    transition: 0.3s;
    z-index: 1000;
}

#sidebar.hide {
    transform: translateX(-280px);
}

/* Main Content */
.main-content {
    margin-left: 280px;
    transition: 0.3s;
    min-height: 100vh;
    background: #f8f9fa;
}

#sidebar.hide + .main-content {
    margin-left: 0;
}

/* Header */
.top-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, #c44569 100%);
    color: white;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.toggle-btn {
    background: rgba(255,255,255,0.15);
    border: none;
    color: white;
    width: 45px;
    height: 45px;
    border-radius: 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Patient Profile */
.patient-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, #c44569 100%);
    color: white;
    padding: 30px;
    border-radius: 15px;
    margin: 30px;
    box-shadow: 0 5px 20px rgba(165,56,96,0.2);
}

.patient-avatar {
    width: 100px;
    height: 100px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    border: 4px solid rgba(255,255,255,0.3);
}

.patient-avatar i {
    font-size: 3rem;
    color: var(--primary-color);
}

/* Cards */
.card-modern {
    background: white;
    border-radius: 12px;
    padding: 25px;
    margin: 20px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.08);
    border: 1px solid #eee;
}

/* Responsive */
@media (max-width: 768px) {
    #sidebar {
        position: fixed;
        transform: translateX(-280px);
    }
    
    #sidebar.show {
        transform: translateX(0);
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .patient-header {
        margin: 15px;
        padding: 20px;
    }
}
</style>

<!-- Simple Working Layout -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>
            
            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>
        
        <!-- Sidebar Footer -->
        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    </aside>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <button class="toggle-btn" id="toggleSidebar">
                    <i class="bi bi-list fs-4"></i>
                </button>
                <h5 class="m-0">Patient Profile</h5>
            </div>
            <div class="d-flex gap-2">
                <a href="<?= $this->Url->build(['action' => 'index']) ?>" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-arrow-left me-2"></i> Back
                </a>
            </div>
        </header>

        <!-- Content -->
        <main>
            <!-- Patient Header -->
            <div class="patient-header">
                <div class="text-center">
                    <div class="patient-avatar">
                        <i class="bi bi-person-heart"></i>
                    </div>
                    <h1 class="mb-2"><?= h($patient->fullname) ?></h1>
                    <div class="d-flex justify-content-center gap-2">
                        <span class="badge bg-light text-dark">
                            <i class="bi bi-person me-1"></i>ID: #<?= $patient->id ?>
                        </span>
                        <span class="badge bg-success">
                            <i class="bi bi-check-circle me-1"></i>Active
                        </span>
                    </div>
                </div>
            </div>

            <!-- Patient Info -->
            <div class="row mx-0">
                <div class="col-lg-8">
                    <div class="card-modern">
                        <h4 class="mb-4">
                            <i class="bi bi-person-vcard me-2"></i>Personal Information
                        </h4>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-muted">Full Name</label>
                                <div class="fs-5 fw-semibold"><?= h($patient->fullname) ?></div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-muted">IC Number</label>
                                <div class="fs-5 fw-semibold"><?= h($patient->ic) ?></div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-muted">Phone</label>
                                <div class="fs-5 fw-semibold"><?= h($patient->phone) ?></div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-muted">Email</label>
                                <div class="fs-5 fw-semibold"><?= h($patient->email) ?></div>
                            </div>
                        </div>

                        <h5 class="mt-4 mb-3">
                            <i class="bi bi-geo-alt me-2"></i>Address
                        </h5>
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <div class="text-muted">Street 1</div>
                                <div><?= h($patient->street1) ?></div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="text-muted">Street 2</div>
                                <div><?= h($patient->street2) ?></div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div class="text-muted">City</div>
                                <div><?= h($patient->city) ?></div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div class="text-muted">State</div>
                                <div><?= h($patient->state) ?></div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div class="text-muted">Postcode</div>
                                <div><?= $this->Number->format($patient->postcode) ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card-modern">
                        <h5 class="mb-3">
                            <i class="bi bi-lightning-charge me-2"></i>Quick Actions
                        </h5>
                        <div class="d-grid gap-2">
                            <a href="<?= $this->Url->build(['action' => 'edit', $patient->id]) ?>" 
                               class="btn btn-primary">
                                <i class="bi bi-pencil-square me-2"></i>Edit Profile
                            </a>
                            <a href="#" class="btn btn-success">
                                <i class="bi bi-calendar-plus me-2"></i>New Appointment
                            </a>
                            <a href="<?= $this->Url->build(['action' => 'index']) ?>" 
                               class="btn btn-outline-primary">
                                <i class="bi bi-list-ul me-2"></i>All Patients
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    document.getElementById('toggleSidebar').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('hide');
    });
    
    // Bootstrap tooltips
    var tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(function(el) {
        new bootstrap.Tooltip(el);
    });
});
</script>