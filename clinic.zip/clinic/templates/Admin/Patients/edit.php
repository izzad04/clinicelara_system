<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Patient $patient
 */
// Page-specific CSS
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" 
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
/* Patient Edit Form Specific Styles */
.patient-edit-form .form-label {
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
}

.patient-edit-form .form-control-lg,
.patient-edit-form .form-select-lg {
    padding: 0.75rem 1rem;
    font-size: 1rem;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.patient-edit-form .form-control-lg:focus,
.patient-edit-form .form-select-lg:focus {
    border-color: #A53860;
    box-shadow: 0 0 0 3px rgba(165, 56, 96, 0.1);
    outline: none;
}

.patient-edit-form .section-title {
    color: #495057;
    font-size: 1.1rem;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid #e9ecef;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.patient-edit-form .edit-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, rgba(165, 56, 96, 0.1) 0%, rgba(248, 182, 200, 0.1) 100%);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.patient-edit-form .btn-lg {
    padding: 0.75rem 1.5rem;
    font-size: 1rem;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.patient-edit-form .btn-primary {
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
    border: none;
    font-weight: 600;
}

.patient-edit-form .btn-primary:hover {
    background: linear-gradient(135deg, #8c2e4f 0%, #a53758 100%);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(165, 56, 96, 0.4);
}

.patient-edit-form .form-text {
    font-size: 0.85rem;
    color: #6c757d;
    margin-top: 6px;
}

/* Input formatting */
.ic-input, .phone-input, .postcode-input, .city-input {
    font-family: monospace;
}

/* Read-only fields */
.bg-light {
    background-color: #f8f9fa !important;
    color: #6c757d;
}

/* Form row spacing */
.row.g-3 > [class*="col-"] {
    margin-bottom: 1rem;
}

/* Modal styling */
.modal-header {
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
    color: white;
}

.modal-header .btn-close {
    filter: invert(1);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .patient-edit-form .col-md-6,
    .patient-edit-form .col-md-3,
    .patient-edit-form .col-md-4,
    .patient-edit-form .col-md-5,
    .patient-edit-form .col-12 {
        width: 100%;
    }
    
    .patient-edit-form .btn-lg {
        padding: 0.5rem 1rem;
        font-size: 0.9rem;
    }
    
    .patient-edit-form .edit-icon {
        width: 50px;
        height: 50px;
        font-size: 1.5rem;
    }
}
</style>

<!-- Patient Admin Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>
            
            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="fas fa-times"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="fas fa-gauge-high"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="fas fa-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="fas fa-user-doctor"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="fas fa-users"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>
                
            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']) ?></li>
                
            <li><?= $this->Html->link('<i class="fas fa-user-gear"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>
        
        <!-- Sidebar Footer -->
        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="fas fa-bars fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Edit Patient: <?= h($patient->fullname) ?></h5>
                <h5 class="m-0 d-md-none">Edit Patient</h5>
            </div>

            <!-- Action Buttons -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="fas fa-arrow-left me-2"></i> Back',
                    ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'view', $patient->id],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <!-- Edit Form Card -->
                    <div class="card-modern shadow-lg patient-edit-form">
                        <div class="card-header bg-transparent border-bottom py-4">
                            <div class="d-flex align-items-center">
                                <div class="edit-icon me-3">
                                    <i class="fas fa-user-pen text-primary fs-3"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0 fw-bold text-primary">Edit Patient Information</h4>
                                    <p class="text-muted mb-0">Update the details for patient #<?= h($patient->id) ?></p>
                                </div>
                                <div class="ms-auto">
                                    <span class="badge bg-info fs-6">ID: <?= $this->Number->format($patient->id) ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-body p-4 p-lg-5">
                            <?= $this->Form->create($patient, ['class' => 'patient-form']) ?>
                            
                            <div class="row g-3">
                                <!-- Personal Information -->
                                <div class="col-12">
                                    <h5 class="section-title mb-4">
                                        <i class="fas fa-id-card me-2"></i>
                                        Personal Information
                                    </h5>
                                </div>
                                
                                <div class="col-md-6">
                                    <label class="form-label">Full Name</label>
                                    <?= $this->Form->control('fullname', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'Enter full name',
                                        'value' => $patient->fullname
                                    ]) ?>
                                </div>
                                
                                <div class="col-md-6">
                                    <label class="form-label">IC Number</label>
                                    <?= $this->Form->control('ic', [
                                        'class' => 'form-control form-control-lg ic-input',
                                        'label' => false,
                                        'placeholder' => 'e.g., 900101-01-1234',
                                        'value' => $patient->ic
                                    ]) ?>
                                    <small class="form-text">Format: 900101-01-1234</small>
                                </div>
                                
                                <!-- Contact Information -->
                                <div class="col-12 mt-4">
                                    <h5 class="section-title mb-4">
                                        <i class="fas fa-address-book me-2"></i>
                                        Contact Information
                                    </h5>
                                </div>
                                
                                <div class="col-md-6">
                                    <label class="form-label">Phone Number</label>
                                    <?= $this->Form->control('phone', [
                                        'class' => 'form-control form-control-lg phone-input',
                                        'label' => false,
                                        'placeholder' => 'e.g., 012-3456789',
                                        'value' => $patient->phone
                                    ]) ?>
                                </div>
                                
                                <div class="col-md-6">
                                    <label class="form-label">Email Address</label>
                                    <?= $this->Form->control('email', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'patient@example.com',
                                        'value' => $patient->email
                                    ]) ?>
                                </div>
                                
                                <!-- Address Information -->
                                <div class="col-12 mt-4">
                                    <h5 class="section-title mb-4">
                                        <i class="fas fa-location-dot me-2"></i>
                                        Address Information
                                    </h5>
                                </div>
                                
                                <div class="col-12">
                                    <label class="form-label">Street Address 1</label>
                                    <?= $this->Form->control('street1', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'House number, street name',
                                        'value' => $patient->street1
                                    ]) ?>
                                </div>
                                
                                <div class="col-12">
                                    <label class="form-label">Street Address 2</label>
                                    <?= $this->Form->control('street2', [
                                        'class' => 'form-control form-control-lg',
                                        'label' => false,
                                        'placeholder' => 'Apartment, suite, unit, building, floor, etc.',
                                        'value' => $patient->street2
                                    ]) ?>
                                </div>
                                
                                <div class="col-md-3">
                                    <label class="form-label">Postcode</label>
                                    <?= $this->Form->control('postcode', [
                                        'class' => 'form-control form-control-lg postcode-input',
                                        'label' => false,
                                        'placeholder' => 'e.g., 50000',
                                        'value' => $patient->postcode
                                    ]) ?>
                                </div>
                                
                                <div class="col-md-5">
                                    <label class="form-label">City</label>
                                    <?= $this->Form->control('city', [
                                        'class' => 'form-control form-control-lg city-input',
                                        'label' => false,
                                        'placeholder' => 'City name',
                                        'value' => $patient->city
                                    ]) ?>
                                </div>
                                
                                <div class="col-md-4">
                                    <label class="form-label">State</label>
                                    <?= $this->Form->control('state', [
                                        'class' => 'form-select form-control-lg',
                                        'label' => false,
                                        'options' => [
                                            'JOHOR' => 'Johor',
                                            'KEDAH' => 'Kedah',
                                            'KELANTAN' => 'Kelantan',
                                            'MELAKA' => 'Melaka',
                                            'NEGERI SEMBILAN' => 'Negeri Sembilan',
                                            'PAHANG' => 'Pahang',
                                            'PENANG' => 'Penang',
                                            'PERAK' => 'Perak',
                                            'PERLIS' => 'Perlis',
                                            'SABAH' => 'Sabah',
                                            'SARAWAK' => 'Sarawak',
                                            'SELANGOR' => 'Selangor',
                                            'TERENGGANU' => 'Terengganu',
                                            'KUALA LUMPUR' => 'Kuala Lumpur',
                                            'LABUAN' => 'Labuan',
                                            'PUTRAJAYA' => 'Putrajaya'
                                        ],
                                        'empty' => '-- Select State --',
                                        'value' => $patient->state
                                    ]) ?>
                                </div>
                                
                                <!-- Record Information -->
                                <div class="col-12 mt-4">
                                    <h5 class="section-title mb-4">
                                        <i class="fas fa-clock-rotate-left me-2"></i>
                                        Record Information
                                    </h5>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">Created On</label>
                                        <input type="text" class="form-control form-control-lg bg-light" 
                                               value="<?= h($patient->created) ?>" readonly>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">Last Modified</label>
                                        <input type="text" class="form-control form-control-lg bg-light" 
                                               value="<?= h($patient->modified) ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Form Actions -->
                            <div class="d-flex justify-content-between align-items-center mt-5 pt-4 border-top">
                                <div>
                                    <?= $this->Html->link(
                                        '<i class="fas fa-xmark-circle me-2"></i> Cancel',
                                        ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'view', $patient->id],
                                        [
                                            'class' => 'btn btn-lg btn-outline-secondary',
                                            'escape' => false
                                        ]
                                    ) ?>
                                </div>
                                
                                <div class="d-flex gap-3">
                                    <?= $this->Form->button(
                                        '<i class="fas fa-rotate-right me-2"></i> Reset',
                                        [
                                            'type' => 'reset',
                                            'class' => 'btn btn-lg btn-outline-warning',
                                            'escape' => false,
                                            'escapeTitle' => false,
                                            'title' => 'Reset form'
                                        ]
                                    ) ?>

                                    <?= $this->Form->button(
                                        '<i class="fas fa-floppy-disk me-2"></i> Save Changes',
                                        [
                                            'type' => 'submit',
                                            'class' => 'btn btn-lg btn-primary px-5 fw-bold',
                                            'escape' => false,
                                            'escapeTitle' => false,
                                            'title' => 'Save changes'
                                        ]
                                    ) ?>
                                </div>

                            </div>
                            
                            <?= $this->Form->end() ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger">
                    <i class="fas fa-triangle-exclamation me-2"></i>
                    Confirm Patient Deletion
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <div class="mb-4">
                    <i class="fas fa-trash-can fa-4x text-danger"></i>
                </div>
                <h5 class="mb-3">Are you sure?</h5>
                <p class="text-muted">
                    You are about to delete patient:<br>
                    <strong class="text-danger"><?= h($patient->fullname) ?></strong><br>
                    <small>(ID: <?= $this->Number->format($patient->id) ?>)</small>
                </p>
                <p class="text-warning">
                    <i class="fas fa-exclamation-triangle me-1"></i>
                    This action cannot be undone.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-xmark me-1"></i>
                    Cancel
                </button>
                <?= $this->Form->postLink(
                    '<i class="fas fa-trash me-1"></i> Delete Patient',
                    ['action' => 'delete', $patient->id],
                    [
                        'class' => 'btn btn-danger',
                        'escape' => false
                    ]
                ) ?>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    const toggleBtn = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const closeBtn = document.getElementById('closeSidebar');
    
    if (toggleBtn && sidebar) {
        toggleBtn.onclick = function() {
            sidebar.classList.toggle('hide');
        };
    }
    
    if (closeBtn && sidebar) {
        closeBtn.onclick = function() {
            sidebar.classList.add('hide');
        };
    }
    
    // IC Number formatting
    const icInput = document.querySelector('.ic-input');
    if (icInput) {
        icInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            
            if (value.length > 6) {
                value = value.substring(0, 6) + '-' + value.substring(6);
            }
            if (value.length > 9) {
                value = value.substring(0, 9) + '-' + value.substring(9);
            }
            
            if (value.length > 14) {
                value = value.substring(0, 14);
            }
            
            e.target.value = value;
        });
    }
    
    // Phone Number formatting
    const phoneInput = document.querySelector('.phone-input');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            
            if (value.length > 3) {
                value = value.substring(0, 3) + '-' + value.substring(3);
            }
            if (value.length > 7) {
                value = value.substring(0, 7) + '-' + value.substring(7);
            }
            
            if (value.length > 12) {
                value = value.substring(0, 12);
            }
            
            e.target.value = value;
        });
    }
    
    // Postcode - only numbers
    const postcodeInput = document.querySelector('.postcode-input');
    if (postcodeInput) {
        postcodeInput.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/[^0-9]/g, '').slice(0, 5);
        });
    }
    
    // Auto-capitalize city input
    const cityInput = document.querySelector('.city-input');
    if (cityInput) {
        cityInput.addEventListener('blur', function() {
            this.value = this.value.toUpperCase();
        });
    }
    
    // Auto-capitalize name input
    const nameInput = document.querySelector('[name="fullname"]');
    if (nameInput) {
        nameInput.addEventListener('blur', function() {
            this.value = this.value.replace(/\b\w/g, function(char) {
                return char.toUpperCase();
            });
        });
    }
});
</script>