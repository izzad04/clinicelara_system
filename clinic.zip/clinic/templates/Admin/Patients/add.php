<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Patient $patient
 */

// Page-specific CSS (keep your existing)
echo $this->Html->css('appointment_admin');
echo $this->Html->css('patientadd_admin');
?>

<!-- Patient Edit Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar" type="button">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false,'escapeTitle'=>false,'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <!-- Sidebar Footer -->
        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Edit Patient Profile</h5>
                <h5 class="m-0 d-md-none">Edit Patient</h5>
            </div>

            <!-- Back Button -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'view', $patient->id],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <div class="row">
                <div class="col-lg-9 mx-auto">
                    <!-- Form Card (match Appointment Add style) -->
                    <div class="card-modern shadow-lg">
                        <div class="card-header bg-transparent border-bottom py-4">
                            <h4 class="mb-1 fw-bold text-primary">
                                <i class="bi bi-person-heart me-2"></i>Edit Patient Profile
                            </h4>
                            <p class="text-muted mb-0">Update information for patient ID: #<?= $patient->id ?></p>
                        </div>

                        <div class="card-body p-4 p-lg-5">
                            <?= $this->Form->create($patient, [
                                'class' => 'needs-validation patient-form',
                                'novalidate' => true
                            ]) ?>

                            <div class="row g-4">
                                <!-- Full Name -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-person me-1 text-primary"></i> Full Name
                                        </label>
                                        <?= $this->Form->control('fullname', [
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'placeholder' => 'Enter patient full name',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Enter the patient's complete name</div>
                                    </div>
                                </div>

                                <!-- IC -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-credit-card-2-front me-1 text-info"></i> IC Number
                                        </label>
                                        <?= $this->Form->control('ic', [
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'placeholder' => 'e.g., 901231-01-1234',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Format: YYMMDD-NN-####</div>
                                    </div>
                                </div>

                                <!-- Phone -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-telephone me-1 text-success"></i> Phone Number
                                        </label>
                                        <?= $this->Form->control('phone', [
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'placeholder' => 'e.g., 012-3456789',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Include country code if necessary</div>
                                    </div>
                                </div>

                                <!-- Email -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-envelope me-1 text-warning"></i> Email Address
                                        </label>
                                        <?= $this->Form->control('email', [
                                            'type' => 'email',
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'placeholder' => 'patient@email.com'
                                        ]) ?>
                                        <div class="form-text text-muted">Optional - for appointment reminders</div>
                                    </div>
                                </div>

                                <!-- Street 1 -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-geo-alt me-1 text-danger"></i> Street Address 1
                                        </label>
                                        <?= $this->Form->control('street1', [
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'placeholder' => 'House/Unit Number, Street',
                                            'required' => true
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Street 2 -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-building me-1 text-secondary"></i> Street Address 2
                                        </label>
                                        <?= $this->Form->control('street2', [
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'placeholder' => 'Apartment, Suite, Building (Optional)'
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- City -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-pin-map me-1 text-primary"></i> City
                                        </label>
                                        <?= $this->Form->control('city', [
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'placeholder' => 'e.g., Kuala Lumpur',
                                            'required' => true
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- State -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-map me-1 text-info"></i> State
                                        </label>
                                        <?= $this->Form->control('state', [
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'options' => [
                                                '' => '-- Select State --',
                                                'Johor' => 'Johor',
                                                'Kedah' => 'Kedah',
                                                'Kelantan' => 'Kelantan',
                                                'Melaka' => 'Melaka',
                                                'Negeri Sembilan' => 'Negeri Sembilan',
                                                'Pahang' => 'Pahang',
                                                'Perak' => 'Perak',
                                                'Perlis' => 'Perlis',
                                                'Pulau Pinang' => 'Pulau Pinang',
                                                'Sabah' => 'Sabah',
                                                'Sarawak' => 'Sarawak',
                                                'Selangor' => 'Selangor',
                                                'Terengganu' => 'Terengganu',
                                                'Wilayah Persekutuan Kuala Lumpur' => 'Wilayah Persekutuan Kuala Lumpur',
                                                'Wilayah Persekutuan Labuan' => 'Wilayah Persekutuan Labuan',
                                                'Wilayah Persekutuan Putrajaya' => 'Wilayah Persekutuan Putrajaya'
                                            ],
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Select the state from the list</div>
                                    </div>
                                </div>

                                <!-- Postcode -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-mailbox2 me-1 text-warning"></i> Postal Code
                                        </label>
                                        <?= $this->Form->control('postcode', [
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'placeholder' => 'e.g., 50000',
                                            'required' => true
                                        ]) ?>
                                    </div>
                                </div>
                            </div>

                            <!-- FORM ACTIONS (match Appointment Add: stable even when sidebar open) -->
                            <div class="form-actions mt-5 pt-4 border-top">
                                <?= $this->Html->link(
                                    '<i class="bi bi-x-circle"></i> Cancel',
                                    ['action' => 'view', $patient->id],
                                    ['class'=>'btn btn-lg btn-outline-secondary','escape'=>false,'escapeTitle'=>false]
                                ) ?>

                                <?= $this->Form->button(
                                    '<i class="bi bi-arrow-clockwise"></i> Reset',
                                    ['type'=>'reset','class'=>'btn btn-lg btn-outline-warning','escape'=>false,'escapeTitle'=>false]
                                ) ?>

                                <?= $this->Form->button(
                                    '<i class="bi bi-check-circle"></i> Save Changes',
                                    ['type'=>'submit','class'=>'btn btn-lg btn-save','escape'=>false,'escapeTitle'=>false]
                                ) ?>
                            </div>

                            <?= $this->Form->end() ?>
                        </div>
                    </div><!-- card -->
                </div>
            </div>
        </main>
    </div>
</div>

<!-- CSS (keep here OR move into appointment_admin.css) -->
<style>
/* Save button pink like theme */
.btn-save{
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%) !important;
    border: none !important;
    color: #fff !important;
    border-radius: 12px !important;
    padding: 14px 40px !important;
    box-shadow: 0 6px 20px rgba(165, 56, 96, 0.30);
    transition: all 0.25s ease;
}
.btn-save:hover{
    transform: translateY(-1px);
    filter: brightness(1.02);
    box-shadow: 0 10px 26px rgba(165, 56, 96, 0.40);
}

/* Form controls */
.form-control-lg {
    border-radius: 10px;
    border: 2px solid #e9ecef;
    padding: 12px 16px;
    transition: all 0.25s ease;
}
.form-control-lg:focus {
    border-color: #A53860;
    box-shadow: 0 0 0 3px rgba(165, 56, 96, 0.10);
    transform: translateY(-1px);
}
.form-label { color: #495057; font-size: 0.95rem; }
.form-text { font-size: 0.85rem; margin-top: 5px; }

/* ===== FIX: footer buttons stable when sidebar open ===== */
.form-actions{
  display:grid;
  grid-template-columns: auto auto 1fr; /* Cancel | Reset | Save */
  gap:14px;
  align-items:center;
}
.form-actions .btn-save{
  justify-self:end;
  min-width:260px;
}
.form-actions .btn{
  min-height:54px;
  border-radius:12px;
  padding:12px 18px;
  font-weight:700;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  gap:10px;
  white-space:nowrap;
}
.form-actions .btn-save{
  padding:12px 26px !important;
  min-width:240px;
}
@media (max-width: 576px){
  .form-actions{ grid-template-columns: 1fr; }
  .form-actions .btn{ width:100%; }
  .form-actions .btn-save{ min-width:0; }
}
</style>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle (safe)
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn  = document.getElementById('closeSidebar');
    var sidebar   = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar)  closeBtn.onclick  = () => sidebar.classList.add('hide');

    // Bootstrap validation (same as appointment)
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Phone formatting (simple)
    const phoneInput = document.querySelector('input[name="phone"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let v = e.target.value.replace(/\D/g, '');
            // keep it readable: 3-4-4 style when possible
            if (v.length > 3 && v.length <= 7) v = v.slice(0,3) + '-' + v.slice(3);
            else if (v.length > 7) v = v.slice(0,3) + '-' + v.slice(3,7) + '-' + v.slice(7,11);
            e.target.value = v;
        });
    }

    // IC formatting (######-##-####)
    const icInput = document.querySelector('input[name="ic"]');
    if (icInput) {
        icInput.addEventListener('input', function(e) {
            let v = e.target.value.replace(/\D/g, '').slice(0, 12);
            if (v.length > 6) v = v.slice(0,6) + '-' + v.slice(6);
            if (v.length > 9) v = v.slice(0,9) + '-' + v.slice(9);
            e.target.value = v;
        });
    }
});
</script>
