<?php
echo $this->Html->css('appointment_admin');
?>

<style>
.search-card{
    background:#fff;
    border-radius:16px;
    padding:18px 18px;
    box-shadow: 0 10px 30px rgba(165,56,96,0.08);
    border: 1px solid rgba(0,0,0,0.04);
    margin-bottom: 18px;
}
.search-form{ margin:0; }
.search-card .search-wrap{
    display:flex !important;
    align-items:center !important;
    gap:12px;
    flex-wrap:wrap;
}
.search-card .search-btn{
    height: 44px !important;
    width: 44px !important;
    padding: 0 !important;

    /* remove box */
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;

    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;

    border-radius: 10px !important;
}

/* nicer hover without box */
.search-card .search-btn:hover{
    background: rgba(165,56,96,0.08) !important;
}

/* make icon a bit bigger */
.search-card .search-btn i{
    font-size: 1.1rem;
    color: #111;
}

/* ===== Fix actions stacking ===== */
.actions-td { white-space: nowrap; }
.btn-group-modern {
    display: inline-flex;
    gap: 10px;
    align-items: center;
    justify-content: center;
    flex-wrap: nowrap;
}
.btn-group-modern .btn{
    width: 34px;
    height: 34px;
    padding: 0;
    border-radius: 8px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
}

/* Patients look */
.patient-avatar-sm {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: linear-gradient(135deg, #A53860 0%, #c44569 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    margin-right: 10px;
}

.status-text {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.status-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: #adb5bd;
}
.status-text-active { color: #198754; }
.status-text-active .status-dot { background: #198754; }
.status-text-inactive { color: #d39e00; }
.status-text-inactive .status-dot { background: #d39e00; }
.status-text-archived { color: #6c757d; }
.status-text-archived .status-dot { background: #6c757d; }
.status-text-default { color: #6c757d; }

.table-no-scroll{ overflow-x:hidden; }

.btn-group-modern{
    display: inline-flex !important;
    gap: 10px !important;
    align-items: center !important;
    justify-content: center !important;
    flex-wrap: nowrap !important;
}

.btn-group-modern .btn{
    width: 34px !important;
    height: 34px !important;
    padding: 0 !important;
    border-radius: 8px !important;

    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;

    box-shadow: none !important;
}

/* Force colors */
.btn-view{
    background: rgba(13,110,253,0.12) !important;
    color: #0d6efd !important;
    border: 1px solid rgba(13,110,253,0.25) !important;
}
.btn-edit{
    background: rgba(255,193,7,0.16) !important;
    color: #ffc107 !important;
    border: 1px solid rgba(255,193,7,0.30) !important;
}
.btn-delete{
    background: rgba(220,53,69,0.14) !important;
    color: #dc3545 !important;
    border: 1px solid rgba(220,53,69,0.25) !important;
}

.btn-view:hover,
.btn-edit:hover,
.btn-delete:hover{
    transform: translateY(-1px);
    box-shadow: 0 6px 14px rgba(0,0,0,0.10) !important;
}
</style>

<div class="admin-wrapper">
    <!-- SIDEBAR (keep yours) -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', ['alt' => 'Elara Clinic Logo', 'class' => 'logo-img']) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix'=>'Admin','controller'=>'Treatments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Patients Management</h5>
                <h5 class="m-0 d-md-none">Patients</h5>
            </div>
        </header>

        <main class="content-area">

            <!-- ✅ SEARCH BOX CARD (same like doctor) -->
            <div class="search-card">
                <?= $this->Form->create(null, [
                    'valueSources' => 'query',
                    'url' => ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                    'type' => 'get',
                    'class' => 'search-form'
                ]) ?>

                <div class="search-wrap">
                    <?= $this->Form->control('id', [
                        'label' => false,
                        'placeholder' => 'Patient ID (number)',
                        'class' => 'form-control search-input',
                        'style' => 'width:170px;',
                        'value' => $this->request->getQuery('id'),
                        'type' => 'number',
                        'min' => 1
                    ]) ?>

                    <?= $this->Form->control('fullname', [
                        'label' => false,
                        'placeholder' => 'Patient name',
                        'class' => 'form-control search-input',
                        'style' => 'width:260px;',
                        'value' => $this->request->getQuery('fullname'),
                        'type' => 'text'
                    ]) ?>

                    <?= $this->Form->control('ic', [
                        'label' => false,
                        'placeholder' => 'IC number',
                        'class' => 'form-control search-input',
                        'style' => 'width:220px;',
                        'value' => $this->request->getQuery('ic'),
                        'type' => 'text'
                    ]) ?>

                     <?= $this->Form->button('<i class="bi bi-search-heart-fill"></i>', [
                            'class' => 'btn search-btn',
                            'escape' => false,
                            'title' => 'Search',
                            'escapeTitle' => false,
                        ]) ?>

                        <?= $this->Html->link('<i class="bi bi-x-lg"></i>',
                            ['prefix'=>'Admin','controller'=>'Patient', 'action'=>'index'],
                            ['class' => 'btn search-btn', 'escape' => false, 'escapeTitle' => false, 'title' => 'Reset']
                        ) ?>
                </div>

                <?= $this->Form->end() ?>
            </div>

            <!-- TABLE CARD -->
            <div class="card-modern shadow-sm mt-4">
                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center py-3">
                    <h6 class="mb-0 fw-bold">Patients Management</h6>

                    <?= $this->Html->link(
                        '<i class="bi bi-plus-circle me-2"></i> Add New Patient',
                        ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'add'],
                        [
                            'class' => 'btn btn-primary fw-bold',
                            'escape' => false,
                            'style' => '
                                background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
                                border: none;
                                border-radius: 8px;
                                padding: 10px 20px;
                                box-shadow: 0 4px 12px rgba(165, 56, 96, 0.3);
                                transition: all 0.3s ease;
                            '
                        ]
                    ) ?>
                </div>

                <div class="table-no-scroll">
                    <table class="table table-modern table-hover mb-0 w-100">
                        <thead class="table-light">
                        <tr>
                            <th style="width:90px;">ID</th>
                            <th>Patient Info</th>
                            <th>Contact</th>
                            <th>Location</th>
                            <th style="width:140px;">Status</th>
                            <th class="text-center" style="width:170px;">Actions</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php foreach ($patients as $patient): ?>
                            <tr>
                                <td><span class="badge bg-secondary">#<?= h($patient->id) ?></span></td>

                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="patient-avatar-sm">
                                            <i class="bi bi-person"></i>
                                        </div>
                                        <div>
                                            <strong><?= h($patient->fullname) ?></strong>
                                            <div class="small text-muted">IC: <?= h($patient->ic) ?></div>
                                        </div>
                                    </div>
                                </td>

                                <td>
                                    <div class="small">
                                        <div><?= h($patient->phone) ?></div>
                                        <div class="text-muted"><?= h($patient->email) ?></div>
                                    </div>
                                </td>

                                <td>
                                    <div class="small">
                                        <div><?= h($patient->city) ?>, <?= h($patient->state) ?></div>
                                        <div class="text-muted"><?= h($patient->street1) ?></div>
                                    </div>
                                </td>

                                <td>
                                    <?php
                                    $statusText = [
                                        1 => 'Active',
                                        0 => 'Inactive',
                                        2 => 'Archived',
                                    ];
                                    $statusTextClass = [
                                        1 => 'status-text-active',
                                        0 => 'status-text-inactive',
                                        2 => 'status-text-archived',
                                    ];
                                    $s = is_numeric($patient->status) ? (int)$patient->status : -1;
                                    ?>
                                    <span class="status-text <?= $statusTextClass[$s] ?? 'status-text-default' ?>">
                                        <span class="status-dot"></span>
                                        <?= $statusText[$s] ?? 'Unknown' ?>
                                    </span>
                                </td>

                                <!-- ✅ Actions NOT STACKING -->
                                <td class="text-center actions-td">
                                    <div class="btn-group-modern">
                                        <?= $this->Html->link(
                                            '<i class="bi bi-eye"></i>',
                                            ['action' => 'view', $patient->id],
                                            ['class' => 'btn btn-view', 'escape' => false, 'title' => 'View']
                                        ) ?>

                                        <?= $this->Html->link(
                                            '<i class="bi bi-pencil"></i>',
                                            ['action' => 'edit', $patient->id],
                                            ['class' => 'btn btn-edit', 'escape' => false, 'title' => 'Edit']
                                        ) ?>

                                        <?= $this->Form->postLink(
                                            '<i class="bi bi-trash"></i>',
                                            ['action' => 'delete', $patient->id],
                                            [
                                                'class' => 'btn btn-delete',
                                                'escape' => false,
                                                'title' => 'Delete',
                                                'confirm' => __('Delete patient: {0}?', h($patient->fullname))
                                            ]
                                        ) ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="card-footer bg-white border-top py-3">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="text-muted small">
                                <?= $this->Paginator->counter(__('Showing {{start}} to {{end}} of {{count}} patients')) ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <nav aria-label="Page navigation" class="float-md-end">
                                <ul class="pagination pagination-sm justify-content-center mb-0">
                                    <?= $this->Paginator->first('<i class="bi bi-chevron-double-left"></i>', ['escape' => false]) ?>
                                    <?= $this->Paginator->prev('<i class="bi bi-chevron-left"></i>', ['escape' => false]) ?>
                                    <?= $this->Paginator->numbers() ?>
                                    <?= $this->Paginator->next('<i class="bi bi-chevron-right"></i>', ['escape' => false]) ?>
                                    <?= $this->Paginator->last('<i class="bi bi-chevron-double-right"></i>', ['escape' => false]) ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>

            </div>

        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // sidebar toggle
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn = document.getElementById('closeSidebar');
    var sidebar = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar) closeBtn.onclick = () => sidebar.classList.add('hide');
});
</script>
