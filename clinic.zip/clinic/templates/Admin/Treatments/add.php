<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Treatment $treatment
 * @var \Cake\Collection\CollectionInterface|string[] $patients
 * @var \Cake\Collection\CollectionInterface|string[] $doctors
 */

// Page-specific CSS (same like Appointment Add)
echo $this->Html->css('appointment_admin');
?>

<!-- Treatments Add Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <!-- BIG LOGO centered at top -->
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar" type="button">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix'=>'Admin','controller'=>'Treatments','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'escapeTitle'=>false,'class'=>'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <!-- Sidebar Footer -->
        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Add New Treatment</h5>
                <h5 class="m-0 d-md-none">New Treatment</h5>
            </div>

            <!-- Back Button -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <!-- Form Card -->
                    <div class="card-modern shadow-lg">
                        <div class="card-header bg-transparent border-bottom py-4">
                            <h4 class="mb-1 fw-bold text-primary">
                                <i class="bi bi-clipboard-pulse me-2"></i>Register New Treatment
                            </h4>
                            <p class="text-muted mb-0">Fill in the details to create a new treatment record</p>
                        </div>

                        <div class="card-body p-4 p-lg-5">
                            <?= $this->Form->create($treatment, [
                                'class' => 'needs-validation',
                                'novalidate' => true
                            ]) ?>

                            <div class="row g-4">
                                <!-- Patient -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-person me-1 text-primary"></i> Patient
                                        </label>
                                        <?= $this->Form->control('patient_id', [
                                            'options' => $patients,
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'empty' => '-- Select Patient --',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Select patient for this treatment</div>
                                    </div>
                                </div>

                                <!-- Doctor -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-person-badge me-1 text-success"></i> Doctor
                                        </label>
                                        <?= $this->Form->control('doctor_id', [
                                            'options' => $doctors,
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'empty' => '-- Select Doctor --',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Doctor in charge of treatment</div>
                                    </div>
                                </div>

                                <!-- Start Date -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-calendar-date me-1 text-info"></i> Start Date
                                        </label>
                                        <?= $this->Form->control('start_date', [
                                            'type' => 'date',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'required' => true,
                                            'min' => date('Y-m-d')
                                        ]) ?>
                                        <div class="form-text text-muted">Treatment start date</div>
                                    </div>
                                </div>

                                <!-- End Date -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-calendar2-check me-1 text-info"></i> End Date
                                        </label>
                                        <?= $this->Form->control('end_date', [
                                            'type' => 'date',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'required' => true
                                            // min will be set by JS based on start_date
                                        ]) ?>
                                        <div class="form-text text-muted">Treatment end date</div>
                                    </div>
                                </div>

                                <!-- Duration -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-hourglass-split me-1 text-warning"></i> Duration
                                        </label>
                                        <?= $this->Form->control('duration', [
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'placeholder' => 'e.g., 7 days'
                                        ]) ?>
                                        <div class="form-text text-muted">Optional (you can calculate later)</div>
                                    </div>
                                </div>

                                <!-- Sickness -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-activity me-1 text-danger"></i> Sickness
                                        </label>
                                        <?= $this->Form->control('sickness', [
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'placeholder' => 'e.g., Fever, Flu, Migraine',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text text-muted">Main complaint / diagnosis</div>
                                    </div>
                                </div>

                                <!-- Notes -->
                                <div class="col-12">
                                    <div class="form-group">
                                        <label class="form-label fw-bold mb-2">
                                            <i class="bi bi-journal-text me-1"></i> Notes & Details
                                        </label>
                                        <?= $this->Form->control('notes', [
                                            'type' => 'textarea',
                                            'class' => 'form-control form-control-lg',
                                            'label' => false,
                                            'rows' => 4,
                                            'placeholder' => 'Enter additional notes (optional)...'
                                        ]) ?>
                                        <div class="form-text text-muted">Optional notes for this treatment</div>
                                    </div>
                                </div>
                            </div>

                            <!-- FORM ACTIONS (same like Appointment Add) -->
                            <div class="form-actions mt-5 pt-4 border-top">
                                <?= $this->Html->link(
                                    '<i class="bi bi-x-circle"></i> Cancel',
                                    ['prefix'=>'Admin','controller'=>'Treatments','action'=>'index'],
                                    ['class'=>'btn btn-lg btn-outline-secondary','escape'=>false,'escapeTitle'=>false]
                                ) ?>

                                <?= $this->Form->button(
                                    '<i class="bi bi-arrow-clockwise"></i> Reset',
                                    ['type'=>'reset','class'=>'btn btn-lg btn-outline-warning','escape'=>false,'escapeTitle'=>false]
                                ) ?>

                                <?= $this->Form->button(
                                    '<i class="bi bi-check2-circle"></i> Save Treatment',
                                    ['type'=>'submit','class'=>'btn btn-lg btn-save','escape'=>false,'escapeTitle'=>false]
                                ) ?>
                            </div>

                            <?= $this->Form->end() ?>
                        </div>
                    </div><!-- card -->
                </div>
            </div>
        </main>
    </div>
</div>

<!-- CSS (keep here OR move into appointment_admin.css) -->
<style>
/* Save button pink like theme (same as appointment) */
.btn-save{
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%) !important;
    border: none !important;
    color: #fff !important;
    border-radius: 12px !important;
    padding: 14px 40px !important;
    box-shadow: 0 6px 20px rgba(165, 56, 96, 0.30);
    transition: all 0.25s ease;
}
.btn-save:hover{
    transform: translateY(-1px);
    filter: brightness(1.02);
    box-shadow: 0 10px 26px rgba(165, 56, 96, 0.40);
}

/* Form controls (same as appointment) */
.form-control-lg {
    border-radius: 10px;
    border: 2px solid #e9ecef;
    padding: 12px 16px;
    transition: all 0.25s ease;
}
.form-control-lg:focus {
    border-color: #A53860;
    box-shadow: 0 0 0 3px rgba(165, 56, 96, 0.10);
    transform: translateY(-1px);
}
.form-label { color: #495057; font-size: 0.95rem; }
.form-text { font-size: 0.85rem; margin-top: 5px; }

/* ===== FIX: footer buttons stable when sidebar open ===== */
.form-actions{
  display:grid;
  grid-template-columns: auto auto 1fr; /* Cancel | Reset | Save */
  gap:14px;
  align-items:center;
}

.form-actions .btn-save{
  justify-self:end;
  min-width:260px;
}

/* all buttons same height + no wrap text */
.form-actions .btn{
  min-height:54px;
  border-radius:12px;
  padding:12px 18px;
  font-weight:700;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  gap:10px;
  white-space:nowrap;
}

/* Make Save button not too wide so it won't push others */
.form-actions .btn-save{
  padding:12px 26px !important;
  min-width:240px;
}

/* Mobile stack */
@media (max-width: 576px){
  .form-actions{ grid-template-columns: 1fr; }
  .form-actions .btn{ width:100%; }
  .form-actions .btn-save{ min-width:0; }
}
</style>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn  = document.getElementById('closeSidebar');
    var sidebar   = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar)  closeBtn.onclick  = () => sidebar.classList.add('hide');

    // Bootstrap validation (same pattern as appointment)
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Date min rules: start_date >= today, end_date >= start_date
    const startDate = document.querySelector('input[name="start_date"]');
    const endDate   = document.querySelector('input[name="end_date"]');

    const today = new Date().toISOString().split('T')[0];

    if (startDate) startDate.setAttribute('min', today);

    const syncEndMin = () => {
        if (!endDate) return;
        const min = (startDate && startDate.value) ? startDate.value : today;
        endDate.setAttribute('min', min);

        // if user already picked an end date earlier than min, clear it
        if (endDate.value && endDate.value < min) endDate.value = '';
    };

    if (startDate) startDate.addEventListener('change', syncEndMin);
    syncEndMin();
});
</script>
