<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Treatment $treatment
 */

$this->layout = 'admin';

echo $this->Html->css('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css');
echo $this->Html->css('appointment_admin');
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
      crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxMwy2scQbITxI"
        crossorigin="anonymous"></script>

<style>
:root {
    --primary-color: #A53860;
    --primary-light: rgba(165, 56, 96, 0.08);
    --secondary-color: #6c757d;
    --success-color: #28a745;
    --info-color: #17a2b8;
    --warning-color: #ffc107;
    --danger-color: #dc3545;
}

/* ✅ make page background plain (no gradient color) */
.treatment-view-wrapper {
    background: #f8f9fa;
    min-height: 100vh;
    padding: 20px;
}

/* Medical Certificate Card */
.certificate-card {
    background: white;
    border-radius: 16px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.08);
    border: 1px solid rgba(0,0,0,0.05);
    position: relative;
    overflow: hidden;
}

/* ✅ REMOVE TOP COLOR BAR */
.certificate-card::before { display: none; }

/* Certificate Header */
.certificate-header {
    text-align: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 2px solid #f0f0f0;
}

/* ✅ header image not weird/cut */
.certificate-logo img{
    width: 100%;
    max-width: 900px;       /* control big width */
    height: auto;
    display: block;
    margin: 0 auto;
    object-fit: contain;
    filter: none;           /* remove shadow */
}

.reference-number {
    text-align: right;
    font-size: 0.95rem;
    color: #666;
    margin-bottom: 20px;
    padding: 10px 20px;
    background: #f8f9fa;
    border-radius: 8px;
    border-left: 4px solid var(--primary-color);
}

.certificate-content { line-height: 1.8; color: #333; }
.certificate-content strong { color: var(--primary-color); }

.certificate-table {
    width: 100%;
    border-collapse: collapse;
    margin: 25px 0;
}
.certificate-table tr td {
    padding: 12px 0;
    vertical-align: top;
}
.certificate-table tr td:first-child {
    width: 220px;
    font-weight: 600;
    color: #495057;
}

/* ✅ Doctor Signature: RIGHT SIDE */
.doctor-signature {
    margin-top: 60px;
    text-align: left;
    border-top: 2px solid #dee2e6;
    padding-top: 30px;
}
.signature-line {
    width: 300px;
    height: 1px;
    background: #333;
   margin: 25px 0 10px 0; 
    position: relative;
}
.signature-line::before { display: none; } /* ✅ remove colored wave */

.certificate-footer {
    margin-top: 40px;
    padding-top: 30px;
    border-top: 1px solid #dee2e6;
}
.certificate-footer img { width: 100%; height: auto; opacity: 0.95; }

/* Sidebar Actions */
.sidebar-actions {
    background: white;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.08);
    border: 1px solid rgba(0,0,0,0.05);
    margin-bottom: 25px;
}
.sidebar-title {
    color: var(--primary-color);
    font-weight: 600;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid rgba(165, 56, 96, 0.1);
    display: flex;
    align-items: center;
    gap: 10px;
}
.quick-info {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
}
.info-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #e9ecef;
}
.info-item:last-child { border-bottom: none; }
.info-label { color: #6c757d; font-size: 0.9rem; }
.info-value { font-weight: 600; color: #333; }

.action-buttons-grid { display: grid; gap: 12px; margin-top: 20px; }
.action-btn {
    display: flex; align-items: center; justify-content: center; gap: 10px;
    padding: 12px; border-radius: 10px; font-weight: 500;
    transition: all 0.3s ease; text-decoration: none !important;
}
.action-btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
.btn-primary2 { background: linear-gradient(135deg, var(--primary-color) 0%, #C44569 100%); color: #fff; border: none; }
.btn-primary2:hover { color: #fff; }
.btn-outline-primary2 { background: #fff; color: var(--primary-color); border: 2px solid var(--primary-color); }
.btn-outline-primary2:hover { background: var(--primary-color); color: #fff; }
.btn-outline-danger2 { background: #fff; color: var(--danger-color); border: 2px solid var(--danger-color); }
.btn-outline-danger2:hover { background: var(--danger-color); color: #fff; }

@media (max-width: 768px) {
    .treatment-view-wrapper { padding: 15px; }
    .certificate-card { padding: 25px; }
    .certificate-table tr td:first-child { width: 160px; }
    .sidebar-actions { margin-top: 25px; }
}

@media print {
    .treatment-view-wrapper { background: white; padding: 0; }
    .sidebar-actions { display: none; }
    .certificate-card { box-shadow: none; border: none; padding: 0; }
}
</style>

<div class="admin-wrapper">
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', ['alt' => 'Elara Clinic Logo', 'class' => 'logo-img']) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix'=>'Admin','controller'=>'Treatments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN -->
    <div class="main-content">
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <div>
                    <h5 class="m-0 d-none d-md-block">Medical Certificate</h5>
                    <small class="text-muted d-none d-md-block">Treatment ID: #<?= $this->Number->format($treatment->id) ?></small>
                    <h5 class="m-0 d-md-none">Medical Certificate</h5>
                </div>
            </div>

         <!-- Action Buttons -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <main class="content-area">
            <div class="treatment-view-wrapper">
                <div class="row">
                    <!-- MAIN CONTENT -->
                    <div class="col-lg-9">
                        <div class="certificate-card">

                            <!-- ✅ REMOVE the color bar (certificate-top) completely -->

                            <!-- Clinic Header -->
                            <div class="certificate-header">
                                <div class="certificate-logo">
                                    <?= $this->Html->image('../img/surat/header.png', [
                                        'alt' => 'Elara Clinic',
                                        'class' => 'img-fluid'
                                    ]) ?>
                                </div>
                            </div>

                            <div class="reference-number">
                                <strong>Our Reference:</strong> EC-MC-<?= str_pad((string)$treatment->id, 5, '0', STR_PAD_LEFT); ?>
                            </div>

                            <div class="certificate-content">
                                <p><strong>TO WHOM IT MAY CONCERN</strong></p><br>

                                <p>This is to certify that the following patient has received treatment at our clinic:</p><br>

                                <table class="certificate-table">
                                    <tr>
                                        <td><strong>Patient Name</strong></td>
                                        <td>: <?= h($treatment->patient->fullname) ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Identification Number</strong></td>
                                        <td>: <?= h($treatment->patient->ic) ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Treatment Date</strong></td>
                                        <td>: <?= date('d/m/Y', strtotime((string)$treatment->start_date)) ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Sick Leave Period</strong></td>
                                        <td>: <?= h($treatment->duration) ?> days</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Valid Until</strong></td>
                                        <td>: <?= date('d/m/Y', strtotime((string)$treatment->end_date)) ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Diagnosis</strong></td>
                                        <td>: <?= h($treatment->sickness) ?></td>
                                    </tr>
                                </table>

                                <br>

                                <p>Therefore, the patient is advised to rest and refrain from any work activities throughout the stated period.</p><br>
                                <p>This certificate is issued upon patient's request for official purposes.</p><br>

                                <!-- ✅ Doctor Signature (RIGHT SIDE) -->
                                <div class="doctor-signature">
                                    <div class="signature-line"></div>
                                    <p class="mb-2"><strong>Doctor On Duty</strong></p>
                                    <p class="mb-1">Dr. <?= h($treatment->doctor->fullname) ?></p>
                                    <p class="text-muted mb-1">Elara Medical Clinic</p>
                                    <p class="small text-muted">License No: MD-<?= str_pad((string)$treatment->doctor->id, 4, '0', STR_PAD_LEFT) ?></p>
                                </div>
                            </div>

                            <div class="certificate-footer">
                                <?= $this->Html->image('../img/surat/footer1.png', [
                                    'alt' => 'Clinic Footer',
                                    'class' => 'img-fluid'
                                ]) ?>
                            </div>
                        </div>
                    </div>

                    <!-- SIDEBAR -->
                    <div class="col-lg-3">
                        <div class="sidebar-actions">
                            <h5 class="sidebar-title">
                                <i class="fas fa-cog"></i> Quick Actions
                            </h5>

                            <div class="quick-info">
                                <div class="info-item">
                                    <span class="info-label">Certificate ID</span>
                                    <span class="info-value">#<?= $this->Number->format($treatment->id) ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Issued Date</span>
                                    <span class="info-value"><?= date('M d, Y', strtotime((string)$treatment->created)) ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Issued Time</span>
                                    <span class="info-value"><?= date('h:i A', strtotime((string)$treatment->created)) ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Status</span>
                                    <?php
                                    $today2 = new \DateTime();
                                    $endDate2 = new \DateTime($treatment->end_date);
                                    $statusClass = $today2 > $endDate2 ? 'text-danger' : 'text-success';
                                    $statusText  = $today2 > $endDate2 ? 'Expired' : 'Valid';
                                    ?>
                                    <span class="info-value <?= $statusClass ?>">
                                        <i class="fas fa-circle fa-xs"></i> <?= $statusText ?>
                                    </span>
                                </div>
                            </div>

                            <div class="action-buttons-grid">
                                <?= $this->Html->link(
                                    '<i class="fas fa-download me-2"></i> Download PDF',
                                    ['action' => 'pdf', $treatment->id],
                                    ['class' => 'action-btn btn-primary2', 'escape' => false]
                                ) ?>

                                <?= $this->Html->link(
                                    '<i class="fas fa-edit me-2"></i> Edit Details',
                                    ['action' => 'edit', $treatment->id],
                                    ['class' => 'action-btn btn-outline-primary2', 'escape' => false]
                                ) ?>

                                <?= $this->Form->postLink(
                                    '<i class="fas fa-trash me-2"></i> Delete Certificate',
                                    ['action' => 'delete', $treatment->id],
                                    [
                                        'confirm' => __('Are you sure you want to delete this medical certificate?'),
                                        'class' => 'action-btn btn-outline-danger2',
                                        'escape' => false
                                    ]
                                ) ?>

                                <?= $this->Html->link(
                                    '<i class="fas fa-list me-2"></i> All Certificates',
                                    ['action' => 'index'],
                                    ['class' => 'action-btn btn-outline-primary2', 'escape' => false]
                                ) ?>
                            </div>
                        </div>
                    </div>
                </div><!-- row -->
            </div><!-- wrapper -->
        </main>
    </div><!-- main-content -->
</div><!-- admin-wrapper -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    // sidebar
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn  = document.getElementById('closeSidebar');
    var sidebar   = document.getElementById('sidebar');
    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar) closeBtn.onclick = () => sidebar.classList.add('hide');
});
</script>
