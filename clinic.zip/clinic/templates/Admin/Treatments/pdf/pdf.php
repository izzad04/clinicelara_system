<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Medical Certificate</title>

  <style>
    @page {
      size: A4;
      margin: 0;
    }

    body{
      margin:0;
      padding:0;
      font-family: DejaVu Sans, sans-serif;
      font-size: 11pt;
      color:#222;
    }

    /* =========================
       Full A4 background
       ========================= */
    .bg{
      position: fixed;
      top:0; left:0; right:0; bottom:0;
      z-index: 0;
    }
    .bg img{
      width:100%;
      height:100%;
    }

    /* =========================
       Main content
       ========================= */
    .content{
      position: relative;
      z-index: 1;

      /* adjust these to match your template */
      padding: 220px 70px 200px 70px;
      line-height: 1.55;
    }

    .ref{
      text-align:right;
      font-size: 10.5pt;
      margin-bottom: 14px;
    }

    .title{
      font-weight: 700;
      margin-bottom: 14px;
    }

    table.info{
      width:100%;
      border-collapse: collapse;
      margin: 12px 0 16px 0;
    }

    table.info td{
      padding: 5px 0;
      vertical-align: top;
    }

    td.label{
      width: 210px;
      font-weight: 700;
    }

    /* =========================
       Signature (fixed position)
       ========================= */
    .signature{
      position: fixed;
      left: 70px;
      right: 70px;
      bottom: 170px;   /* adjust up/down if needed */
      z-index: 2;
      page-break-inside: avoid;
      line-height: 1.5;
    }

    .sig-line{
      letter-spacing: 1px;
    }
  </style>
</head>

<body>

  <!-- A4 background image -->
  <div class="bg">
    <?= $this->Html->image('../img/surat/mc_a4_template.png', ['fullBase' => true]) ?>
  </div>

  <!-- MAIN CONTENT -->
  <div class="content">

    <div class="ref">
      Our Reference: EC-MC-<?= str_pad($treatment->id, 5, '0', STR_PAD_LEFT); ?>
    </div>

    <div class="title">TO WHOM IT MAY CONCERN</div>

    This is to certify that the following patient has received medical treatment at our clinic:

    <table class="info">
      <tr>
        <td class="label">Patient Name</td>
        <td>: <?= h($treatment->patient->fullname) ?></td>
      </tr>
      <tr>
        <td class="label">Identification Number</td>
        <td>: <?= h($treatment->patient->ic) ?></td>
      </tr>
      <tr>
        <td class="label">Treatment Date</td>
        <td>: <?= date('d/m/Y', strtotime($treatment->start_date)) ?></td>
      </tr>
      <tr>
        <td class="label">Medical Leave Period</td>
        <td>: <?= h($treatment->duration) ?> day(s)</td>
      </tr>
      <tr>
        <td class="label">Valid Until</td>
        <td>: <?= date('d/m/Y', strtotime($treatment->end_date)) ?></td>
      </tr>
      <tr>
        <td class="label">Diagnosis</td>
        <td>: <?= h($treatment->sickness) ?></td>
      </tr>
    </table>

    Therefore, the patient is advised to rest and refrain from any work activities throughout the stated period.
    <br><br>
    This certificate is issued upon the patient’s request for official purposes.

  </div>

  <!-- SIGNATURE -->
  <div class="signature">
    Yours sincerely,<br><br>

    <span class="sig-line">......................................................</span><br>
    <strong>Doctor On Duty</strong><br>
    Dr. <?= h($treatment->doctor->fullname) ?><br>
    Elara Medical Clinic<br>
    <small>License No: MD-<?= str_pad($treatment->doctor->id, 4, '0', STR_PAD_LEFT) ?></small>
  </div>

</body>
</html>
