<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Treatment> $treatments
 */

use Cake\Routing\Router;

// Same like appointments (base layout css)
echo $this->Html->css('appointment_admin');
echo $this->Html->css('dark_mode');
?>

<?= $this->Html->script('theme') ?>


<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxMwy2scQbITxI" crossorigin="anonymous"></script>

<!-- Chart.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>

<?php
// =====================
// tally cards from current list (page tally)
// =====================
$page_total = 0;
$page_active = 0;
$page_completed = 0;
$page_upcoming = 0;

$today = new \DateTime('today');

foreach ($treatments as $_t) {
    $page_total++;
    $start = new \DateTime($_t->start_date);
    $end   = new \DateTime($_t->end_date);

    if ($today > $end) {
        $page_completed++;
    } elseif ($today >= $start && $today <= $end) {
        $page_active++;
    } else {
        $page_upcoming++;
    }
}

// =====================
// Search values (id + name)
// =====================
$idValue   = (string)$this->request->getQuery('id');
$nameValue = (string)$this->request->getQuery('name');
$isSearch  = (!empty($idValue) || !empty($nameValue));
?>

<style>
/* =========================
   SEARCH (inline + same height) - SAME AS APPOINTMENTS
   ========================= */
.search-form { margin: 0; }
.search-wrap {
    display: flex !important;
    align-items: center !important;
    gap: 10px;
    position: relative;
    flex-wrap: wrap;
}
.search-input {
    height: 44px !important;
    line-height: 44px !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    border-radius: 10px !important;
}
.search-btn {
    height: 44px !important;
    width: 44px !important;
    padding: 0 !important;
    border-radius: 10px !important;
    background: #fff !important;
    border: 1px solid rgba(255,255,255,0.35) !important;
    cursor: pointer !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
}
@media (max-width: 768px) {
    .search-wrap { gap: 8px; }
}

/* =========================
   STATUS (Active / Completed / Upcoming)
   ========================= */
.status-text {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.status-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: #adb5bd;
}

.status-text-active { color: #198754; }
.status-text-active .status-dot { background: #198754; }

.status-text-completed { color: #6c757d; }
.status-text-completed .status-dot { background: #6c757d; }

.status-text-upcoming { color: #9a7b00; }
.status-text-upcoming .status-dot { background: #ffc107; }

.status-text-default { color: #6c757d; }
.status-text-default .status-dot { background: #adb5bd; }

/* =========================
   ACTION BUTTONS (compact spacing)
   ========================= */
.action-buttons-sm {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
}
.action-buttons-sm .btn {
    padding: 4px 8px;
}

/* optional table hover */
.table-modern tbody tr { transition: all 0.2s ease; }
.table-modern tbody tr:hover { background-color: rgba(248, 182, 200, 0.1); }

/* small badge for ID */
.badge-id {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 6px;
    background: #6c757d;
    color: #fff;
    font-weight: 700;
    font-size: 0.85rem;
}

/* analytics card */
.analytics-card .card-title {
    font-weight: 700;
    margin-bottom: 12px;
}
</style>

<!-- Treatments Admin Content -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Admin Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link('<i class="bi bi-speedometer2"></i> Dashboard',
                ['prefix'=>'Admin','controller'=>'Dashboards','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-calendar-check"></i> Appointments',
                ['prefix'=>'Admin','controller'=>'Appointments','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-badge"></i> Doctors',
                ['prefix'=>'Admin','controller'=>'Doctors','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-people"></i> Patients',
                ['prefix'=>'Admin','controller'=>'Patients','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <li><?= $this->Html->link(
                '<i class="bi bi-clipboard-pulse"></i> Treatments',
                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']) ?></li>

            <li><?= $this->Html->link('<i class="bi bi-person-lines-fill"></i> Users',
                ['prefix'=>'Admin','controller'=>'Users','action'=>'index'],
                ['escape'=>false,'class'=>'nav-link']) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link('<i class="bi bi-box-arrow-right"></i> Logout',
                ['controller'=>'Users','action'=>'logout'],
                ['escape'=>false,'class'=>'nav-link text-danger fw-bold']) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Treatments Management</h5>
                <h5 class="m-0 d-md-none">Elara Clinic</h5>
            </div>

            <button
  type="button"
  class="btn btn-sm btn-outline-secondary"
  onclick="toggleDarkMode()"
  title="Toggle Dark Mode"
>
  <i class="bi bi-moon-stars"></i>
</button>


        </header>

        <!-- CONTENT -->
        <main class="content-area">
            <!-- CARDS -->
            <div class="row mb-4 g-3">
                <div class="col-md-3 col-sm-6">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-clipboard2-pulse fs-1 text-primary"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $page_total ?></h3>
                        <p class="text-muted mb-0">Total Treatments</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-clock-history fs-1 text-success"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $page_active ?></h3>
                        <p class="text-muted mb-0">Active Treatments</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-archive fs-1 text-secondary"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $page_completed ?></h3>
                        <p class="text-muted mb-0">Archived Treatments</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card-modern text-center shadow-sm">
                        <div class="card-icon mb-3">
                            <i class="bi bi-calendar-event fs-1 text-warning"></i>
                        </div>
                        <h3 class="mb-2 fw-bold"><?= $page_upcoming ?></h3>
                        <p class="text-muted mb-0">Upcoming Treatments</p>
                    </div>
                </div>
            </div>
                    
            <div class="card-modern shadow-sm mb-4">

                <!-- ✅ SEARCH (ID + Name like Doctors) -->
            <div class="header-search">
                <?= $this->Form->create(null, [
                    'valueSources' => 'query',
                    'url' => ['prefix'=>'Admin','controller'=>'Treatments','action'=>'index'],
                    'type' => 'get',
                    'class' => 'search-form'
                ]) ?>

                <div class="search-wrap">
                    <?= $this->Form->control('id', [
                        'label' => false,
                        'placeholder' => 'Treatment ID',
                        'class' => 'form-control search-input',
                        'style' => 'width:140px;',
                        'value' => $idValue,
                        'type' => 'number',
                        'min' => 1
                    ]) ?>

                    <?= $this->Form->control('name', [
                        'label' => false,
                        'placeholder' => 'Patient / Doctor / Sickness',
                        'class' => 'form-control search-input',
                        'style' => 'width:260px;',
                        'value' => $nameValue,
                        'type' => 'text'
                    ]) ?>

                    <?= $this->Form->button('<i class="bi bi-search-heart-fill"></i>', [
                        'class' => 'btn search-btn',
                        'escape' => false,
                        'escapeTitle' => false,
                        'title' => 'Search Treatment',
                    ]) ?>

                        <?= $this->Html->link('<i class="bi bi-x-lg"></i>',
                            ['prefix'=>'Admin','controller'=>'Treatments','action'=>'index'],
                            ['class'=>'btn search-btn', 'escape'=>false, 'escapeTitle'=>false, 'title'=>'Reset']
                        ) ?>
                </div>

                <?= $this->Form->end() ?>
            </div>
            </div>

            <!-- Tabs -->
            <div class="card-modern mb-4">
                <div class="card-body">
                    <ul class="nav nav-tabs nav-tabs-modern" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#list-tab">
                                <i class="bi bi-list me-2"></i>Treatments List
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#report-tab">
                                <i class="bi bi-chart-pie me-2"></i>Analytics
                            </button>
                        </li>
                    </ul>

                    
                    <div class="tab-content mt-4">
                        <!-- List Tab -->
                        <div class="tab-pane fade show active" id="list-tab">
                            <div class="card-modern shadow-sm">
                                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center py-3">
                                    <h6 class="mb-0 fw-bold">Treatment Management</h6>

                                    <?= $this->Html->link(
                                        '<i class="bi bi-plus-circle me-2"></i> Add New Treatment',
                                        ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'add'],
                                        [
                                            'class' => 'btn btn-primary fw-bold',
                                            'escape' => false,
                                            'escapeTitle' => false,
                                            'style' => '
                                                background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
                                                border: none;
                                                border-radius: 8px;
                                                padding: 10px 20px;
                                                box-shadow: 0 4px 12px rgba(165, 56, 96, 0.3);
                                                transition: all 0.3s ease;
                                            '
                                        ]
                                    ) ?>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-modern table-hover mb-0">
                                        <thead class="table-light">
                                        <tr>
                                            <th>ID</th>
                                            <th>Patient</th>
                                            <th>Doctor</th>
                                            <th>Sickness</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if (empty($treatments)): ?>
                                            <tr>
                                                <td colspan="7" class="text-center py-5">
                                                    <div class="py-4">
                                                        <i class="bi bi-clipboard-x fs-1 text-muted mb-3"></i>
                                                        <h6 class="text-muted mb-0">No treatments found</h6>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($treatments as $treatment): ?>
                                                <?php
                                                    $todayRow  = new \DateTime();
                                                    $startDate = new \DateTime($treatment->start_date);
                                                    $endDate   = new \DateTime($treatment->end_date);

                                                    $text  = 'Upcoming';
                                                    $class = 'status-text-upcoming';

                                                    if ($todayRow > $endDate) {
                                                        $text  = 'Completed';
                                                        $class = 'status-text-completed';
                                                    } elseif ($todayRow >= $startDate && $todayRow <= $endDate) {
                                                        $text  = 'Active';
                                                        $class = 'status-text-active';
                                                    }
                                                ?>
                                                <tr>
                                                    <td><span class="badge-id">#<?= h($treatment->id) ?></span></td>

                                                    <td>
                                                        <?php if ($treatment->has('patient')): ?>
                                                            <?= h($treatment->patient->fullname) ?>
                                                        <?php else: ?>
                                                            <?= h($treatment->patient_id) ?>
                                                        <?php endif; ?>
                                                    </td>

                                                    <td>
                                                        <?php if ($treatment->has('doctor')): ?>
                                                            <?= h($treatment->doctor->fullname) ?>
                                                        <?php else: ?>
                                                            <?= h($treatment->doctor_id) ?>
                                                        <?php endif; ?>
                                                    </td>

                                                    <td><?= h($treatment->sickness) ?></td>
                                                    <td>
                                                        <?php if (!empty($treatment->start_date)): ?>
                                                            <?= h($treatment->start_date->format('m/d/y')) ?>
                                                        <?php else: ?>
                                                            <span class="text-muted fst-italic">-</span>
                                                        <?php endif; ?>
                                                    </td>

                                                    <td>
                                                        <span class="status-text <?= $class ?>">
                                                            <span class="status-dot"></span>
                                                            <?= $text ?>
                                                        </span>
                                                    </td>

                                                    <td class="text-center">
                                                        <div class="action-buttons-sm">
                                                            <?= $this->Html->link('<i class="bi bi-eye"></i>',
                                                                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'view', $treatment->id],
                                                                ['class' => 'btn btn-outline-primary btn-sm', 'escape' => false]
                                                            ) ?>

                                                            <?= $this->Html->link('<i class="bi bi-pencil"></i>',
                                                                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'edit', $treatment->id],
                                                                ['class' => 'btn btn-outline-warning btn-sm', 'escape' => false]
                                                            ) ?>

                                                            <?= $this->Form->postLink('<i class="bi bi-trash"></i>',
                                                                ['prefix' => 'Admin', 'controller' => 'Treatments', 'action' => 'delete', $treatment->id],
                                                                [
                                                                    'class' => 'btn btn-outline-danger btn-sm',
                                                                    'escape' => false,
                                                                    'confirm' => 'Are you sure you want to delete treatment #' . h($treatment->id) . '?'
                                                                ]
                                                            ) ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Pagination -->
                                <div class="card-footer bg-white border-top py-3">
                                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                                        <div class="text-muted">
                                            <?= $this->Paginator->counter('Showing {{start}} to {{end}} of {{count}} treatments') ?>
                                        </div>
                                        <nav>
                                            <ul class="pagination justify-content-center mb-0 pagination-sm">
                                                <?= $this->Paginator->prev('Previous') ?>
                                                <?= $this->Paginator->numbers() ?>
                                                <?= $this->Paginator->next('Next') ?>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Analytics Tab -->
                        <div class="tab-pane fade" id="report-tab">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="card-modern analytics-card">
                                        <div class="card-body">
                                            <h5 class="card-title">Treatments by Month</h5>
                                            <canvas id="monthlyChart" height="250"></canvas>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card-modern analytics-card">
                                        <div class="card-body">
                                            <h5 class="card-title">Treatments by Status</h5>
                                            <canvas id="statusChart" height="250"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div><!-- /.tab-content -->
                </div><!-- /.card-body -->
            </div><!-- /.card-modern -->
        </main>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // sidebar
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn = document.getElementById('closeSidebar');
    var sidebar = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar) closeBtn.onclick = () => sidebar.classList.add('hide');

    // Charts
    const monthlyCtx = document.getElementById('monthlyChart');
    if (monthlyCtx) {
        new Chart(monthlyCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($monthArray ?? []) ?>,
                datasets: [{
                    label: 'Treatments',
                    data: <?= json_encode($countArray ?? []) ?>,
                    backgroundColor: "rgba(165, 56, 96, 0.2)",
                    borderColor: "rgba(165, 56, 96, 1)",
                    borderWidth: 1,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, grid: { color: "rgba(0,0,0,0.05)" } },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    const statusCtx = document.getElementById('statusChart');
    if (statusCtx) {
        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Active', 'Completed', 'Upcoming'],
                datasets: [{
                    data: [<?= (int)$page_active ?>, <?= (int)$page_completed ?>, <?= (int)$page_upcoming ?>],
                    backgroundColor: [
                        'rgba(25, 135, 84, 0.8)',
                        'rgba(108, 117, 125, 0.8)',
                        'rgba(255, 193, 7, 0.8)'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                cutout: '60%',
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
});

</script>
