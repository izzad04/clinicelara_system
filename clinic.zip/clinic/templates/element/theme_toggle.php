<button id="themeToggle" class="btn btn-sm btn-outline-secondary ms-auto">
    🌙 / 🌸
</button>

<script>
document.getElementById('themeToggle').onclick = () => {
    document.body.classList.toggle('dark-mode');
};
</script>
