<nav class="sidebar sidebar-user">
    <h4 class="fw-bold text-pink mb-4">
        <i class="bi bi-heart-fill"></i> Elara Clinic
    </h4>

    <?= $this->Html->link(
        '<i class="bi bi-speedometer"></i> Dashboard',
        ['controller' => 'Dashboards', 'action' => 'index'],
        ['escape' => false]
    ) ?>

    <?= $this->Html->link(
        '<i class="bi bi-calendar-event"></i> Appointments',
        ['controller' => 'Appointments', 'action' => 'index'],
        ['escape' => false]
    ) ?>

    <?= $this->Html->link(
        '<i class="bi bi-person-circle"></i> Profile',
        ['controller' => 'Users', 'action' => 'profile'],
        ['escape' => false]
    ) ?>

    <hr>

    <?= $this->Html->link(
        '<i class="bi bi-box-arrow-right"></i> Logout',
        ['controller' => 'Users', 'action' => 'logout'],
        ['escape' => false, 'class' => 'text-danger']
    ) ?>
</nav>
