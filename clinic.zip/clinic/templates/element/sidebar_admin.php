<aside class="admin-sidebar bg-light p-3">
    <h4 class="text-center mb-4">Elara Clinic</h4>

    <ul class="nav flex-column gap-2">
        <!-- Dashboard -->
        <li>
            <?= $this->Html->link(
                '<i class="bi bi-speedometer2 me-2"></i> Dashboard',
                ['prefix' => 'Admin', 'controller' => 'Dashboards', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link ' . ($this->request->getParam('controller') === 'Dashboards' ? 'active' : '')]
            ) ?>
        </li>

        <!-- Appointments -->
        <li>
            <?= $this->Html->link(
                '<i class="bi bi-calendar-check me-2"></i> Appointments',
                ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link ' . ($this->request->getParam('controller') === 'Appointments' ? 'active' : '')]
            ) ?>
        </li>

        <!-- Doctors -->
        <li>
            <?= $this->Html->link(
                '<i class="bi bi-person-badge me-2"></i> Doctors',
                ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link ' . ($this->request->getParam('controller') === 'Doctors' ? 'active' : '')]
            ) ?>
        </li>

        <!-- Patients -->
        <li>
            <?= $this->Html->link(
                '<i class="bi bi-people me-2"></i> Patients',
                ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link ' . ($this->request->getParam('controller') === 'Patients' ? 'active' : '')]
            ) ?>
        </li>

        <!-- Users -->
        <li>
            <?= $this->Html->link(
                '<i class="bi bi-person-lines-fill me-2"></i> Users',
                ['prefix' => 'Admin', 'controller' => 'Users', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link ' . ($this->request->getParam('controller') === 'Users' ? 'active' : '')]
            ) ?>
        </li>

        <hr>

        <!-- Profile -->
        <li>
            <?= $this->Html->link(
                '<i class="bi bi-person-circle me-2"></i> Profile',
                ['prefix' => 'Admin', 'controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link ' . ($this->request->getParam('action') === 'profile' ? 'active' : '')]
            ) ?>
        </li>

        <!-- Logout -->
        <li>
            <?= $this->Html->link(
                '<i class="bi bi-box-arrow-right me-2"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger']
            ) ?>
        </li>
    </ul>
</aside>
