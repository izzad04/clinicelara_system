<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="/">MyApp</a>

        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <?= $this->Html->link('Dashboard', '/dashboard', ['class' => 'nav-link']) ?>
            </li>
            <li class="nav-item">
                <?= $this->Html->link('Profile', ['controller' => 'Users', 'action' => 'profile'], ['class' => 'nav-link']) ?>
            </li>
            <li class="nav-item">
                <?= $this->Html->link('Logout', '/logout', ['class' => 'nav-link']) ?>
            </li>
        </ul>
    </div>
</nav>
