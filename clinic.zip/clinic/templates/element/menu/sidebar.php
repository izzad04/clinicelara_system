<?php
$c_name = $this->request->getParam('controller');
$a_name = $this->request->getParam('action');
?>

<!-- Sidebar -->
<nav id="sidebar" class="bg-body-tertiary shadow">
    <!-- Logo -->
    <div class="sidebar-header pt-3 pb-2 ps-3 border-bottom">
        <span class="fw-bold text-pink fs-5">
            <i class="fa-solid fa-clinic-medical me-1"></i>
            <?= h($system_abbr) ?>
        </span>
    </div>

    <ul class="list-unstyled components mt-3">

        <!-- ================= NOT LOGGED IN ================= -->
        <?php if (!$this->Identity->isLoggedIn()) : ?>
            <li class="menu-item">
                <?= $this->Html->link(
                    '<i class="fa-solid fa-right-to-bracket me-2"></i> Login',
                    ['controller' => 'Users', 'action' => 'login'],
                    ['class' => 'menu-link', 'escape' => false]
                ) ?>
            </li>
        <?php endif; ?>

        <!-- ================= LOGGED IN ================= -->
        <?php if ($this->Identity->isLoggedIn()) : ?>

            <!-- Dashboard -->
            <li class="menu-item <?= $c_name === 'Dashboards' ? 'active' : '' ?>">
                <?= $this->Html->link(
                    '<i class="fa-solid fa-gauge me-2"></i> Dashboard',
                    ['controller' => 'Dashboards', 'action' => 'index'],
                    ['class' => 'menu-link', 'escape' => false]
                ) ?>
            </li>

            <!-- Appointments -->
            <li class="menu-item <?= $c_name === 'Appointments' ? 'active' : '' ?>">
                <?= $this->Html->link(
                    '<i class="fa-solid fa-calendar-check me-2"></i> Appointments',
                    ['controller' => 'Appointments', 'action' => 'index'],
                    ['class' => 'menu-link', 'escape' => false]
                ) ?>
            </li>

            <!-- Patients -->
            <li class="menu-item <?= $c_name === 'Patients' ? 'active' : '' ?>">
                <?= $this->Html->link(
                    '<i class="fa-solid fa-bed-pulse me-2"></i> Patients',
                    ['controller' => 'Patients', 'action' => 'index'],
                    ['class' => 'menu-link', 'escape' => false]
                ) ?>
            </li>

            <!-- ================= ADMIN ONLY ================= -->
            <?php if ($this->Identity->get('user_group_id') == 1) : ?>

                <li class="menu-header text-uppercase small fw-bold mt-4 mb-2 ps-3">
                    Admin Panel
                </li>

                <!-- Appointments -->
            <li class="menu-item <?= $c_name === 'Appointments' ? 'active' : '' ?>">
                <?= $this->Html->link(
                    '<i class="fa-solid fa-calendar-check me-2"></i> Appointments',
                    ['prefix' => 'Admin', 'controller' => 'Appointments', 'action' => 'index'],
                    ['class' => 'menu-link', 'escape' => false]
                ) ?>
            </li>

            <!-- Patients -->
            <li class="menu-item <?= $c_name === 'Patients' ? 'active' : '' ?>">
                <?= $this->Html->link(
                    '<i class="fa-solid fa-bed-pulse me-2"></i> Patients',
                    ['prefix' => 'Admin', 'controller' => 'Patients', 'action' => 'index'],
                    ['class' => 'menu-link', 'escape' => false]
                ) ?>
            </li>

                <!-- Doctors -->
                <li class="menu-item <?= $c_name === 'Doctors' ? 'active' : '' ?>">
                    <?= $this->Html->link(
                        '<i class="fa-solid fa-user-doctor me-2"></i> Doctors',
                        ['prefix' => 'Admin', 'controller' => 'Doctors', 'action' => 'index'],
                        ['class' => 'menu-link', 'escape' => false]
                    ) ?>
                </li>

                <!-- User Management -->
                <li class="menu-item <?= $c_name === 'Users' && $a_name === 'index' ? 'active' : '' ?>">
                    <?= $this->Html->link(
                        '<i class="fa-solid fa-users me-2"></i> Users',
                        ['prefix' => 'Admin', 'controller' => 'Users', 'action' => 'index'],
                        ['class' => 'menu-link', 'escape' => false]
                    ) ?>
                </li>

                <!-- Settings -->
                <li class="menu-item <?= $c_name === 'Settings' ? 'active' : '' ?>">
                    <?= $this->Html->link(
                        '<i class="fa-solid fa-gear me-2"></i> Settings',
                        ['prefix' => 'Admin', 'controller' => 'Settings', 'action' => 'update'],
                        ['class' => 'menu-link', 'escape' => false]
                    ) ?>
                </li>

            <?php endif; ?>

            <!-- Profile -->
            <li class="menu-item mt-4 <?= $c_name === 'Users' && $a_name === 'profile' ? 'active' : '' ?>">
                <?= $this->Html->link(
                    '<i class="fa-solid fa-user me-2"></i> Profile',
                    ['controller' => 'Users', 'action' => 'profile'],
                    ['class' => 'menu-link', 'escape' => false]
                ) ?>
            </li>

            <!-- Logout -->
            <li class="menu-item">
                <?= $this->Html->link(
                    '<i class="fa-solid fa-right-from-bracket me-2"></i> Logout',
                    ['controller' => 'Users', 'action' => 'logout'],
                    ['class' => 'menu-link text-danger', 'escape' => false]
                ) ?>
            </li>

        <?php endif; ?>
    </ul>
</nav>
<!-- /Sidebar -->
