<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="/admin/dashboard">Admin Panel</a>

        <ul class="navbar-nav flex-row">
            <li class="nav-item me-3">
                <?= $this->Html->link('Users', '/admin/users', ['class' => 'nav-link text-white']) ?>
            </li>
            <li class="nav-item">
                <?= $this->Html->link('Logout', '/logout', ['class' => 'nav-link text-danger']) ?>
            </li>
        </ul>
    </div>
</nav>
