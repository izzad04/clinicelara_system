<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="webroot/img/logo.png" type="image/png">
    <title><?= $this->fetch('title', 'Elara Clinic') ?></title>

    <!-- 1. Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- 2. Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

    <!-- 3. Your custom CSS -->
    <?= $this->Html->css(['theme', 'sidebar']) ?>
    
    <!-- Page-specific CSS -->
    <?= $this->fetch('css') ?>
</head>
<body class="light-mode">

<div class="p-0">
    <?= $this->fetch('content') ?>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Your custom JS -->
<?= $this->Html->script('theme') ?>

<!-- Page-specific JS -->
<?= $this->fetch('script') ?>

<!-- Optional: Initialize Bootstrap tooltips -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>

</body>
</html>
