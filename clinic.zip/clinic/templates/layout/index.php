<?php
use Cake\Routing\Router;

$c_name = $this->request->getParam('controller');
$a_name = $this->request->getParam('action');
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <?= $this->Html->charset() ?>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" href="webroot/img/logo.png" type="image/png">
    
    <!-- SEO -->
    <title><?= h($system_name) ?> | <?= $this->fetch('title') ?></title>
    <meta name="description" content="<?= $metaDescription ?? 'Clinic Management System' ?>">
    <meta name="keywords" content="<?= $metaKeywords ?? 'clinic, appointment, doctor, patient' ?>">
    <meta name="author" content="<?= h($system_name) ?>">

    <!-- Favicon -->
    <?= $this->Html->meta('icon') ?>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <?= $this->Html->css('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css') ?>

    <!-- Font Awesome -->
    <?= $this->Html->css('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css') ?>

    <!-- App CSS -->
    <?= $this->Html->css('style') ?>

    <?= $this->fetch('css') ?>
</head>

<body class="bg-light text-body-secondary">

<!-- =================== WRAPPER =================== -->
<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <?= $this->element('menu/sidebar') ?>

    <!-- Page Content -->
    <div id="page-content-wrapper" class="flex-fill">

        <!-- Top Bar -->
        <?= $this->element('menu/topbar') ?>

        <!-- Main Content -->
        <main class="container-fluid py-4">
            <?= $this->Flash->render() ?>
            <?= $this->fetch('content') ?>
        </main>

        <!-- Footer -->
        <footer class="bg-white border-top py-3 mt-auto">
            <div class="container-fluid d-flex justify-content-between align-items-center">
                <small>
                    © <?= date('Y') ?> <?= h($system_name) ?> — All Rights Reserved
                </small>
                <small class="text-muted">
                    Built with <i class="fa-solid fa-heart text-danger"></i> using CakePHP
                </small>
            </div>
        </footer>

    </div>
</div>
<!-- =================== /WRAPPER =================== -->

<!-- JS -->
<?= $this->Html->script('https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js') ?>
<?= $this->Html->script('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js') ?>

<?= $this->fetch('script') ?>
<?= $this->fetch('scriptBottom') ?>

<script>
    $(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
        });
    });
</script>

</body>
</html>
