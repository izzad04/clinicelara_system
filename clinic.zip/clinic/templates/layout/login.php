<!DOCTYPE html>
<html>
<head>
    <?= $this->Html->charset() ?>

        <link rel="icon" href="webroot/img/logo.png" type="image/png">
        <title>Log In Elara Clinic</title>

    <?= $this->Html->css(['bootstrap.min', 'custom-login']) ?>
    <?= $this->fetch('css') ?>
</head>
<body>
    <?= $this->Flash->render() ?>
    <?= $this->fetch('content') ?>
</body>
</html>
