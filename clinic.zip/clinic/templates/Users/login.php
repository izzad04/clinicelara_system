<?php
echo $this->Html->css('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css');
$this->layout = 'login';
?>

<style>
/* ===== Page background ===== */
.login-page{
    min-height: 100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding: 24px 14px;
    position: relative;
    overflow:hidden;
    background:
        radial-gradient(900px 500px at 15% 15%, rgba(165,56,96,0.18), transparent 60%),
        radial-gradient(900px 500px at 85% 20%, rgba(79,70,229,0.16), transparent 60%),
        linear-gradient(135deg, #fff 0%, #f7f7fb 45%, #fff 100%);
}

/* soft “glass” overlay */
.login-bg-overlay{
    position:absolute;
    inset:0;
    background:
        radial-gradient(700px 420px at 30% 80%, rgba(255,193,7,0.10), transparent 55%),
        radial-gradient(700px 420px at 70% 70%, rgba(34,197,94,0.08), transparent 55%);
    pointer-events:none;
}

/* ===== Card ===== */
.login-card{
    width: 100%;
    max-width: 440px;
    border: 1px solid rgba(0,0,0,0.06);
    background: rgba(255,255,255,0.92);
    backdrop-filter: blur(10px);
    box-shadow: 0 20px 60px rgba(0,0,0,0.10);
    position: relative;
    z-index: 2;
}

/* top accent bar */
.login-card:before{
    content:"";
    position:absolute;
    top:0; left:0; right:0;
    height:6px;
    border-top-left-radius: 18px;
    border-top-right-radius: 18px;
    background: linear-gradient(90deg, #A53860 0%, #C44569 45%, #7c3aed 100%);
}

/* ===== Brand ===== */
.text-pink{ color:#A53860; }

/* ===== Form inputs ===== */
.form-control-lg{
    border: 1px solid rgba(0,0,0,0.10) !important;
    box-shadow: none !important;
    padding-left: 44px !important; /* space for icon */
}
.form-control-lg:focus{
    border-color: rgba(165,56,96,0.55) !important;
    box-shadow: 0 0 0 0.25rem rgba(165,56,96,0.15) !important;
}
.input-icon-wrap{ position: relative; }
.input-icon{
    position:absolute;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(0,0,0,0.45);
    font-size: 1rem;
    pointer-events:none;
}

/* ===== Buttons ===== */
.btn-pink{
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
    border: none;
    box-shadow: 0 10px 22px rgba(165,56,96,0.25);
}
.btn-pink:hover{
    filter: brightness(0.98);
    transform: translateY(-1px);
}
.btn-pink:active{
    transform: translateY(0px);
}
.btn-outline-danger{
    border-color: rgba(220,53,69,0.35) !important;
}

/* ===== Links ===== */
.auth-links a{
    color:#A53860;
    text-decoration:none;
    font-weight:600;
}
.auth-links a:hover{ text-decoration: underline; }

/* ===== Small helper ===== */
.small-muted{ color: rgba(0,0,0,0.55); }
</style>

<!-- Font Awesome (for icons) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<div class="login-page">

    <div class="card rounded-4 p-4 p-md-5 login-card">

        <!-- Logo / Clinic Name -->
        <div class="text-center mb-4">
            <?= $this->Html->image('logo.png', [
                'alt' => 'Elara Clinic Logo',
                'class' => 'img-fluid mb-2',
                'style' => 'max-height:86px;'
            ]) ?>

            <h2 class="fw-bold text-pink mb-1">Elara Clinic</h2>
            <p class="small-muted mb-0" style="font-size:0.95rem;">
                Welcome back! Please login to continue
            </p>
        </div>

        <!-- Flash message (optional) -->
        <?= $this->Flash->render() ?>

        <!-- Login Form -->
        <?= $this->Form->create(null, ['class' => 'mt-3']) ?>

        <!-- Email -->
        <div class="mb-3 input-icon-wrap">
            <span class="input-icon"><i class="fa-solid fa-envelope"></i></span>
            <?= $this->Form->control('email', [
                'label' => false,
                'required' => true,
                'class' => 'form-control form-control-lg rounded-pill',
                'placeholder' => 'Email Address',
                'autocomplete' => 'off'
            ]) ?>
        </div>

        <!-- Password -->
        <div class="mb-2 input-icon-wrap">
            <span class="input-icon"><i class="fa-solid fa-lock"></i></span>
            <?= $this->Form->control('password', [
                'label' => false,
                'required' => true,
                'class' => 'form-control form-control-lg rounded-pill',
                'placeholder' => 'Password'
            ]) ?>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="form-check ms-1">
                <input class="form-check-input" type="checkbox" value="1" id="rememberMe" name="remember_me">
                <label class="form-check-label small text-muted" for="rememberMe">Remember me</label>
            </div>

            <div class="small auth-links">
                <?= $this->Html->link('Forgot Password?', ['action' => 'forgotPassword']) ?>
            </div>
        </div>

        <div class="d-grid gap-2 mb-2">
            <?= $this->Form->button('<i class="fa-solid fa-right-to-bracket me-2"></i>Login', [
                'type' => 'submit',
                'class' => 'btn btn-pink btn-lg rounded-pill text-white',
                'escape' => false,
                'escapeTitle'=>false
            ]) ?>

            <?= $this->Form->button('<i class="fa-solid fa-rotate-left me-2"></i>Reset', [
                'type' => 'reset',
                'class' => 'btn btn-outline-danger btn-lg rounded-pill',
                'escape' => false,
                'escapeTitle'=>false
            ]) ?>
        </div>

        <?= $this->Form->end() ?>

        <!-- Links -->
        <div class="text-center mt-3 auth-links" style="font-size:0.9rem;">
            <span class="text-muted">No account?</span>
            <?= $this->Html->link('Register', ['action' => 'registration'], ['class' => 'ms-1']) ?>
        </div>

        <hr class="my-4">

        <p class="text-center small text-muted mb-0">
            &copy; <?= date('Y') ?> Elara Clinic. All rights reserved.
        </p>
    </div>

    <!-- Background Overlay -->
    <div class="login-bg-overlay"></div>
</div>
