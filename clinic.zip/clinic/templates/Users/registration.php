<?php
echo $this->Html->css('select2/css/select2.css');
echo $this->Html->script('select2/js/select2.full.min.js');
// Page-specific CSS
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" 
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
/* Registration Page Specific Styles */
.registration-wrapper {
    min-height: 100vh;
    background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.registration-card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    width: 100%;
    max-width: 1200px;
}

.registration-header {
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
    color: white;
    padding: 40px;
    text-align: center;
}

.registration-header h1 {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 10px;
}

.registration-header p {
    font-size: 1.1rem;
    opacity: 0.9;
}

.registration-body {
    padding: 40px;
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 40px;
}

@media (max-width: 992px) {
    .registration-body {
        grid-template-columns: 1fr;
    }
}

.form-section h3 {
    color: #333;
    font-size: 1.5rem;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f0f0f0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-section h3 i {
    color: #A53860;
}

.form-group {
    margin-bottom: 25px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #495057;
    font-size: 0.95rem;
}

.form-control {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: #f8f9fa;
}

.form-control:focus {
    outline: none;
    border-color: #A53860;
    background: white;
    box-shadow: 0 0 0 3px rgba(165, 56, 96, 0.1);
}

.form-control.error {
    border-color: #dc3545;
}

.form-control.success {
    border-color: #28a745;
}

.form-text {
    font-size: 0.85rem;
    color: #6c757d;
    margin-top: 6px;
}

.row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

@media (max-width: 768px) {
    .row {
        grid-template-columns: 1fr;
    }
}

/* File Upload Styling */
.file-upload-container {
    position: relative;
    margin-top: 5px;
}

.file-upload-label {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 15px;
    background: #f8f9fa;
    border: 2px dashed #dee2e6;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.file-upload-label:hover {
    background: #e9ecef;
    border-color: #A53860;
}

.file-upload-label i {
    font-size: 1.5rem;
    color: #A53860;
}

.file-upload-input {
    position: absolute;
    width: 0;
    height: 0;
    opacity: 0;
}

.file-name {
    margin-top: 10px;
    font-size: 0.9rem;
    color: #495057;
}

/* Terms Checkbox Styling */
.terms-container {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    margin: 30px 0;
}

.terms-checkbox {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    cursor: pointer;
}

.terms-checkbox input[type="checkbox"] {
    width: 20px;
    height: 20px;
    margin-top: 3px;
    cursor: pointer;
}

.terms-checkbox label {
    margin: 0;
    font-weight: normal;
    cursor: pointer;
    line-height: 1.5;
}

.terms-checkbox a {
    color: #A53860;
    text-decoration: none;
    font-weight: 500;
}

.terms-checkbox a:hover {
    text-decoration: underline;
}

/* Submit Button */
.submit-btn {
    width: 100%;
    padding: 15px;
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-top: 20px;
}

.submit-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(165, 56, 96, 0.3);
}

.submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

/* Info Card */
.info-card {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 15px;
    padding: 30px;
    border-left: 5px solid #A53860;
}

.info-card h4 {
    color: #333;
    font-size: 1.3rem;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-card h4 i {
    color: #A53860;
}

.info-card ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.info-card li {
    padding: 12px 0;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    color: #495057;
    display: flex;
    align-items: flex-start;
    gap: 12px;
}

.info-card li:last-child {
    border-bottom: none;
}

.info-card li i {
    color: #28a745;
    margin-top: 3px;
    flex-shrink: 0;
}

/* Password Strength Indicator */
.password-strength {
    margin-top: 10px;
}

.strength-bar {
    height: 6px;
    background: #e9ecef;
    border-radius: 3px;
    overflow: hidden;
    margin-bottom: 8px;
}

.strength-fill {
    height: 100%;
    width: 0%;
    background: #dc3545;
    border-radius: 3px;
    transition: all 0.3s ease;
}

.strength-text {
    font-size: 0.85rem;
    font-weight: 500;
}

.strength-text.weak {
    color: #dc3545;
}

.strength-text.fair {
    color: #fd7e14;
}

.strength-text.good {
    color: #ffc107;
}

.strength-text.strong {
    color: #28a745;
}

/* Logo */
.registration-logo {
    width: 100px;
    height: 100px;
    margin: 0 auto 20px;
    background: white;
    border-radius: 50%;
    padding: 15px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.registration-logo img {
    width: 100%;
    height: 100%;
    object-fit: contain;
}
</style>

<!-- Registration Content -->
<div class="registration-wrapper">
    <div class="registration-card">
        <!-- Header -->
        <div class="registration-header">
            <div class="registration-logo">
                <?= $this->Html->image('logo.png', [
                    'alt' => 'Elara Clinic Logo',
                    'class' => 'logo-img'
                ]) ?>
            </div>
            <h1>Create Your Account</h1>
            <p>Join Elara Clinic as a new user</p>
        </div>

        <!-- Body -->
        <div class="registration-body">
            <!-- Form Section -->
            <div class="form-section">
                <?= $this->Form->create($user, [
                    'type' => 'file', 
                    'novalidate' => true,
                    'id' => 'registrationForm',
                    'class' => 'registration-form'
                ]) ?>
                
                <h3><i class="fas fa-user-circle"></i> Personal Information</h3>
                
                <div class="row">
                    <div class="form-group">
                        <label for="fullname">Full Name <span class="text-danger">*</span></label>
                        <?= $this->Form->control('fullname', [
                            'label' => false,
                            'class' => 'form-control',
                            'placeholder' => 'Enter your full name',
                            'required' => false,
                            'id' => 'fullname'
                        ]) ?>
                        <div class="form-text">Enter your complete name as per IC</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address <span class="text-danger">*</span></label>
                        <?= $this->Form->control('email', [
                            'label' => false,
                            'class' => 'form-control',
                            'placeholder' => 'you@example.com',
                            'required' => false,
                            'id' => 'email',
                            'type' => 'email'
                        ]) ?>
                        <div class="form-text">We'll never share your email with anyone else</div>
                    </div>
                </div>

                <h3><i class="fas fa-lock"></i> Security Information</h3>
                
                <div class="row">
                    <div class="form-group">
                        <label for="password">Password <span class="text-danger">*</span></label>
                        <?= $this->Form->control('password', [
                            'label' => false,
                            'class' => 'form-control password-input',
                            'placeholder' => 'Create a strong password',
                            'required' => false,
                            'id' => 'password',
                            'type' => 'password'
                        ]) ?>
                        <div class="password-strength">
                            <div class="strength-bar">
                                <div class="strength-fill" id="strengthFill"></div>
                            </div>
                            <div class="strength-text" id="strengthText">Password strength</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="cpassword">Confirm Password <span class="text-danger">*</span></label>
                        <?= $this->Form->control('cpassword', [
                            'label' => false,
                            'class' => 'form-control confirm-password',
                            'placeholder' => 'Re-enter your password',
                            'required' => false,
                            'id' => 'cpassword',
                            'type' => 'password'
                        ]) ?>
                        <div class="form-text" id="passwordMatchText">Passwords must match</div>
                    </div>
                </div>

                <h3><i class="fas fa-image"></i> Profile Image</h3>
                
                <div class="form-group">
                    <label>Upload Profile Picture (Optional)</label>
                    <div class="file-upload-container">
                        <label class="file-upload-label" for="avatar">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <span>Choose file or drag and drop</span>
                        </label>
                        <?= $this->Form->control('avatar', [
                            'type' => 'file',
                            'required' => false,
                            'class' => 'file-upload-input',
                            'label' => false,
                            'id' => 'avatar'
                        ]) ?>
                        <div class="file-name" id="fileName">No file chosen</div>
                    </div>
                    <div class="form-text">Max file size: 5MB. Supported: JPG, PNG</div>
                </div>

                <div class="terms-container">
                    <div class="terms-checkbox">
                        <?= $this->Form->checkbox('terms', [
                            'value' => '1',
                            'class' => 'form-check-input',
                            'id' => 'terms',
                            'required' => true
                        ]) ?>
                        <label for="terms">
                            I agree to the <a href="#" onclick="showTerms()">Terms & Conditions</a> 
                            and <a href="#" onclick="showPrivacy()">Privacy Policy</a> of Elara Clinic
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" id="submitBtn" class="submit-btn" disabled>
                        <i class="fas fa-user-plus me-2"></i> Create Account
                    </button>
                </div>
                
                <?= $this->Form->end() ?>
            </div>

            <!-- Information Section -->
            <div class="info-section">
                <div class="info-card">
                    <h4><i class="fas fa-info-circle"></i> Registration Guidelines</h4>
                    <ul>
                        <li><i class="fas fa-check-circle"></i> All information provided must be accurate and truthful</li>
                        <li><i class="fas fa-check-circle"></i> Each email can register only one account</li>
                        <li><i class="fas fa-check-circle"></i> Use strong password for account security</li>
                        <li><i class="fas fa-check-circle"></i> Contact administrator for registration assistance</li>
                        <li><i class="fas fa-check-circle"></i> Profile picture is optional but recommended</li>
                        <li><i class="fas fa-check-circle"></i> Read terms & conditions before proceeding</li>
                    </ul>
                </div>
                
                <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                    <p style="color: #6c757d; margin-bottom: 15px;">Already have an account?</p>
                    <?= $this->Html->link(
                        '<i class="fas fa-sign-in-alt me-2"></i> Sign In Here',
                        ['controller' => 'Users', 'action' => 'login'],
                        ['class' => 'btn btn-outline-primary', 'escape' => false]
                    ) ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registrationForm');
    const submitBtn = document.getElementById('submitBtn');
    const termsCheckbox = document.getElementById('terms');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('cpassword');
    const passwordMatchText = document.getElementById('passwordMatchText');
    const strengthFill = document.getElementById('strengthFill');
    const strengthText = document.getElementById('strengthText');
    const fileInput = document.getElementById('avatar');
    const fileName = document.getElementById('fileName');
    
    // Check terms checkbox to enable submit button
    termsCheckbox.addEventListener('change', function() {
        submitBtn.disabled = !this.checked;
        console.log('Terms checked:', this.checked, 'Submit disabled:', submitBtn.disabled);
    });
    
    // Password strength checker
    passwordInput.addEventListener('input', function() {
        checkPasswordStrength(this.value);
        checkPasswordMatch();
    });
    
    // Confirm password checker
    confirmPasswordInput.addEventListener('input', checkPasswordMatch);
    
    // File upload display
    fileInput.addEventListener('change', function() {
        if (this.files.length > 0) {
            fileName.textContent = this.files[0].name;
            fileName.style.color = '#28a745';
        } else {
            fileName.textContent = 'No file chosen';
            fileName.style.color = '#495057';
        }
    });
    
    // Password strength function
    function checkPasswordStrength(password) {
        let strength = 0;
        let text = 'Password strength';
        let color = '#dc3545';
        let width = 0;
        
        if (password.length >= 8) strength++;
        if (/[a-z]/.test(password)) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[^A-Za-z0-9]/.test(password)) strength++;
        
        switch(strength) {
            case 0:
            case 1:
                text = 'Very Weak';
                color = '#dc3545';
                width = 20;
                break;
            case 2:
                text = 'Weak';
                color = '#dc3545';
                width = 40;
                break;
            case 3:
                text = 'Fair';
                color = '#fd7e14';
                width = 60;
                break;
            case 4:
                text = 'Good';
                color = '#ffc107';
                width = 80;
                break;
            case 5:
                text = 'Strong';
                color = '#28a745';
                width = 100;
                break;
        }
        
        strengthFill.style.width = width + '%';
        strengthFill.style.backgroundColor = color;
        strengthText.textContent = text;
        strengthText.className = 'strength-text ' + text.toLowerCase().replace(' ', '-');
    }
    
    // Password match checker
    function checkPasswordMatch() {
        const password = passwordInput.value;
        const confirm = confirmPasswordInput.value;
        
        if (confirm === '') {
            passwordMatchText.textContent = 'Passwords must match';
            passwordMatchText.style.color = '#6c757d';
            confirmPasswordInput.classList.remove('error', 'success');
        } else if (password === confirm) {
            passwordMatchText.textContent = '✓ Passwords match';
            passwordMatchText.style.color = '#28a745';
            confirmPasswordInput.classList.remove('error');
            confirmPasswordInput.classList.add('success');
        } else {
            passwordMatchText.textContent = '✗ Passwords do not match';
            passwordMatchText.style.color = '#dc3545';
            confirmPasswordInput.classList.remove('success');
            confirmPasswordInput.classList.add('error');
        }
    }
    
    // Form validation before submission
    form.addEventListener('submit', function(e) {
        // Basic validation
        const fullname = document.getElementById('fullname').value.trim();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const confirm = document.getElementById('cpassword').value;
        
        let isValid = true;
        let errorMessage = '';
        
        // Check required fields
        if (!fullname) {
            isValid = false;
            errorMessage += '• Full name is required\n';
        }
        
        if (!email) {
            isValid = false;
            errorMessage += '• Email address is required\n';
        } else if (!isValidEmail(email)) {
            isValid = false;
            errorMessage += '• Please enter a valid email address\n';
        }
        
        if (!password) {
            isValid = false;
            errorMessage += '• Password is required\n';
        } else if (password.length < 8) {
            isValid = false;
            errorMessage += '• Password must be at least 8 characters\n';
        }
        
        if (password !== confirm) {
            isValid = false;
            errorMessage += '• Passwords do not match\n';
        }
        
        if (!termsCheckbox.checked) {
            isValid = false;
            errorMessage += '• You must agree to the terms and conditions\n';
        }
        
        if (!isValid) {
            e.preventDefault();
            alert('Please fix the following errors:\n\n' + errorMessage);
        }
    });
    
    // Email validation helper
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
});

// Modal functions (you can implement these)
function showTerms() {
    alert('Terms and conditions modal would appear here. Implement a modal with your terms.');
}

function showPrivacy() {
    alert('Privacy policy modal would appear here. Implement a modal with your privacy policy.');
}
</script>