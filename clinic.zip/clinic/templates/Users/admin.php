<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <?= $this->Html->css('admin.css') ?>
</head>
<body>
    <?= $this->element('admin/navbar') ?>
    <?= $this->fetch('content') ?>
</body>
</html>
