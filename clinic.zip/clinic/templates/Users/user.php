<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <?= $this->Html->css('user.css') ?>
</head>
<body>
    <?= $this->element('user/navbar') ?>
    <?= $this->fetch('content') ?>
</body>
</html>
