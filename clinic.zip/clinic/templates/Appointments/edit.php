<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Appointment $appointment
 * @var string[]|\Cake\Collection\CollectionInterface $users
 * @var string[]|\Cake\Collection\CollectionInterface $patients
 * @var string[]|\Cake\Collection\CollectionInterface $doctors
 */

echo $this->Html->css('appointment_admin');

$statusOptions = [
    1 => 'Confirmed',
    2 => 'Scheduled',
    4 => 'Cancelled',
];

$currentStatusLabel = $statusOptions[(int)($appointment->status ?? 0)] ?? 'Unknown';

// ✅ nicer date text
$createdText  = $appointment->created ? $appointment->created->format('M d, Y • h:i A') : '-';
$modifiedText = $appointment->modified ? $appointment->modified->format('M d, Y • h:i A') : '-';
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" 
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- FLATPICKR FOR DATE/TIME PICKER -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<!-- Appointment Edit Form -->
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', ['alt' => 'Elara Clinic Logo', 'class' => 'logo-img']) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Patient Panel</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="bi bi-x-lg"></i> Close
            </button>
        </div>

        <!-- Navigation Menu -->
            <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="bi bi-list fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block">Edit Appointment #<?= h($appointment->id) ?></h5>
                <h5 class="m-0 d-md-none">Edit Appointment</h5>
            </div>

            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    [ 'controller' => 'Appointments', 'action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <main class="content-area">
            <div class="row">
                <div class="col-lg-8">
                    <div class="card-modern shadow-lg">
                        <!-- ✅ nicer header + status pill -->
                        <div class="card-header bg-transparent border-bottom py-3">
                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                                <h4 class="mb-0 fw-bold text-primary">
                                    <i class="bi bi-pencil-square me-2"></i>Edit Appointment Details
                                </h4>

                                <span class="badge rounded-pill px-3 py-2 bg-info">
                                    <i class="bi bi-activity me-1"></i><?= h($currentStatusLabel) ?>
                                </span>
                            </div>

                            <!-- ✅ created/updated inside SAME card header -->
                            <div class="mt-3 info-meta">
                                <div class="meta-item">
                                    <i class="bi bi-calendar2-plus me-2"></i>
                                    <span class="meta-label">Created</span>
                                    <span class="meta-value"><?= h($createdText) ?></span>
                                </div>
                                <div class="meta-divider"></div>
                                <div class="meta-item">
                                    <i class="bi bi-arrow-repeat me-2"></i>
                                    <span class="meta-label">Last Updated</span>
                                    <span class="meta-value"><?= h($modifiedText) ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="card-body p-4">
                            <?= $this->Form->create($appointment, [
                                'class' => 'edit-appointment-form',
                                'id' => 'editAppointmentForm'
                            ]) ?>

                            <div class="row g-4">
                                <!-- Appointment Info -->
                                <div class="col-12">
                                    <div class="info-card bg-light p-3 rounded-3">
                                        <div class="d-flex align-items-center">
                                            <div class="info-icon me-3">
                                                <i class="bi bi-info-circle-fill text-primary fs-4"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted">APPOINTMENT ID</small>
                                                <h5 class="mb-0">#<?= h($appointment->id) ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Patient -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="patient_id" class="form-label fw-bold">
                                            <i class="bi bi-person-heart text-primary me-2"></i>Patient
                                        </label>
                                        <?= $this->Form->control('patient_id', [
                                            'options' => $patients,
                                            'empty' => 'Select Patient',
                                            'label' => false,
                                            'class' => 'form-select form-select-lg',
                                            'id' => 'patient_id',
                                            'required' => true
                                        ]) ?>
                                        <small class="text-muted">Choose the patient for this appointment</small>
                                    </div>
                                </div>

                                <!-- Doctor -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="doctor_id" class="form-label fw-bold">
                                            <i class="bi bi-person-badge text-success me-2"></i>Doctor
                                        </label>
                                        <?= $this->Form->control('doctor_id', [
                                            'options' => $doctors,
                                            'empty' => 'Select Doctor',
                                            'label' => false,
                                            'class' => 'form-select form-select-lg',
                                            'id' => 'doctor_id',
                                            'required' => true
                                        ]) ?>
                                        <small class="text-muted">Assign a doctor to this appointment</small>
                                    </div>
                                </div>

                                <!-- Date -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="date" class="form-label fw-bold">
                                            <i class="bi bi-calendar-date text-info me-2"></i>Appointment Date
                                        </label>
                                        <?= $this->Form->control('date', [
                                            'type' => 'date',
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'id' => 'date',
                                            'required' => true
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Time -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="time" class="form-label fw-bold">
                                            <i class="bi bi-clock text-info me-2"></i>Appointment Time
                                        </label>
                                        <?= $this->Form->control('time', [
                                            'type' => 'time',
                                            'label' => false,
                                            'class' => 'form-control form-control-lg',
                                            'id' => 'time',
                                            'required' => true
                                        ]) ?>
                                    </div>
                                </div>

                                <!-- Status (INTEGER) -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status" class="form-label fw-bold">
                                            <i class="bi bi-circle-fill text-warning me-2"></i>Status
                                        </label>
                                        <?= $this->Form->control('status', [
                                            'type' => 'select',
                                            'options' => $statusOptions,
                                            'empty' => 'Select Status',
                                            'label' => false,
                                            'class' => 'form-select form-select-lg',
                                            'id' => 'status',
                                            'required' => true
                                        ]) ?>
                                        <small class="text-muted">Update appointment status</small>
                                    </div>
                                </div>

                                <!-- Assigned To -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="user_id" class="form-label fw-bold">
                                            <i class="bi bi-person-circle text-warning me-2"></i>Assigned To
                                        </label>
                                        <?= $this->Form->control('user_id', [
                                            'options' => $users,
                                            'empty' => 'Assign Staff',
                                            'label' => false,
                                            'class' => 'form-select form-select-lg',
                                            'id' => 'user_id',
                                            'required' => true
                                        ]) ?>
                                        <small class="text-muted">Staff member responsible</small>
                                    </div>
                                </div>

                                <!-- ✅ Notes FULL WIDTH nice box (same row width as above) -->
                                <div class="col-12">
                                    <div class="notes-wrap">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <label for="notes" class="form-label fw-bold mb-0">
                                                <i class="bi bi-journal-text me-2"></i>Notes & Details
                                            </label>
                                            <span class="text-muted small">
                                                Optional
                                            </span>
                                        </div>

                                        <?= $this->Form->control('notes', [
                                            'type' => 'textarea',
                                            'label' => false,
                                            'class' => 'form-control form-control-lg notes-textarea',
                                            'id' => 'notes',
                                            'rows' => 6,
                                            'placeholder' => 'Enter any important notes, symptoms, or special instructions...'
                                        ]) ?>

                                        <div class="d-flex justify-content-between mt-2">
                                            <small class="text-muted">Additional information about this appointment</small>
                                            <small class="text-muted" id="notesCount"></small>
                                        </div>
                                    </div>
                                </div>

                                <!-- Buttons -->
                                <div class="col-12 mt-3 pt-3 border-top">
                                    <div class="d-flex justify-content-between flex-wrap gap-2">
                                        <div class="d-flex gap-2 flex-wrap">
                                            <?= $this->Html->link(
                                                '<i class="bi bi-x-circle me-2"></i> Cancel',
                                                ['action' => 'view', $appointment->id],
                                                ['class' => 'btn btn-outline-secondary btn-lg', 'escape' => false]
                                            ) ?>
                                            <button type="reset" class="btn btn-outline-warning btn-lg">
                                                <i class="bi bi-arrow-clockwise me-2"></i> Reset
                                            </button>
                                        </div>

                                        <div>
                                            <?= $this->Form->button('<i class="bi bi-check-circle me-2"></i> Update Appointment', [
                                                'type' => 'submit',
                                                'class' => 'btn btn-primary btn-lg fw-bold px-4',
                                                'escape' => false,
                                                'escapeTitle'=>false,
                                                'style' => '
                                                    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
                                                    border: none;
                                                    box-shadow: 0 4px 15px rgba(165, 56, 96, 0.3);
                                                '
                                            ]) ?>
                                        </div>
                                    </div>
                                </div>

                            </div><!-- row -->
                            <?= $this->Form->end() ?>
                        </div>
                    </div>
                </div>

                <!-- Right Sidebar -->
                <div class="col-lg-4">
                    <div class="card-modern shadow-sm">
                        <div class="card-header bg-transparent border-bottom py-3">
                            <h5 class="mb-0 fw-bold">
                                <i class="bi bi-lightning me-2"></i>Quick Actions
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <?= $this->Html->link(
                                    '<i class="bi bi-eye me-2"></i> View Appointment',
                                    ['action' => 'view', $appointment->id],
                                    ['class' => 'btn btn-outline-primary btn-lg', 'escape' => false]
                                ) ?>
                                <?= $this->Form->postLink(
                                    '<i class="bi bi-trash me-2"></i> Delete Appointment',
                                    ['action' => 'delete', $appointment->id],
                                    [
                                        'confirm' => __('Are you sure you want to delete appointment #{0}?', $appointment->id),
                                        'class' => 'btn btn-outline-danger btn-lg',
                                        'escape' => false
                                    ]
                                ) ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div><!-- row -->
        </main>
    </div>
</div>

<!-- JavaScript for Sidebar -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn  = document.getElementById('closeSidebar');
    var sidebar   = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar)  closeBtn.onclick  = () => sidebar.classList.add('hide');

    // Notes counter (optional nice touch)
    var notes = document.getElementById('notes');
    var out = document.getElementById('notesCount');
    if (notes && out) {
        var update = function(){
            out.textContent = notes.value.length + " chars";
        };
        notes.addEventListener('input', update);
        update();
    }
});
</script>

<style>
/* ===== SINGLE SCROLL FIX (remove double scrollbar) ===== */
html, body { height: 100%; overflow: hidden !important; }
.admin-wrapper { height: 100vh; }
.main-content  { height: 100vh; overflow: hidden !important; }
.content-area  {
    overflow-y: auto !important;
    overflow-x: hidden !important;
    height: calc(100vh - 70px) !important; /* adjust if header height differs */
}

/* ===== Form styling ===== */
.edit-appointment-form .form-label { font-size: 0.9rem; margin-bottom: 0.5rem; }
.edit-appointment-form .form-control-lg,
.edit-appointment-form .form-select-lg { padding: 0.75rem 1rem; font-size: 1rem; }

.edit-appointment-form .info-card {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-left: 4px solid #A53860;
}

.btn-lg { padding: 0.75rem 1.5rem; font-size: 1rem; }

/* ===== Header meta (Created / Updated) ===== */
.info-meta{
    display:flex;
    align-items:center;
    gap:14px;
    padding: 10px 0 0;
    flex-wrap: wrap;
}
.meta-item{
    display:flex;
    align-items:center;
    gap:8px;
    font-size: 0.92rem;
    color:#6c757d;
}
.meta-label{ font-weight:600; color:#495057; }
.meta-value{ font-weight:600; color:#343a40; }
.meta-divider{
    width:1px;
    height:18px;
    background:#e9ecef;
}

/* ===== Notes full width nicer ===== */
.notes-wrap{
    border: 1px solid #e9ecef;
    border-radius: 14px;
    padding: 16px;
    background: #fff;
    box-shadow: 0 8px 20px rgba(0,0,0,0.04);
}
.notes-textarea{
    border-radius: 12px;
    resize: vertical;
    min-height: 160px;
}
</style>
