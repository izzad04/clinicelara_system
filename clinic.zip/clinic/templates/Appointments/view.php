<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Appointment $appointment
 */

echo $this->Html->css('appointment_admin');
echo $this->Html->css('index_dashboard');

$currentUser   = $this->request->getAttribute('identity');
$currentUserId = (int)($currentUser->id ?? 0);
$userGroupId   = (int)($currentUser->user_group_id ?? 0); // 1 = admin
$isAdmin       = ($userGroupId === 1);

$isOwner = (
    $appointment->has('patient') &&
    (int)($appointment->patient->user_id ?? 0) === $currentUserId
);

$canView = $isAdmin || $isOwner;

/** UI-only status */
$appointmentDate = $appointment->date ?? null;
$appointmentTime = $appointment->time ?? null;

$dateStr = is_object($appointmentDate) && method_exists($appointmentDate, 'format')
    ? $appointmentDate->format('Y-m-d')
    : (string)$appointmentDate;

$timeStr = is_object($appointmentTime) && method_exists($appointmentTime, 'format')
    ? $appointmentTime->format('H:i:s')
    : (string)$appointmentTime;

$appointmentDateTime = strtotime(trim($dateStr . ' ' . $timeStr));
$now = time();

if ($appointmentDateTime !== false && $appointmentDateTime < $now) {
    $statusText  = 'Completed';
    $statusClass = 'status-text-completed';
} else {
    $statusText  = 'Active';
    $statusClass = 'status-text-active';
}

/** Assigned to name */
$assignedName = 'N/A';
if ($appointment->has('user') && !empty($appointment->user)) {
    // change fullname -> name if your column is "name"
    $assignedName = $appointment->user->fullname ?? $appointment->user->name ?? 'N/A';
}
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
/* ===================== FIX DOUBLE SCROLLBAR ===================== */
/* Make ONLY body scroll */
html, body { height: auto !important; overflow-y: auto !important; }

/* Stop inner containers from creating another scrollbar */
.admin-wrapper, .main-content, .content-area { overflow: visible !important; }
.content-area { height: auto !important; min-height: 0 !important; }

/* Sometimes these cause horizontal scroll */
.admin-wrapper, .main-content, .content-area { overflow-x: hidden !important; }

/* ===================== STATUS (dot + text) ===================== */
.status-text{display:inline-flex;align-items:center;gap:8px;font-weight:600;}
.status-dot{width:8px;height:8px;border-radius:999px;background:#adb5bd;}
.status-text-active{color:#198754;}
.status-text-active .status-dot{background:#198754;}
.status-text-completed{color:#6c757d;}
.status-text-completed .status-dot{background:#6c757d;}

/* Timeline mini cards */
.timeline-mini-card{
    background:#f8f9fa;border:1px solid #e9ecef;border-radius:12px;padding:14px;
}
</style>

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', ['alt'=>'Elara Clinic Logo','class'=>'logo-img']) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted">Patient Portal</small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="fas fa-times"></i> Close
            </button>
        </div>

        <!-- Navigation Menu -->
            <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="fas fa-bars fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block"><?= $canView ? 'Appointment Details' : 'Access Restricted' ?></h5>
                <h5 class="m-0 d-md-none"><?= $canView ? 'Details' : 'Restricted' ?></h5>
            </div>

            <!-- ONLY BACK AT TOP -->
            <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="fas fa-arrow-left me-2"></i> Back',
                    ['controller' => 'Appointments', 'action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
        </header>

        <main class="content-area">
            <?php if (!$canView): ?>
                <div class="row">
                    <div class="col-12">
                        <div class="card-modern shadow-lg mb-4">
                            <div class="card-body text-center py-5">
                                <i class="fa-solid fa-lock fa-4x text-warning mb-4"></i>
                                <h3 class="text-danger mb-3">Access Denied</h3>
                                <p class="text-muted mb-4">You don't have permission to view this appointment.</p>

                                <?= $this->Html->link(
                                    '<i class="fa-solid fa-arrow-left me-2"></i> Back to Appointments',
                                    ['action' => 'index'],
                                    ['class' => 'btn btn-primary', 'escape' => false]
                                ) ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>

                <div class="row">
                    <div class="col-12">
                        <div class="card-modern shadow-lg mb-4">
                            <div class="card-header bg-transparent border-bottom py-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h4 class="mb-0 fw-bold text-primary">
                                        <i class="fas fa-calendar-alt me-2"></i>
                                        Appointment #<?= h($appointment->id) ?>
                                    </h4>

                                    <span class="status-text <?= $statusClass ?>">
                                        <span class="status-dot"></span>
                                        <?= $statusText ?>
                                    </span>
                                </div>
                            </div>

                            <div class="card-body p-4">
                                <div class="row g-4">

                                    <div class="col-md-6">
                                        <div class="info-card">
                                            <div class="info-icon">
                                                <i class="fas fa-user-circle text-warning"></i>
                                            </div>
                                            <div class="info-content">
                                                <small class="text-muted">ASSIGNED TO USER</small>
                                                <h5 class="mb-1"><?= h($assignedName) ?></h5>

                                                <?php if ($appointment->has('user') && !empty($appointment->user)): ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Patient -->
                                    <div class="col-md-6">
                                        <div class="info-card">
                                            <div class="info-icon">
                                                <i class="fas fa-user text-primary"></i>
                                            </div>
                                            <div class="info-content">
                                                <small class="text-muted">PATIENT</small>
                                                <h5 class="mb-1"><?= $appointment->hasValue('patient') ? h($appointment->patient->fullname) : 'N/A' ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Doctor -->
                                    <div class="col-md-6">
                                        <div class="info-card">
                                            <div class="info-icon">
                                                <i class="fas fa-user-doctor text-success"></i>
                                            </div>
                                            <div class="info-content">
                                                <small class="text-muted">DOCTOR</small>
                                                <h5 class="mb-1"><?= $appointment->hasValue('doctor') ? h($appointment->doctor->fullname) : 'N/A' ?></h5>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Date & Time -->
                                    <div class="col-md-6">
                                        <div class="info-card">
                                            <div class="info-icon">
                                                <i class="fas fa-calendar-day text-info"></i>
                                            </div>
                                            <div class="info-content">
                                                <small class="text-muted">APPOINTMENT DATE</small>
                                                <h5 class="mb-1">
                                                    <?php if (!empty($appointment->date)): ?>
                                                        <?php if (is_object($appointment->date) && method_exists($appointment->date, 'format')): ?>
                                                            <?= h($appointment->date->format('d/m/Y')) ?>
                                                        <?php else: ?>
                                                            <?= h(date('d/m/Y', strtotime((string)$appointment->date))) ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </h5>
                                                <p class="text-muted mb-0">
                                                    <i class="fas fa-clock me-1"></i>
                                                    <?php
                                                        if (is_object($appointment->time) && method_exists($appointment->time, 'format')) {
                                                            echo h($appointment->time->format('h:i A'));
                                                        } else {
                                                            echo h((string)$appointment->time ?: 'N/A');
                                                        }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Timeline -->
                                    <div class="col-12">
                                        <div class="timeline-section mt-3">
                                            <h6 class="fw-bold mb-2">
                                                <i class="fas fa-clock-rotate-left me-2"></i>Appointment Timeline
                                            </h6>

                                            <div class="row g-2">
                                                <div class="col-md-6">
                                                    <div class="timeline-mini-card">
                                                        <small class="text-muted d-block mb-1">CREATED</small>
                                                        <?php if (!empty($appointment->created)): ?>
                                                            <div class="fw-bold"><?= h($appointment->created->format('d/m/Y')) ?></div>
                                                            <div class="text-muted small"><?= h($appointment->created->format('h:i A')) ?></div>
                                                        <?php else: ?>
                                                            <div class="text-muted fst-italic">Not set</div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="timeline-mini-card">
                                                        <small class="text-muted d-block mb-1">LAST UPDATED</small>
                                                        <?php if (!empty($appointment->modified)): ?>
                                                            <div class="fw-bold"><?= h($appointment->modified->format('d/m/Y')) ?></div>
                                                            <div class="text-muted small"><?= h($appointment->modified->format('h:i A')) ?></div>
                                                        <?php else: ?>
                                                            <div class="text-muted fst-italic">Not set</div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <hr class="my-4">
                                                    <div class="notes-section">
                                                        <h5 class="mb-3 fw-bold">
                                                            <i class="fas fa-note-sticky me-2"></i>Notes & Details
                                                        </h5>

                                                        <?php if (!empty($appointment->notes)): ?>
                                                            <?= $this->Text->autoParagraph(h($appointment->notes)); ?>
                                                        <?php else: ?>
                                                            <div class="text-center py-4">
                                                                <i class="fas fa-circle-xmark text-muted fs-1 mb-2"></i>
                                                                <p class="text-muted mb-0">No notes available for this appointment.</p>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- row -->
                            </div><!-- body -->
                        </div><!-- card -->
                    </div>
                </div>

            <?php endif; ?>
        </main>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn  = document.getElementById('closeSidebar');
    var sidebar   = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar)  closeBtn.onclick  = () => sidebar.classList.add('hide');
});
</script>
