<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Appointment $appointment
 * @var \Cake\Collection\CollectionInterface|string[] $users
 * @var \Cake\Collection\CollectionInterface|string[] $patients
 * @var \Cake\Collection\CollectionInterface|string[] $doctors
 */
?>

<?php
// Page-specific CSS
echo $this->Html->css('appointment_admin');
?>

<!-- FONT AWESOME CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" 
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- FLATPICKR FOR DATE/TIME PICKER -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<style>
/* Additional styles for appointment form */
.section-title {
    color: #A53860;
    font-weight: 600;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid rgba(165, 56, 96, 0.1);
}

/* ===== FORM FOOTER BUTTONS (Cancel / Reset / Save) ===== */
.form-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;            /* allow wrap instead of squeezing */
}

.form-actions .left-actions,
.form-actions .right-actions {
    display: flex;
    gap: 14px;                  /* consistent spacing */
    flex-wrap: wrap;
    align-items: center;
}

/* Make all buttons same height & nicer */
.form-actions .btn {
    min-height: 54px;
    border-radius: 12px;
    padding: 12px 18px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    white-space: nowrap;        /* stop text breaking weirdly */
}

/* Make Save button pink like your theme */
.form-actions .btn-save {
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%) !important;
    border: none !important;
    color: #fff !important;
    box-shadow: 0 6px 16px rgba(165, 56, 96, 0.25);
    padding-left: 26px;
    padding-right: 26px;
}

.form-actions .btn-save:hover {
    transform: translateY(-1px);
    box-shadow: 0 10px 22px rgba(165, 56, 96, 0.35);
    filter: brightness(1.02);
}

/* On smaller width, make buttons full width (nice stacking) */
@media (max-width: 992px) {
    .form-actions {
        flex-direction: column;
        align-items: stretch;
    }
    .form-actions .left-actions,
    .form-actions .right-actions {
        justify-content: center;
    }
    .form-actions .btn {
        width: 100%;
    }
}

.top-actions .btn{
    border-radius: 10px;
    padding: 8px 12px;
}

.alert-info {
    background: rgba(165, 56, 96, 0.1);
    border: 1px solid rgba(165, 56, 96, 0.2);
    color: #A53860;
    border-radius: 10px;
}

.alert-warning {
    background: rgba(255, 193, 7, 0.1);
    border: 1px solid rgba(255, 193, 7, 0.2);
    color: #856404;
    border-radius: 10px;
}

.btn-primary {
    background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
    border: none;
    color: white;
    padding: 12px 25px;
    border-radius: 10px;
    font-weight: 600;
    transition: all 0.3s;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(165, 56, 96, 0.3);
}

.btn-outline-primary {
    color: #A53860;
    border-color: #A53860;
}

.btn-outline-primary:hover {
    background: #A53860;
    color: white;
}

/* Status badges styling */
.status-option {
    display: inline-block;
    margin: 5px;
    cursor: pointer;
}

.status-radio {
    display: none;
}

.status-badge {
    padding: 8px 15px;
    border-radius: 20px;
    border: 2px solid #e9ecef;
    transition: all 0.3s;
}

.status-radio:checked + .status-badge {
    border-color: #A53860;
    background: rgba(165, 56, 96, 0.1);
    font-weight: 600;
}

/* Time slots grid */
.time-slots {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
    gap: 10px;
    margin-top: 10px;
}

.time-slot {
    padding: 10px;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s;
}

.time-slot:hover {
    border-color: #A53860;
}

.time-slot.selected {
    background: rgba(165, 56, 96, 0.1);
    border-color: #A53860;
    color: #A53860;
    font-weight: 600;
}

/* Required field indicator */
.required::after {
    content: " *";
    color: #dc3545;
}

/* Loading state */
.loading {
    opacity: 0.7;
    pointer-events: none;
}

/* More space between each input block */
.form-group {
    margin-bottom: 24px;   /* was too small before */
}

/* More space between grid rows (Doctor + Date, Time, etc) */
.row {
    row-gap: 20px;
}

/* More space between sections */
.form-section {
    margin-bottom: 40px;
}

</style>

<?php
// Check if current user is a patient
$isPatient = false;
$patientId = null;
$currentUserId = $this->request->getAttribute('identity')['id'] ?? null;
$currentUserRole = $this->request->getAttribute('identity')['role'] ?? null;

// If user is patient, check if they have a patient profile
if ($currentUserRole === 'patient') {
    $isPatient = true;
    // Find patient record for current user
    foreach ($patients as $id => $patientName) {
        if (strpos($patientName, $this->request->getAttribute('identity')['fullname']) !== false) {
            $patientId = $id;
            break;
        }
    }
}
?>

<div class="admin-body">
    <div class="admin-wrapper">
        <!-- SIDEBAR -->
        <aside class="admin-sidebar" id="sidebar">
            <!-- Logo Section -->
            <div class="sidebar-header text-center py-4 border-bottom">
                <div class="sidebar-logo mx-auto mb-3">
                    <?= $this->Html->image('logo.png', [
                        'alt' => 'Clinic Logo',
                        'class' => 'logo-img'
                    ]) ?>
                </div>
                <h5 class="fw-bold" style="color: #A53860;">Elara Medical</h5>
                <small class="text-muted">Patient Portal</small>
                
                <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                    <i class="fas fa-times me-2"></i> Close
                </button>
            </div>

            <!-- Navigation Menu -->
            <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
        </aside>

        <!-- MAIN CONTENT -->
        <div class="main-content">
            <!-- HEADER -->
            <header class="top-header">
                <div class="d-flex align-items-center gap-3">
                    <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                        <i class="fas fa-bars fs-4"></i>
                    </span>
                    <h5 class="m-0 d-none d-md-block">Book New Appointment</h5>
                    <h5 class="m-0 d-md-none">New Appointment</h5>
                </div>

                <div class="d-flex gap-2">
                <?= $this->Html->link(
                    '<i class="bi bi-arrow-left me-2"></i> Back',
                    ['controller' => 'Appointments', 'action' => 'index'],
                    ['class' => 'btn btn-outline-light btn-sm', 'escape' => false]
                ) ?>
            </div>
            </header>

            <!-- FORM CONTENT -->
            <main class="content-area">
                <div class="card-modern">
                    <div class="mb-4">
                        <h3 class="section-title"><i class="fas fa-calendar-plus me-2"></i>Schedule New Appointment</h3>
                        <p class="text-muted mb-0">Fill in the details below to book your appointment</p>
                    </div>

                    <?php if ($isPatient && !$patientId): ?>
                        <!-- Patient profile not found warning -->
                        <div class="alert alert-warning d-flex align-items-center mb-4">
                            <i class="fas fa-exclamation-triangle me-3 fa-2x"></i>
                            <div>
                                <h5 class="alert-heading mb-2">Complete Your Profile First!</h5>
                                <p class="mb-0">You need to complete your patient profile before booking appointments.</p>
                                <?= $this->Html->link(
                                    '<i class="fas fa-user-plus me-2"></i> Complete Profile Now',
                                    ['controller' => 'Patients', 'action' => 'add'],
                                    ['class' => 'btn btn-primary mt-3', 'escape' => false]
                                ) ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <!-- Appointment Form -->
                        <?= $this->Form->create($appointment, [
                            'class' => 'appointment-form',
                            'id' => 'appointmentForm'
                        ]) ?>
                        
                        <div class="form-section">
                            <h5 class="section-title"><i class="fas fa-user-circle me-2"></i>Personal Information</h5>

                            <!-- Always store the logged-in user_id -->
                            <?= $this->Form->hidden('user_id', ['value' => $currentUserId]) ?>

                            <?php if ($isPatient): ?>
                                <!-- ✅ Patient user: auto-fill patient_id, no dropdown -->
                                <?= $this->Form->hidden('patient_id', ['value' => $patientId]) ?>

                                <div class="alert alert-info d-flex align-items-center">
                                    <i class="fas fa-circle-info me-3 fa-lg"></i>
                                    <div>
                                        Booking as: <b><?= h($this->request->getAttribute('identity')['fullname'] ?? 'Patient') ?></b>
                                    </div>
                                </div>

                            <?php else: ?>
                                <!-- Admin/staff: keep dropdown -->
                                <div class="form-group">
                                    <label class="form-label required">
                                        <i class="fas fa-user"></i> Patient
                                    </label>

                                    <?= $this->Form->control('patient_id', [
                                        'options' => $patients,
                                        'empty' => '-- Select Patient --',
                                        'label' => false,
                                        'class' => 'form-select',
                                        'required' => true
                                    ]) ?>
                                </div>
                            <?php endif; ?>
                        </div>


                        <div class="form-section">
                            <h5 class="section-title"><i class="fas fa-user-md me-2"></i>Medical Information</h5>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label required">
                                            <i class="fas fa-user-md"></i> Doctor/Specialist
                                        </label>
                                        <?= $this->Form->control('doctor_id', [
                                            'options' => $doctors,
                                            'empty' => '-- Select Doctor --',
                                            'label' => false,
                                            'class' => 'form-select',
                                            'required' => true
                                        ]) ?>
                                        <div class="form-text">
                                            <i class="fas fa-info-circle me-1"></i> Choose your preferred doctor or specialist
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label required">
                                            <i class="fas fa-calendar-day"></i> Appointment Date
                                        </label>
                                        <?= $this->Form->control('date', [
                                            'type' => 'text',
                                            'label' => false,
                                            'class' => 'form-control datepicker',
                                            'required' => true,
                                            'placeholder' => 'Select appointment date'
                                        ]) ?>
                                        <div class="form-text">
                                            <i class="fas fa-info-circle me-1"></i> Click to select date
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label required">
                                            <i class="fas fa-clock"></i> Appointment Time
                                        </label>
                                        <?= $this->Form->control('time', [
                                            'type' => 'text',
                                            'label' => false,
                                            'class' => 'form-control timepicker',
                                            'required' => true,
                                            'placeholder' => 'Select appointment time'
                                        ]) ?>
                                        <div class="form-text">
                                            <i class="fas fa-info-circle me-1"></i> Select preferred time slot
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-section">
                            <h5 class="section-title"><i class="fas fa-notes-medical me-2"></i>Additional Information</h5>
                            
                            <div class="form-group">
                                <label class="form-label">
                                    <i class="fas fa-sticky-note"></i> Notes (Optional)
                                </label>
                                <?= $this->Form->control('notes', [
                                    'type' => 'textarea',
                                    'label' => false,
                                    'class' => 'form-control',
                                    'rows' => 4,
                                    'placeholder' => 'Any special requirements, symptoms, or notes for the doctor...'
                                ]) ?>
                                <div class="form-text">
                                    <i class="fas fa-info-circle me-1"></i> 
                                    Add any additional information that might help the doctor
                                </div>
                            </div>
                        </div>

                        <div class="form-actions pt-4 border-top">
                            <div class="left-actions">
                                <?= $this->Html->link(
                                    '<i class="fas fa-xmark-circle"></i> Cancel',
                                    ['controller'=>'Appointments','action'=>'index'],
                                    ['class'=>'btn btn-lg btn-outline-secondary','escape'=>false,'escapeTitle'=>false]
                                ) ?>
                                
                                <div class="right-actions">
                                <?= $this->Form->button(
                                    '<i class="fas fa-rotate-right"></i> Reset',
                                    ['type' => 'reset', 'class' => 'btn btn-lg btn-outline-warning', 'escape' => false, 'escapeTitle' => false]
                                ) ?>
                                    
                                    <?= $this->Form->button(
                                    $appointment->isNew()
                                        ? '<i class="fas fa-calendar-plus"></i> Add Appointment'
                                        : '<i class="fas fa-floppy-disk"></i> Add Changes',
                                    ['type' => 'submit', 'class' => 'btn btn-lg btn-save', 'escape' => false, 'escapeTitle' => false]
                                    ) ?>
                                </div>
                            </div>
                        </div>

                        <?= $this->Form->end() ?>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    const toggleBtn = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const closeBtn = document.getElementById('closeSidebar');
    
    if (toggleBtn && sidebar) {
        toggleBtn.onclick = function() {
            sidebar.classList.toggle('hide');
        };
    }
    
    if (closeBtn && sidebar) {
        closeBtn.onclick = function() {
            sidebar.classList.add('hide');
        };
    }
    
    // Initialize date picker
    const datePicker = flatpickr(".datepicker", {
        dateFormat: "Y-m-d",
        minDate: "today",
        maxDate: new Date().fp_incr(90), // 90 days from today
        disableMobile: true,
        theme: "light",
        onChange: function(selectedDates, dateStr) {
            // Disable weekends
            const day = selectedDates[0].getDay();
            if (day === 0 || day === 6) {
                alert('Weekends are not available for appointments. Please select a weekday.');
                datePicker.clear();
            }
        }
    });
    
    // Initialize time picker
    flatpickr(".timepicker", {
        enableTime: true,
        noCalendar: true,
        dateFormat: "H:i",
        time_24hr: true,
        minuteIncrement: 15,
        disableMobile: true,
        minTime: "08:00",
        maxTime: "18:00",
        theme: "light"
    });
    
    // Form validation and submission
    const form = document.getElementById('appointmentForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const date = document.querySelector('.datepicker')?.value;
            const time = document.querySelector('.timepicker')?.value;
            const doctor = document.querySelector('select[name="doctor_id"]')?.value;
            
            // Validation
            let isValid = true;
            let errorMessage = '';
            
            if (!date) {
                isValid = false;
                errorMessage = 'Please select an appointment date.';
            } else if (!time) {
                isValid = false;
                errorMessage = 'Please select an appointment time.';
            } else if (!doctor || doctor === '') {
                isValid = false;
                errorMessage = 'Please select a doctor.';
            } else {
                // Check if date/time is in the future
                const selectedDateTime = new Date(date + ' ' + time);
                const now = new Date();
                
                if (selectedDateTime < now) {
                    isValid = false;
                    errorMessage = 'Appointment date and time must be in the future.';
                }
                
                // Check if it's a weekend
                const day = selectedDateTime.getDay();
                if (day === 0 || day === 6) {
                    isValid = false;
                    errorMessage = 'Appointments are not available on weekends.';
                }
                
                // Check if within working hours (8 AM - 6 PM)
                const hour = selectedDateTime.getHours();
                if (hour < 8 || hour >= 18) {
                    isValid = false;
                    errorMessage = 'Appointments are only available between 8:00 AM and 6:00 PM.';
                }
            }
            
            if (!isValid) {
                alert(errorMessage);
                return false;
            }
            
            // Show loading state
            const submitBtn = document.getElementById('submitBtn');
            if (submitBtn) {
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Booking Appointment...';
                submitBtn.disabled = true;
                submitBtn.classList.add('loading');
            }
            
            // Submit form
            form.submit();
        });
    }
    
    // Status badge selection
    document.querySelectorAll('.status-radio').forEach(radio => {
        radio.addEventListener('change', function() {
            document.querySelectorAll('.status-badge').forEach(badge => {
                badge.classList.remove('selected');
            });
            if (this.nextElementSibling) {
                this.nextElementSibling.classList.add('selected');
            }
        });
    });
    
    // Initialize badge selection
    document.querySelector('.status-radio:checked')?.dispatchEvent(new Event('change'));
    
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Responsive sidebar handling
    function handleResize() {
        if (window.innerWidth < 768) {
            sidebar.classList.add('hide');
        }
    }
    
    window.addEventListener('resize', handleResize);
    handleResize(); // Initial check
    
    // Auto-select current user if patient
    <?php if ($isPatient && $patientId): ?>
    // Disable patient selection for patients
    const patientSelect = document.querySelector('select[name="patient_id"]');
    if (patientSelect) {
        patientSelect.value = '<?= $patientId ?>';
        patientSelect.disabled = true;
    }
    <?php endif; ?>
});
</script>