<?php
/**
 * Appointments/index.php  (USER INDEX)
 *
 * ✅ Keeps your existing Actions buttons (view/edit/delete) - DO NOT CHANGE
 * ✅ Adds SEARCH BAR in the RED BOX area:
 *    - Appointment No (id)
 *    - Doctor dropdown (doctor_id)
 *    - Date (date)
 *
 * Controller must provide:
 * - $appointments (paginated)
 * - $total_appointments, $total_appointments_active, $total_appointments_disabled, $total_appointments_archived
 * - $doctors (array id => fullname)  <-- dropdown
 */

echo $this->Html->css('appointment_admin');
echo $this->Html->css('index_dashboard');

$currentUser   = $this->request->getAttribute('identity');
$userGroupId   = (int)(($currentUser->user_group_id ?? 0));
$isAdmin       = ($userGroupId === 1);

// Search values
$noValue       = (string)$this->request->getQuery('no');
$doctorIdValue = (string)$this->request->getQuery('doctor_id');
$dateValue     = (string)$this->request->getQuery('date');
$isSearch      = (!empty($noValue) || !empty($doctorIdValue) || !empty($dateValue));
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
/* ===================== FIX DOUBLE SCROLLBAR ===================== */
html, body { height: auto !important; overflow-y: auto !important; }
.admin-wrapper, .main-content, .content-area { overflow: visible !important; }
.content-area { height: auto !important; min-height: 0 !important; }
.admin-wrapper, .main-content, .content-area { overflow-x: hidden !important; }

/* =========================
   SEARCH (inline + same height) - like your admin sample
   ========================= */
.search-form { margin: 0; }
.search-wrap {
    display: flex !important;
    align-items: center !important;
    gap: 10px;
    position: relative;
    flex-wrap: wrap;
}
.search-input, .search-select {
    height: 44px !important;
    line-height: 44px !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    border-radius: 10px !important;
}
.search-select { padding-right: 34px !important; }
.search-btn {
    height: 44px !important;
    width: 44px !important;
    padding: 0 !important;
    border-radius: 10px !important;
    background: #fff !important;
    border: 1px solid rgba(0,0,0,0.10) !important;
    cursor: pointer !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
}
@media (max-width: 768px) {
    .search-wrap { gap: 8px; }
}

/* keep table neat */
.table-modern tbody tr { transition: all 0.2s ease; }
.table-modern tbody tr:hover { background-color: rgba(248, 182, 200, 0.08); }
</style>

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="text-center py-4 border-bottom">
            <div class="sidebar-logo mx-auto mb-3" style="width: 120px; height: 120px;">
                <?= $this->Html->image('logo.png', ['alt'=>'Elara Clinic Logo','class'=>'logo-img']) ?>
            </div>
            <h5 class="fw-bold text-primary m-0 mb-1">Elara Clinic</h5>
            <small class="text-muted"><?= $isAdmin ? 'Admin Panel' : 'Patient Portal' ?></small>

            <button class="btn btn-sm btn-outline-secondary d-md-none mt-3" id="closeSidebar">
                <i class="fas fa-times"></i> Close
            </button>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav flex-column gap-2 mt-3">
            <li><?= $this->Html->link(
                '<i class="fas fa-gauge-high"></i> Dashboard',
                ['controller' => '', 'action' => 'dashboard'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-calendar-check"></i> Appointments',
                ['controller' => 'Appointments', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link active']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-hospital-user"></i> Patients',
                ['controller' => 'Patients', 'action' => 'index'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <li><?= $this->Html->link(
                '<i class="fas fa-user"></i> Profile',
                ['controller' => 'Users', 'action' => 'profile'],
                ['escape' => false, 'class' => 'nav-link']
            ) ?></li>

            <hr class="my-3">

            <li><?= $this->Html->link(
                '<i class="fas fa-right-from-bracket"></i> Logout',
                ['controller' => 'Users', 'action' => 'logout'],
                ['escape' => false, 'class' => 'nav-link text-danger fw-bold']
            ) ?></li>
        </ul>

        <div class="sidebar-footer mt-auto pt-4">
            <small class="text-muted d-block text-center">© <?= date('Y') ?> Elara Clinic</small>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="top-header">
            <div class="d-flex align-items-center gap-3">
                <span class="toggle-btn" id="toggleSidebar" title="Toggle Sidebar">
                    <i class="fas fa-bars fs-4"></i>
                </span>
                <h5 class="m-0 d-none d-md-block"><?= h($title ?? 'Appointments List') ?></h5>
                <h5 class="m-0 d-md-none">Appointments</h5>
            </div>
        </header>

        <main class="content-area">

            <!-- CARDS (use your existing ones if you already have design) -->
            <div class="row mb-4 g-3">
                <div class="col-md-3 col-sm-6">
                    <div class="card-modern text-center shadow-sm">
                        <h3 class="mb-2 fw-bold"><?= (int)($total_appointments ?? 0) ?></h3>
                        <p class="text-muted mb-0">Total Appointments</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card-modern text-center shadow-sm">
                        <h3 class="mb-2 fw-bold"><?= (int)($total_appointments_active ?? 0) ?></h3>
                        <p class="text-muted mb-0">Active Appointments</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card-modern text-center shadow-sm">
                        <h3 class="mb-2 fw-bold"><?= (int)($total_appointments_archived ?? 0) ?></h3>
                        <p class="text-muted mb-0">Completed</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card-modern text-center shadow-sm">
                        <h3 class="mb-2 fw-bold"><?= (int)($total_appointments_disabled ?? 0) ?></h3>
                        <p class="text-muted mb-0">Cancelled</p>
                    </div>
                </div>
            </div>

            <!-- ✅ SEARCH BAR (PUTS IN YOUR RED BOX AREA) -->
            <div class="card-modern shadow-sm mb-4">
                <div class="header-search">
                    <?= $this->Form->create(null, [
                        'valueSources' => 'query',
                        'url' => ['controller' => 'Appointments', 'action' => 'index'],
                        'type' => 'get',
                        'class' => 'search-form'
                    ]) ?>

                    <div class="search-wrap">

                        <!-- Appointment No -->
                        <?= $this->Form->control('no', [
                            'label' => false,
                            'placeholder' => 'Appointment No',
                            'class' => 'form-control search-input',
                            'style' => 'width:160px;',
                            'value' => $noValue,
                            'type' => 'number',
                            'min' => 1
                        ]) ?>

                        <!-- Doctor dropdown -->
                        <?= $this->Form->control('doctor_id', [
                            'label' => false,
                            'options' => $doctors ?? [],
                            'empty' => 'All Doctors',
                            'class' => 'form-select search-select',
                            'style' => 'width:260px;',
                            'value' => $doctorIdValue
                        ]) ?>

                        <!-- Date -->
                        <?= $this->Form->control('date', [
                            'label' => false,
                            'type' => 'date',
                            'class' => 'form-control search-input',
                            'style' => 'width:200px;',
                            'value' => $dateValue
                        ]) ?>

                        <!-- Search button -->
                        <?= $this->Form->button('<i class="fas fa-magnifying-glass"></i>', [
                            'class' => 'btn search-btn',
                            'escape' => false,
                            'escapeTitle' => false,
                            'title' => 'Search Appointment',
                        ]) ?>

                        <!-- Reset -->
                        <?= $this->Html->link('<i class="fas fa-xmark"></i>',
                            ['controller'=>'Appointments','action'=>'index'],
                            ['class'=>'btn search-btn', 'escape'=>false, 'escapeTitle'=>false, 'title'=>'Reset']
                        ) ?>

                    </div>

                    <?= $this->Form->end() ?>
                </div>
            </div>

            <!-- TABLE CARD -->
            <div class="card-modern shadow-sm">
                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center py-3">
                    <h6 class="mb-0 fw-bold">Appointment Management</h6>
                    
                <div class="d-flex gap-2">
                    <?= $this->Html->link(
                        '<i class="fas fa-plus me-2"></i> Book New Appointment',
                        ['action' => 'add'],
                        ['class' => 'btn btn-primary fw-bold',
                                'escape' => false,
                                'escapeTitle' => false,
                                'style' => '
                                background: linear-gradient(135deg, #A53860 0%, #C44569 100%);
                                border: none;
                                border-radius: 8px;
                                padding: 10px 20px;
                                box-shadow: 0 4px 12px rgba(165, 56, 96, 0.3);
                                transition: all 0.3s ease;
                              '
                        ]
                                        
                            ) ?>
                </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-modern table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Patient</th>
                                <th>Doctor</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($appointments)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-5">
                                    <div class="py-4">
                                        <i class="fas fa-calendar-xmark fs-1 text-muted mb-3"></i>
                                        <h6 class="text-muted mb-0">
                                            <?= $isSearch ? 'No appointments match your search.' : 'No appointments found.' ?>
                                        </h6>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($appointments as $appointment): ?>
                                <?php
                                    // status display (adjust if you already have mapping)
                                    $statusText = 'Active';
                                    $statusClass = 'status-text-active';
                                    if ((int)($appointment->status ?? 1) === 0) {
                                        $statusText = 'Cancelled';
                                        $statusClass = 'status-text-default';
                                    } elseif ((int)($appointment->status ?? 1) === 2) {
                                        $statusText = 'Completed';
                                        $statusClass = 'status-text-completed';
                                    }

                                    $dateText = 'N/A';
                                    if (!empty($appointment->date)) {
                                        $dateText = (is_object($appointment->date) && method_exists($appointment->date, 'format'))
                                            ? $appointment->date->format('d/m/Y')
                                            : date('d/m/Y', strtotime((string)$appointment->date));
                                    }

                                    $timeText = 'N/A';
                                    if (!empty($appointment->time)) {
                                        $timeText = (is_object($appointment->time) && method_exists($appointment->time, 'format'))
                                            ? $appointment->time->format('h:i A')
                                            : (string)$appointment->time;
                                    }
                                ?>
                                <tr>
                                    <td><span class="badge-id">#<?= h($appointment->id) ?></span></td>

                                    <td>
                                        <?= $appointment->has('patient')
                                            ? h($appointment->patient->fullname)
                                            : h($appointment->patient_id) ?>
                                    </td>

                                    <td>
                                        <?= $appointment->has('doctor')
                                            ? h($appointment->doctor->fullname)
                                            : h($appointment->doctor_id) ?>
                                    </td>

                                    <td><?= h($dateText) ?></td>
                                    <td><?= h($timeText) ?></td>

                                    <td>
                                        <span class="status-text <?= $statusClass ?>">
                                            <span class="status-dot"></span>
                                            <?= h($statusText) ?>
                                        </span>
                                    </td>

                                    <!-- ✅ ACTION BUTTONS - KEEP SAME STYLE AS YOU WANT
                                         (If your old index already has buttons, paste them here exactly) -->
                                    <td class="text-center">
                                        <div class="action-buttons-sm">
                                            <?= $this->Html->link('<i class="fas fa-eye"></i>',
                                                ['action' => 'view', $appointment->id],
                                                ['class' => 'btn btn-outline-primary btn-sm', 'escape' => false]
                                            ) ?>

                                            <?= $this->Html->link('<i class="fas fa-pen-to-square"></i>',
                                                ['action' => 'edit', $appointment->id],
                                                ['class' => 'btn btn-outline-warning btn-sm', 'escape' => false]
                                            ) ?>

                                            <?= $this->Form->postLink('<i class="fas fa-trash"></i>',
                                                ['action' => 'delete', $appointment->id],
                                                [
                                                    'class' => 'btn btn-outline-danger btn-sm',
                                                    'escape' => false,
                                                    'confirm' => 'Are you sure you want to delete appointment #' . h($appointment->id) . '?'
                                                ]
                                            ) ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="card-footer bg-white border-top py-3">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <div class="text-muted">
                            <?= $this->Paginator->counter('Showing {{start}} to {{end}} of {{count}} appointments') ?>
                        </div>
                        <nav>
                            <ul class="pagination justify-content-center mb-0 pagination-sm">
                                <?= $this->Paginator->prev('Previous') ?>
                                <?= $this->Paginator->numbers() ?>
                                <?= $this->Paginator->next('Next') ?>
                            </ul>
                        </nav>
                    </div>
                </div>

            </div>
        </main>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // sidebar
    var toggleBtn = document.getElementById('toggleSidebar');
    var closeBtn  = document.getElementById('closeSidebar');
    var sidebar   = document.getElementById('sidebar');

    if (toggleBtn && sidebar) toggleBtn.onclick = () => sidebar.classList.toggle('hide');
    if (closeBtn && sidebar)  closeBtn.onclick  = () => sidebar.classList.add('hide');
});
</script>
