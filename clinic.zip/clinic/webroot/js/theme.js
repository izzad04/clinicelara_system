document.addEventListener("DOMContentLoaded", function () {
  const key = "ecms_theme";

  function applyTheme(mode) {
    document.body.classList.remove("light-mode", "dark-mode");
    document.body.classList.add(mode === "dark" ? "dark-mode" : "light-mode");
  }

  // load saved theme
  const saved = localStorage.getItem(key) || "light";
  applyTheme(saved);

  window.toggleDarkMode = function () {
    const isDark = document.body.classList.contains("dark-mode");
    const newMode = isDark ? "light" : "dark";
    applyTheme(newMode);
    localStorage.setItem(key, newMode);
  };
});
