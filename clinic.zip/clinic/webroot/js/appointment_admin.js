document.addEventListener('DOMContentLoaded', function() {
    const toggleBtn = document.querySelector('.toggle-btn');
    const sidebar = document.querySelector('.admin-sidebar');

    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('hide');
    });
});
