<?php

return [
    'DebugKit' => [
        'onlyDebug' => true,
    ],
    'Bake' => [
        'onlyCli' => true,
        'optional' => true,
    ],
    'Migrations' => [
        'onlyCli' => true,
    ],
    'AuditStash' => [],
    'CakePdf' => [],
    'Search' => [],
    'Tools' => [],
    'Josegonzalez/Upload' => [],
    'ReCrud' => [],
    'CsvView' => [],
];
