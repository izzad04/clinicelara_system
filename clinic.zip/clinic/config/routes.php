<?php
/**
 * Routes configuration.
 *
 * CakePHP(tm) : Rapid Development Framework
 * https://cakephp.org
 */

use Cake\Routing\Route\DashedRoute;
use Cake\Routing\RouteBuilder;

return function (RouteBuilder $routes): void {

    // Use dashed URLs
    $routes->setRouteClass(DashedRoute::class);

    /*
    |--------------------------------------------------------------------------
    | USER ROUTES
    |--------------------------------------------------------------------------
    */
    $routes->scope('/', function (RouteBuilder $builder): void {

        // Homepage (user dashboard)
        $builder->connect('/', [
            'controller' => 'Dashboards',
            'action' => 'index',
        ]);

        // Login
        $builder->connect('/login', [
            'controller' => 'Users',
            'action' => 'login',
        ]);

        // Logout
        $builder->connect('/logout', [
            'controller' => 'Users',
            'action' => 'logout',
        ]);

        // User dashboard
        $builder->connect('/dashboard', [
            'controller' => 'Dashboards',
            'action' => 'index',
        ]);

        // Other pages
        $builder->connect('/pages/*', 'Pages::display');
        $builder->connect('/contact', [
            'controller' => 'Contacts',
            'action' => 'add',
        ]);

        // Fallback routes
        $builder->fallbacks(DashedRoute::class);
    });

    /*
    |--------------------------------------------------------------------------
    | ADMIN ROUTES
    |--------------------------------------------------------------------------
    */
    $routes->prefix('Admin', function (RouteBuilder $routes): void {

        // Admin dashboard
        $routes->connect('/', [
            'controller' => 'Dashboards',
            'action' => 'index',
        ]);

        $routes->connect('/dashboard', [
            'controller' => 'Dashboards',
            'action' => 'index',
        ]);

        // Admin users management
        $routes->connect('/users', [
            'controller' => 'Users',
            'action' => 'index',
        ]);

        // Admin fallback routes
        $routes->fallbacks(DashedRoute::class);
    });
};
