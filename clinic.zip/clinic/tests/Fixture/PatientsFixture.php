<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * PatientsFixture
 */
class PatientsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'fullname' => 'Lorem ipsum dolor sit amet',
                'ic' => 'Lorem ipsum ',
                'phone' => 1,
                'email' => 'Lorem ipsum dolor ',
                'street1' => 'Lorem ipsum dolor sit a',
                'street2' => 'Lorem ipsum dolor sit a',
                'postcode' => 1,
                'city' => 'Lorem ipsum dolor sit a',
                'state' => 'Lorem ip',
                'created' => '2026-01-06 16:50:49',
                'modified' => '2026-01-06 16:50:49',
            ],
        ];
        parent::init();
    }
}
