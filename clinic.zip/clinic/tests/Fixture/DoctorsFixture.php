<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DoctorsFixture
 */
class DoctorsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'fullname' => 'Lorem ipsum dolor sit amet',
                'specialization' => 1,
                'status' => 1,
                'created' => '2026-01-06 15:21:21',
                'modified' => '2026-01-06 15:21:21',
            ],
        ];
        parent::init();
    }
}
